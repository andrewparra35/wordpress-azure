(function( $ ) {
	'use strict';

	/**
	 * =================================================
	 * 3rd PARTY
	 * =================================================
	 */
	/**
	 * jQuery UI easing
	 */
	$.extend($.easing, {
		easeInOutExpo: function (x, t, b, c, d) {
			if (t==0) return b;
			if (t==d) return b+c;
			if ((t/=d/2) < 1) return c/2 * Math.pow(2, 10 * (t - 1)) + b;
			return c/2 * (-Math.pow(2, -10 * --t) + 2) + b;
		},
	});
	/**
	 * Currently GF conditional_logic.js doesn't trigger 'change' event after
	 * '.prop()', so this patch is needed.
	 * http://stackoverflow.com/a/17946759
	 */
	$.propHooks.checked = {
		set: function(elem, value, name) {
			var ret = (elem[ name ] = value);
			$(elem).trigger("change");
			return ret;
		}
	};



	/**
	 * =================================================
	 * CONSTANTS & GLOBALS
	 * =================================================
	 */
	/**
	 * Constants
	 */
	var
	ARROW_LEFT     = 37,
	ARROW_UP       = 38,
	ARROW_RIGHT    = 39,
	ARROW_DOWN     = 40,
	TAB            = 9,
	ENTER          = 13,
	NEXT           = 1,
	PREV           = -1,
	INPUTS         = 'input:not([type="hidden"]), select, textarea',
	LETTERS        = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];

	/**
	 * Globals
	 */
	var lastform = {};



	/**
	 * =================================================
	 * INIT
	 * =================================================
	 */
	$(document).ready(function(){
		/**
		 * Skip welcome message...
		 */
		if ( welcomeScreenIsActive() && (!hasGForm() || formHasErrors()) ) {
			$('.lf-welcome').remove();
		}
		/**
		 * Is touch device
		 */
		toggleTouchClass();
		/**
		 * Add footer trigger field to 'ul.gform_fields'
		 */
		addFooterTriggerField();
		/**
		 * Move footer GF field to '#lf-footer-trigger' footer trigger field
		 */
		moveFooterToTriggerField();
		/**
		 * Add 'press ENTER' hint to footer
		 */
		addShortcutHintToFooter();
		/**
		 * Add 'lf-checked' class to checked radios and checkbox
		 */
		$('.ginput_container_radio input:radio:checked, .ginput_container_checkbox input:checkbox:checked').parent().addClass('lf-checked');
		/**
		 * Auto grow textareas
		 */
		$('.ginput_container textarea').css('overflow', 'hidden').autogrow({animate: false});
		/**
		 * Add shortcut hints
		 */
		$('.gfield_radio, .gfield_checkbox').each(function(){
			$(this).find('label').each(function(index){
				$(this).prepend('<small class="lf-shortcut-hint"><h>'+lastformLocalize.hint_key+'</h> '+LETTERS[index]+'</small>');
			});
		});
		/**
		 * Add field tips
		 */
		$('.ginput_container_checkbox').each(function(){
			if ($(this).find('input:checkbox').length > 1) {
				$(this).prepend('<p class="lf-field-tip"><i class="lfi-done_all"></i> '+getMultichoiceTip()+'</p>');
			}
		});
		$('.ginput_container_multiselect').each(function(){
			$(this).prepend('<p class="lf-field-tip"><i class="lfi-done_all"></i> '+getMultichoiceTip()+'</p>');
		});
		$('.ginput_container textarea').each(function(){
			$(this).parent().addClass('lf-ginput_container_textarea');
			$(this).parent().prepend('<p class="lf-field-tip"><i class="lfi-keyboard_return"></i> '+lastformLocalize.textarea_tip+'</p>');
		});
		/**
		 * Hide navigation arrows on confirmation message
		 */
		if (isConfirmationMessageScreen()) {
			$('.lf-progress-box').hide();
			$('.lf-nav-arrows').hide();
		}
		/**
		 * Start select2.js
		 */
		$('.ginput_container_select select, .address_country select, .ginput_container_multiselect select').select2({width:'100%'});
		/**
		 * Add helper Continue buttons
		 */
		var continueButton = '<div class="lf-continue-help"><a href="javascript:void(0)" class="lf-continue-button">OK <i class="lfi-check"></i></a><span>'+lastformLocalize.press_enter+'</strong></span></div>';
		$('.ginput_container:not(.ginput_container_multiselect) input:not([type="hidden"]):not([type="radio"]):not([type="checkbox"]):not([type="submit"]):not([type="button"]):not([type="image"]):not([type="file"]), .ginput_container textarea, .ginput_container_total input, .ginput_container_fileupload input, .ginput_container_multiselect .select2-container').after(continueButton);
		$('.gfield_html, .ginput_container_checkbox').append(continueButton);
		/**
		 * Add keyboard icons
		 */
		$('.ginput_container input:not([type="hidden"]):not([type="radio"]):not([type="checkbox"]):not([type="submit"]):not([type="button"]):not([type="image"]):not([type="file"]), .ginput_container textarea').after('<i class="lf-keyboard-icon lfi-keyboard"></i>');
		/**
		 * Add Upload buttons
		 */
		$('.ginput_container_fileupload input[type="file"]').each(function(){
			$(this).after('<label for="'+$(this).attr('id')+'"><span class="upload-button">'+lastformLocalize.upload_button+'<i class="lfi-file_upload"></i></span> <span class="upload-tip">'+lastformLocalize.press_enter+'</span></label>');
		});
	});

	$(window).on('load', function(){
		/**
		 * Remove preloader
		 */
		$('.lf-preloader').fadeOut(800, 'easeInOutExpo');
		/**
		 * Init Waypoints directly in case of no welcome screen
		 * or message screen
		 */
		if (!welcomeScreenIsActive() && !isConfirmationMessageScreen() ) {
			initWaypoints();
			$('.gform_wrapper').css({'overflow-y':'auto','max-height':'auto','position':'relative','opacity':1});
			$('.lf-progress-box, .lf-nav-arrows').css({bottom: 0});
		}
	});



	/**
	 * =================================================
	 * TRIGGERS
	 * =================================================
	 */
	/**
	 * Init Waypoints when Welcome Screen is closed
	 */
	$(document).on('lastformWelcomeScreenWasClosed', function(){
		initWaypoints();
	});

	/**
	 * Activate first visible field when Waypoints is initialized.
	 * Activate first field with error if there is any.
	 */
	$(document).on('lastformWaypointsWasInitialized', function(){
		holdUser();
		if (formHasErrors()) {
			activateField(getFieldsWithErrors()[0]);
		} else {
			activateField(getVisibleFields()[0]);
		}
	});

	/**
	 * Swipe between fields
	 */
	$(window).on('touchstart', function(event){
		releaseScroll();
		lastform.windowTop = $(window).scrollTop();
	});
	$(window).on('touchend', function(event){
		holdScroll();
		var
		scrolled           = $(window).scrollTop() - lastform.windowTop;

		if (currentFieldHeight() <= viewportHeight() && !lastform.waypointWasFired) {
			// Down
			if (scrolled < 0 && !isFirstField()) {
				holdUser();
				activateRelativeField(PREV);
			// Up
			} else if (scrolled > 0 && !footerIsActive()) {
				holdUser();
				activateRelativeField(NEXT);
			}
		}

		lastform.waypointWasFired = false;
	});

	/**
	 * Is scrolling?
	 */
	$(window).on('scroll', function(event){
		lastform.isScrolling = true;

		clearTimeout($.data(this, 'scrollTimer'));

		$.data(this, 'scrollTimer', setTimeout(function() {
			lastform.isScrolling = false;
		}, 250));
	});


	/**
	 * Re-check touch class
	 */
	$(window).on('resize', function(){
		toggleTouchClass();
	});

	/**
	 * Toggle footer when '#lf-footer-trigger' is de/activated
	 */
	$(document).on('lastformFieldWasActivated', function(event, field){
		if (field.element.id == 'lf-footer-trigger') {
			clearTimeout(lastform.footerActivationTimeout);
			lastform.footerActivationTimeout = setTimeout(function(){
				// Still active?
				if (field.active) {
					$('.gform_footer').addClass('lf-footer-active');
				}
			},250);
		}
	});
	$(document).on('lastformFieldWasDeactivated', function(event, field){
		if (field.element.id == 'lf-footer-trigger') {
			clearTimeout(lastform.footerActivationTimeout);
			lastform.footerActivationTimeout = setTimeout(function(){
				$('.gform_footer').removeClass('lf-footer-active');
			},250);
		}
	});

	/**
	 * Update progress box
	 */
	$(document).on('lastformFieldWasActivated', function(event, field){
		progressBoxUpdate(field);
	});

	/**
	 * Toggle '.ls-active' class on field de/activation
	 */
	$(document).on('lastformFieldWasActivated', function(event, field){
		$(field.element).addClass('lf-active');
	});
	$(document).on('lastformFieldWasDeactivated', function(event, field){
		$(field.element).removeClass('lf-active');
	});

	/**
	 * Blur inputs of inactive fields
	 */
	$(document).on('lastformFieldWasDeactivated', function(event, field){
		$(field.element).find(':focus').blur();
	});

	/**
	 * Toggle '.lf-focused-child' class on input focus
	 */
	$(document).on('focusin', INPUTS, function(){
		$('.lf-focused-child').removeClass('lf-focused-child');
		$(this).parent().addClass('lf-focused-child');
	});
	$(document).on('focusout', INPUTS, function(){
		$('.lf-focused-child').removeClass('lf-focused-child');
	});

	/**
	 * Activate/deactivate select2.js when needed
	 */
	$(document).on('lastformFieldWasActivated', function(event, field){
		if (containerHasSelectInput(field) && !isTouchDevice()) {
			$(field.element).find('select').select2('open');
		}
	});
	$(document).on('lastformFieldWasDeactivated', function(event, field){
		if (containerHasSelectInput(field)) {
			clearTimeout(lastform.select2TimeoutClose);
			lastform.select2TimeoutClose = setTimeout(function(){
				clearSelect2Inputs(field);
			},150);
			clearSelect2Inputs(field);
		}
	});
	$(document).on('focusin', '.select2-selection--single', function(e) {
		$(this).closest('.select2-container').siblings('select').select2('open');
	});

	/**
	 * Jump to next question when select2.js dropdown option is changed
	 */
	$(document).on('change', '.ginput_container_select select, .address_country select', function(){
		holdUser();
		setTimeout(function(){
			activateRelativeField(NEXT);
		},250);
	});

	/**
	 * Activate/deactivate datepicker when needed
	 */
	$(document).on('click', '.datepicker', function(e) {
		if (datepickerIsLoaded()) {
			$(this).datepicker('show');
		}
	});
	$(document).on('lastformFieldWasDeactivated', function(event, field){
		if (datepickerIsLoaded()) {
			$(field.element).find('.datepicker').datepicker('hide');
		}
	});

	/**
	 * Jump to next question when datepicker value is changed
	 */
	$(document).on('change', '.datepicker', function(){
		if(datepickerIsLoaded()) {
			holdUser();
			setTimeout(function(){
				activateRelativeField(NEXT);
			},250);
		}
	});

	/**
	 * Navigation arrow buttons
	 */
	$(document).on('click', '.lf-nav-arrow-up', function(){
		holdUser();
		activateRelativeField(PREV);
	});
	$(document).on('click', '.lf-nav-arrow-down', function(){
		holdUser();
		activateRelativeField(NEXT);
	});

	/**
	 * Navigation help button
	 */
	$(document).on('mousedown', '.lf-continue-help a', function(event){
		event.preventDefault();
		// Is last input
		if (!containerIsComplex() || currentInputIsLast()) {
			holdUser();
			activateRelativeField(NEXT);
		// Behavior as TAB
		} else {
			focusNextInput();
		}
	});

	/**
	 * Auto-scroll to field after activation
	 */
	$(document).on('lastformFieldWasActivated', function(event, field){
		if (userIsHeld() || isTouchDevice()) {
			autoScrollToField(field);
		}
	});

	/**
	 * Check if input is filled
	 */
	$(window).on('keyup', function (event) {
		if ( focusedTextInputIsFilled() ) {
			$(focusedTextInput()).parent().addClass('lf-input-filled');
		} else {
			$(focusedTextInput()).parent().removeClass('lf-input-filled');
		}
	});
	$(document).on('change', '.ginput_container_multiselect select', function (event) {
		if ($(this).find(':selected').length > 0) {
			$(this).parent().addClass('lf-input-filled');
		} else {
			$(this).parent().removeClass('lf-input-filled');
		}
	});
	$(document).on('change', '.ginput_container_checkbox', function (event) {
		if ($(this).find(':checked').length > 0) {
			$(this).addClass('lf-input-filled');
		} else {
			$(this).removeClass('lf-input-filled');
		}
	});
	$(document).on('change', '.ginput_container_fileupload input[type="file"]', function (event) {
		if ($(this).val() != '') {
			$(this).parent().addClass('lf-input-filled');
			holdUser();
			activateRelativeField(NEXT);
		} else {
			$(this).parent().removeClass('lf-input-filled');
		}
	});

	/**
	 * Toggle '.lf-checked' class on radio and checkbox change
	 */
	 $(document).on('change', '.ginput_container_checkbox input:checkbox, .ginput_container_radio input:radio', function(){
		 if(this.checked){
			 $('.gform_fields input:radio[name="'+$(this).attr('name')+'"]').parent().removeClass('lf-checked');
			 $(this).parent().addClass('lf-checked');
		 } else {
			 $(this).parent().removeClass('lf-checked');
		 }
	 });

	/**
	 * Activate next field on radio change
	 */
	$(document).on('change', '.ginput_container_radio input:radio', function(){
		if(this.checked && $(this).val() != 'gf_other_choice'){
			holdUser();
			clearTimeout(lastform.optionChangeTimeout);
			lastform.optionChangeTimeout = setTimeout(function(){
				activateRelativeField(NEXT);
			},500);
		}
	});

	/**
	 * Toggle 'touchIsActive' var
	 */
	$(document).on('touchstart', function(event){
		clearTimeout(lastform.touchIsActiveTimeout);
		lastform.touchIsActive = true;
	});
	$(document).on('touchend', function(event){
		lastform.touchIsActiveTimeout = setTimeout(function(){
			lastform.touchIsActive = false;
		},250);
	});

	/**
	 * Focus active field first input
	 */
	$(document).on('lastformFieldWasActivated', function(event, field){
		setTimeout(function(){
			focusFirstInput(field);
		},300);
	});

	/**
	 * Scrolling
	 */
	$(window).on('scroll mousedown wheel DOMMouseScroll mousewheel keydown', function(event){
		if (userIsHeld()) {
			event.preventDefault();
			event.stopPropagation();
			return false;
		}
	});

	/**
	 * Progress box update
	 */
	$(document).on('lastformWaypointsWasInitialized', function(){
		progressBoxUpdate();
	});

	/**
	 * Navigation arrows and progress box position update
	 */
	$(window).on('load',function(){
		navArrowPosition();
		progressBoxPosition();
	});
	$(window).on('resize', function(){
		navArrowPosition();
		progressBoxPosition();
	});

	/**
	 * Close welcome screen
	 */
	$(document).on('click', '#lf-welcome-start-button', function(){
		closeWelcomeScreen();
	});

	/**
	 * Keyboard shortcuts
	 */
	$(window).on('keydown', function (event) {
		if (userIsHeld()) {
			return false;
		}

		var key = event.keyCode;

		switch(key) {
			case TAB:
				// SHIFT+TAB and is first input
				if (event.shiftKey && (!containerIsComplex() || currentInputIsFirst())) {
					holdUser();
					activateRelativeField(PREV);
				}
				// SHIFT+TAB and there is no focused input
				else if (event.shiftKey && noFocusedInput()) {
					holdUser();
					activateRelativeField(PREV);
				}
				// SHIFT+TAB and is NOT first input
				else if (event.shiftKey && (!containerIsComplex() || !currentInputIsFirst())) {
					return true;
				}
				// TAB and is Select2 field
				else if (containerIsSelect()) {
					holdUser();
					activateRelativeField(NEXT);
				}
				// TAB and there is no focused input
				else if (noFocusedInput()) {
					holdUser();
					activateRelativeField(NEXT);
				}
				// TAB and is last input
				else if (!containerIsComplex() || currentInputIsLast()) {
					holdUser();
					activateRelativeField(NEXT);
				}
				// TAB normally
				else {
					return true;
				}
				return false;
				break;
			case ENTER:
				// ENTER and welcome screen is active
				if (welcomeScreenIsActive()) {
					closeWelcomeScreen();
				}
				// CMD+ENTER / CTRL+enter
				else if (event.metaKey || event.ctrlKey) {
					submitForm();
				}
				// SHIFT+ENTER
				else if (event.shiftKey) {
					return true;
				}
				// ENTER and footer is active
				else if (footerIsActive()) {
					submitForm();
				}
				// ENTER and is upload field
				else if (isUploadField() && isUploadFieldIsEmpty()) {
					fireCurrentUploadField();
				}
				// ENTER and Select2 field
				else if (containerHasSelectInput() && select2DropdownHasHighligtedOption()) {
					event.stopPropagation();
					return true;
				}
				// ENTER and there is no focused input
				else if (noFocusedInput()) {
					holdUser();
					activateRelativeField(NEXT);
				}
				// ENTER and is last input
				else if (!containerIsComplex() || currentInputIsLast()) {
					holdUser();
					activateRelativeField(NEXT);
				}
				// ENTER as TAB
				else {
					focusNextInput();
				}
				return false;
				break;
			default:
				// A-Z keys inside fields with keyboar shortcuts
				// (aka radios and checkbox)
				if (isLetterKey(key) && !eventHasShortcutKey(event) && isShortcutable()) {
					var
					index = key - 65,
					input = $('.lf-active input:radio, .lf-active input:checkbox')[index];
					if ($(input).is(':radio')) {
						holdUser();
					}
					if (typeof input != 'undefined') {
						// Uncheck checked checkbox :D
						if ($(input).is(':checkbox:checked')) {
							$(input).prop('checked', false)[0].onclick();
						} else {
							$(input).prop('checked', true)[0].onclick();
						}
					}
					return false;
				}
				break;
		}
		return true;
	});

	/**
	 * Gravity Forms conditional logic
	 */
	gform.addAction('gform_post_conditional_logic_field_action', function (formId, action, targetId, defaultValues, isInit) {
		if (!lastform.waypoints) {
			return false;
		}

		var triggeredField = getFieldById(targetId);

		setTimeout(function(){
			if (action == 'show' && $(triggeredField.element).is(':visible')) {
				triggeredField.enable();
			} else if (action == 'hide') {
				triggeredField.disable();
			}
		},400);
	});



	/**
	 * =================================================
	 * FUNCTIONS
	 * =================================================
	 */

	// Source: http://stackoverflow.com/a/4819886/1355201
	function isTouchDevice() {
		return 'ontouchstart' in window || navigator.maxTouchPoints; // works on IE10/11 and Surface
	}

	function toggleTouchClass() {
		if (isTouchDevice()) {
			$('html').addClass('lf-is-touch');
		} else {
			$('html').removeClass('lf-is-touch');
		}
	}

	function isTouching() {
		return lastform.touchIsActive;
	}

	function isScrolling() {
		return lastform.isScrolling;
	}

	function welcomeScreenIsActive() {
		return $('.lf-welcome').length > 0;
	}

	function hasGForm() {
		return $('.gform_wrapper').length > 0;
	}

	function isConfirmationMessageScreen() {
		return $('.gform_confirmation_message').length > 0;
	}

	function formHasErrors() {
		return $('.gform_wrapper').hasClass('gform_validation_error');
	}

	function closeWelcomeScreen() {
		holdUser();
		$('.lf-welcome-content').css('overflow-y','hidden');
		$('.gform_wrapper').css({'overflow-y':'auto','max-height':'auto','position':'relative'});
		$('html, body').scrollTop(0);
		$('.lf-welcome').animate({ opacity:0 }, 750, 'easeInOutExpo', function(){
			$(this).remove();
			releaseUser();
			$(document).trigger('lastformWelcomeScreenWasClosed');
		});
		$('.gform_wrapper').animate({opacity: 1}, 1500, 'easeInOutExpo');
		$('.lf-progress-box, .lf-nav-arrows').delay(1000).animate({bottom: 0}, 500, 'easeInOutExpo');
	}

	function getVisibleFields() {
		return $.grep(lastform.waypoints, function(obj){
			return obj.enabled === true;
		});
	}

	function getFieldsWithErrors() {
		return $.grep(lastform.waypoints, function(obj){
			return obj.enabled === true && $(obj.element).hasClass('gfield_error');
		});
	}

	function getFieldById(targetId){
		var foundField;
		targetId = targetId.replace('#','');
		for (var i = 0; i < lastform.waypoints.length; i++) {
			if (lastform.waypoints[i].element.id == targetId) {
				foundField = lastform.waypoints[i];
				break;
			}
		}
		return foundField;
	}

	function submitForm() {
		$('.gform_wrapper form').submit();
	}

	function fixedMargin() {
		return ($(window).width() - $('.gform_fields .gfield:first-child').width()) / 2;
	}

	function navArrowPosition() {
		$('.lf-nav-arrows').css('right', fixedMargin());
	}

	function progressBoxPosition() {
		$('.lf-progress-box').css('left', fixedMargin());
	}

	function progressBoxUpdate(field) {
		if ($('.lf-progress-box').length < 1) {
			return false;
		}

		var
		visibleFields  = getVisibleFields(),
		active         = (typeof field == 'undefined') ? visibleFields[0] : field,
		activePosition = $(visibleFields).index(active),
		visibleTotal   = visibleFields.length - 1,
		percentage     = Math.round(activePosition * 100 / visibleTotal)+'%';

		progressBoxTextUpdate(activePosition, visibleTotal, percentage);
		progressBoxBarUpdate(percentage);
	}

	function progressBoxTextUpdate(activePosition, visibleTotal, percentage) {
		var
		$progressText   = $('.lf-progress-text'),
		progressTextVal,
		position;

		/**
		 * Progress box text
		 */
		if ($progressText.hasClass('lf-progress-proportional')) {
			position = activePosition + 1;
			progressTextVal = lastformLocalize.progress_proportional.replace('$1', position).replace('$2', visibleTotal);
		} else {
			progressTextVal = lastformLocalize.progress_percentage.replace('$1', percentage);
		}

		$progressText.text(progressTextVal);
	}

	function progressBoxBarUpdate(percentage) {
		$('.lf-progress-bar-fill').stop().animate({width:percentage}, 150, 'easeInOutExpo');
	}

	function getActiveField() {
		var activeField;

		$(lastform.waypoints).each(function(){
			if (this.active === true) {
				activeField = this;
				return false;
			}
		});

		return activeField;
	}

	function isFirstField() {
		return $(getVisibleFields()).index(getActiveField()) === 0;
	}

	function footerIsActive() {
		return getActiveField().element.id == 'lf-footer-trigger';
	}

	function activeFieldContainer() {
		return $(getActiveField().element).find('.ginput_container');
	}

	function currentInputIndex() {
		return getActiveFieldInputs().index(focusedInput());
	}

	function currentInputIsFirst() {
		return currentInputIndex() === 0;
	}

	function currentInputIsLast() {
		return currentInputIndex() === getActiveFieldInputs().length - 1;
	}

	function focusNextInput() {
		getActiveFieldInputs()[currentInputIndex()+1].focus();
	}

	function containerIsComplex() {
		var container = activeFieldContainer();
		return container.hasClass('ginput_complex') || container.hasClass('ginput_container_time') || container.hasClass('ginput_container_date') || container.hasClass('ginput_container_list');
	}

	function containerIsSelect() {
		var container = activeFieldContainer();
		return container.hasClass('ginput_container_select') || container.hasClass('ginput_container_multiselect');
	}

	function containerHasSelectInput(field) {
		var container;
		if (typeof field == 'undefined') {
			container = activeFieldContainer();
		} else {
			container = $(field.element).children('.ginput_container');
		}
		return container.hasClass('ginput_container_select') || container.hasClass('ginput_container_multiselect');
	}

	function clearSelect2Inputs(field) {
		$(field.element).find('select').select2('close');
		$(field.element).find('.select2-search__field').blur();
	}

	function select2DropdownHasHighligtedOption() {
		return $('.select2-container--open').length > 0;
	}

	function datepickerIsLoaded() {
		return typeof jQuery().datepicker === 'function';
	}

	function isShortcutable() {
		var container = activeFieldContainer();
		return container.hasClass('ginput_container_radio') || container.hasClass('ginput_container_checkbox');
	}

	function isLetterKey(keyCode) {
		return keyCode >= 65 && keyCode <= 90;
	}

	function eventHasShortcutKey(event) {
		return event.altKey || event.ctrlKey || event.metaKey || event.shiftKey;
	}

	function scrollIsAutomatic() {
		return lastform.scrollIsAutomatic;
	}

	function isUploadField() {
		return $(activeFieldContainer()).hasClass('ginput_container_fileupload');
	}

	function isUploadFieldIsEmpty() {
		return $(activeFieldContainer()).find('input[type="file"]').val() == '';
	}

	function fireCurrentUploadField() {
		$(activeFieldContainer()).find('input[type="file"]').click();
	}

	function getActiveFieldInputs() {
		return $(getActiveField().element).find(INPUTS);
	}

	function focusFirstInput(field) {
		if (!isTouchDevice()) {
			var firstField = $(field.element).find(INPUTS)[0];

			if (typeof firstField != 'undefined') {
				$(firstField).focus();
			}
		}
	}

	function getMultichoiceTip() {
		if (isTouchDevice()) {
			return lastformLocalize.multichoice_tip_mobile;
		} else {
			return lastformLocalize.multichoice_tip;
		}
	}

	function userIsHeld() {
		return lastform.holdUser;
	}

	function holdUser() {
		lastform.holdUser = true;
	}

	function releaseUser() {
		lastform.holdUser = false;
	}

	function focusedInput() {
		return $('input:not([type="hidden"]):focus, select:focus, textarea:focus')[0];
	}

	function noFocusedInput() {
		return typeof focusedInput() == 'undefined';
	}

	function focusedTextInput() {
		return $('input:not([type="hidden"]):not([type="radio"]):not([type="checkbox"]):not([type="submit"]):not([type="button"]):not([type="image"]):not([type="file"]):focus, textarea:focus')[0];
	}

	function focusedTextInputIsFilled() {
		if (focusedTextInput()) {
			return $(focusedTextInput()).val().length > 0;
		}
	}

	function activateField(field) {
		field.active = true;
	}

	function activateRelativeField(num) {
		var
		activeField = getActiveField(),
		newField    = getNewField(activeField, num);

		if (typeof newField == 'undefined') {
			var
			visibleFields         = getVisibleFields(),
			activeFieldIndex      = $(visibleFields).index(activeField),
			lastVisibleFieldIndex = visibleFields.length - 1;

			if (activeFieldIndex == 0) {
				newField = visibleFields[lastVisibleFieldIndex];
			} else if (activeFieldIndex == lastVisibleFieldIndex) {
				newField = visibleFields[0];
			} else {
				return false;
			}
		}

		activateField(newField);
	}

	function holdScroll() {
		$('body').css('overflow-y', 'hidden');
	}

	function releaseScroll() {
		$('body').css('overflow-y', 'scroll');
	}

	function currentFieldHeight(){
		return $(getActiveField().element).outerHeight();
	}

	// Source: http://jsbin.com/diwoyevive/2/edit?html,css,js,output
	function viewportHeight() {
		var div, height;
		div                 = document.createElement('div');
		div.style.height    = '100vh';
		div.style.maxHeight = 'none';
		div.style.boxSizing = 'content-box';
		document.body.appendChild(div);
		height              = div.clientHeight;
		document.body.removeChild(div);
		return height;
	}

	function getNewField(field, num) {
		var
		keyIndex = parseInt(field.key.replace('waypoint-','')),
		newField;
		// Search backward
		if (num < 0) {
			for (var i = keyIndex - 1; i >= 0; i--) {
				if (lastform.waypoints[i].enabled) {
					newField = lastform.waypoints[i];
					break;
				}
			}
		// Search forward
		} else {
			for (var i = keyIndex + 1; i < lastform.waypoints.length; i++) {

				if (lastform.waypoints[i].enabled) {
					newField = lastform.waypoints[i];
					break;
				}
			}
		}

		return newField;
	}

	function getCurrentLastEnabledField() {
		for (var i = lastform.waypoints.length - 1; i >= 0; i--) {
			if (lastform.waypoints[i].enabled) {
				return lastform.waypoints[i];
				break;
			}
		}
	}

	function addFooterTriggerField() {
		$('.gform_fields').append('<li id="lf-footer-trigger" class="gfield lf-footer-trigger"></li>');
	}

	function moveFooterToTriggerField() {
		$('.gform_footer').appendTo('#lf-footer-trigger');
	}

	function addShortcutHintToFooter() {
		$('.gform_footer input[type=submit]').after('<span>'+lastformLocalize.press_enter+'</span>');
	}

	function autoScrollToField(field) {
		var
		maxFieldHeight = ($(window).outerHeight() * 0.45),
		marginTop,
		goTo;

		if ($(field.element).outerHeight() > maxFieldHeight) {
			marginTop = ($(window).outerHeight() - $(field.element).outerHeight()) * 0.45;
			marginTop = (marginTop < 15) ? 15 : marginTop;
		} else {
			marginTop = ($(window).outerHeight() * 0.45);
		}
		goTo = $(field.element).offset().top - marginTop;

		$('html, body').stop().animate({scrollTop:goTo}, 300, 'easeInOutExpo', function() {
			releaseUser();
			$(document).trigger('lastformAutoScrollToFieldEnded', field);
		});
	}


	function initWaypoints() {
		/**
		 * Start Waypoints plugins
		 */
		lastform.waypoints = $('.gfield').waypoint({
			handler: function(direction) {
				if ( isScrolling() && !userIsHeld() ) {
					if (isTouchDevice() && !isTouching()) {
						return false;
					}

					if (direction == 'down') {
						activateField(this);
					} else if (direction == 'up') {
						var keyIndex = parseInt(this.key.replace('waypoint-',''));
						for (var i = keyIndex - 1; i >= 0; i--) {
							if (lastform.waypoints[i].enabled) {
								activateField(lastform.waypoints[i]);
								break;
							}
						}
					}

					lastform.waypointWasFired = true;
				}
			},
			offset: '50%',
			enabled: false
		});

		/**
		 * Loop waypoints elements
		 */
		for (var i = 0; i < lastform.waypoints.length; i++) {
			// Default value
			lastform.waypoints[i].active = false;
			/**
			 * Watch for 'active' attribute changes
			 */
			lastform.waypoints[i].watch('active', function (id, oldval, newval) {
				// Just activated
				if ( oldval === false && newval === true ) {
					// Inactivate other elements
					$.grep(lastform.waypoints, function(obj){
						if (obj.active === true) {
							obj.active = false;
						}
					});
					$(document).trigger('lastformFieldWasActivated', this);
				} else if ( oldval === true && newval === false ) {
					$(document).trigger('lastformFieldWasDeactivated', this);
				}
				return newval;
			});
			/**
			 * Enable visible elements
			 */
			if ($(lastform.waypoints[i].element).is(':visible')) {
				lastform.waypoints[i].enable();
			}
		}
		$(document).trigger('lastformWaypointsWasInitialized');
	}


})( jQuery );
