<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       http://meydjer.com
 * @since      1.0.0
 *
 * @package    Lastform
 * @subpackage Lastform/public/partials
 */

// Load form display class.
require_once( GFCommon::get_base_path() . '/form_display.php' );

// Get form ID.
$form_id = absint( get_query_var('lastform') );

// Get form object.
$form = GFFormsModel::get_form_meta( $form_id );

// Get form options
$options = lastform_addon()->get_form_settings( $form );

$start_button_text = (!empty($options['welcome-start-button-text'])) ? $options['welcome-start-button-text'] : esc_attr__('Start', 'lastform')

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
  <head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php if ( ! empty($form['description']) ) : ?>
		<meta name="description" content="<?php echo $form['description'] ?>">
	<?php endif ?>
	<title><?php echo apply_filters('lastform_public_display_page_title', $form['title'], $form_id) ?></title>
	<?php if (!empty($options['favicon-url'])) : ?>
		<link rel="icon" href="<?php echo $options['favicon-url'] ?>">
	<?php endif ?>
	<?php
		/**
		 * Scripts
		 */
		if ( ! empty( $form ) ) {
			GFFormDisplay::enqueue_form_scripts( $form );
		}

		wp_print_head_scripts();

		/**
		 * Styles
		 */
		$styles = apply_filters( 'lastform_public_display_styles', array('lastform', 'google-fonts'), $form );

		if ( ! empty( $styles ) ) {
			$return = wp_print_styles( $styles );
		}

		Lastform_Public::print_form_inline_style($form);

	?>
	<?php if (!empty($options['custom-html-code'])) echo $options['custom-html-code']; ?>

	<?php if (!empty($options['custom-css-code'])) : ?>
	<style>
		<?php echo $options['custom-css-code'] ?>
	</style>
	<?php endif ?>

	<?php if (!empty($options['custom-js-code'])) : ?>
	<script  type="text/javascript">
		<?php echo $options['custom-js-code'] ?>
	</script>
	<?php endif ?>
</head>
<body>
	<div class="lf-preloader">
		<div class="lf-preloader-animation">
			<div class="lf-preloader-text">
				<?php esc_attr_e('Loading', 'lastform') ?>
			</div><?php // <!-- /.lf-preloader-text --> ?>
		</div><?php // <!-- /.lf-preloader-animation --> ?>
	</div><?php // <!-- /.lf-preloader --> ?>
	<div class="lf-bg"></div>

	<?php if (isset($options['welcome-enabled']) && $options['welcome-enabled']) : ?>
	<div class="lf-welcome">
		<div class="lf-welcome-content scrollbar-macosx">
			<div class="lf-welcome-container">
				<?php if (!empty($options['welcome-image-url'])) : ?>
					<img src="<?php echo $options['welcome-image-url'] ?>" class="lf-welcome-image">
				<?php endif ?>

				<?php if (!empty($options['welcome-text'])) : ?>
					<div class="lg-welcome-text">
						<?php echo wpautop($options['welcome-text']) ?>
					</div><?php // <!-- /.lg-welcome-text --> ?>
				<?php endif ?>

				<div class="lf-welcome-start-button-wrapper desktop">
					<a href="javascript:void(0)" class="lf-welcome-start-button" id="lf-welcome-start-button">
						<?php echo $start_button_text ?>
					</a>
					<span><?php esc_attr_e('press', 'lastform') ?> <strong><?php esc_attr_e('ENTER', 'lastform') ?></strong></span>
				</div><?php // <!-- /.lf-welcome-start-button-wrapper --> ?>
			</div><?php // <!-- /.lf-welcome-container --> ?>
		</div><?php // <!-- /.lf-welcome-content --> ?>
		<div class="lf-welcome-start-button-wrapper mobile">
			<a href="javascript:void(0)" class="lf-welcome-start-button" id="lf-welcome-start-button">
				<?php echo $start_button_text ?>
			</a>
			<span><?php esc_attr_e('press', 'lastform') ?> <strong><?php esc_attr_e('ENTER', 'lastform') ?></strong></span>
		</div><?php // <!-- /.lf-welcome-start-button-wrapper --> ?>
	</div><?php // <!-- /.lf-welcome --> ?>
	<?php endif ?>

	<?php echo GFFormDisplay::get_form( $form_id ); ?>

	<?php $progress_bar_type = (!empty($options['progress-box-type'])) ? $options['progress-box-type'] : 'percentage' ?>
	<?php if ($progress_bar_type != 'none') : ?>
	<div class="lf-progress-box">
		<div class="lf-progress-bar">
			<div class="lf-progress-bar-fill"></div>
		</div><?php // <!-- /.lf-progress-bar --> ?>
		<div class="lf-progress-text lf-progress-<?php echo $progress_bar_type ?>"></div>
	</div><?php // <!-- /.lf-progress-box --> ?>
	<?php endif ?>

	<div class="lf-nav-arrows">
		<div class="lf-nav-arrow-up">
			<i class="lfi-keyboard_arrow_up"></i>
		</div><?php // <!-- /.lf-nav-arrow-up --> ?>
		<div class="lf-nav-arrow-down">
			<i class="lfi-keyboard_arrow_down"></i>
		</div><?php // <!-- /.lf-nav-arrow-down --> ?>
	</div><?php // <!-- /.lf-nav --> ?>
	<?php
	wp_print_footer_scripts();
	?>
  </body>
</html>
