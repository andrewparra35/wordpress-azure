<?php
/*
Plugin Name: Rcwd Upload for Gravity Forms
Plugin URI: 
Description: the Rcwd Upload field for Gravity Forms that let you upload with no use of wp media upload.
Version: 1.1.7.0
Author: Roberto Cantarano
Author URI: http://www.cantarano.com
License: You should have purchased a license from http://codecanyon.net/ plugin download page
Copyright: 2013 Roberto Cantarano (email : roberto@cantarano.com) 
*/

// UNCOMMENT THIS BLOCK ONLY FOR DEBUG

/* 
ini_set('display_errors', '1');
ini_set('error_reporting', E_ALL);
*/

if(preg_match('#' . basename(__FILE__) . '#', $_SERVER['PHP_SELF'])) { die('Hello :)'); }

require_once(plugin_dir_path( __FILE__ ).'updater.php');
require_once(plugin_dir_path( __FILE__ ).'updater-manager.php');
require_once(plugin_dir_path( __FILE__ ).'common.php');
require_once(plugin_dir_path( __FILE__ ).'rules.php');

if(is_admin())
	include_once('envato/envato.api.class.php');

class gforms_rcwdupload_plugin{

	private static $post;

	public $version = '1.1.7.0';
	
	static $gfurclass 	= '';
	static $gfurd 		= '';
	static $rnm_search	= '';

	function __construct(){

		$settings = array(
		
			'version' 	=> $this->version,
			'basename' 	=> plugin_basename(__FILE__)
							
		);
		
		$upf = wp_upload_dir();

		if(!defined('RCWD_DS'))
			define( 'RCWD_DS', DIRECTORY_SEPARATOR );
							
		define( 'GFORMS_RCWDUPLOAD_NAME', 'gravityforms-rcwdupload/gravityforms-rcwdupload.php' );
		define( 'GFORMS_RCWDUPLOAD_TITLE', 'Rcwd Upload for Gravity Forms' );
		define( 'GFORMS_RCWDUPLOAD_UP_TEMP_DIR', $upf['basedir'].RCWD_DS.'gformsrcwduploads_temp' );
		define( 'GFORMS_RCWDUPLOAD_UP_DIR', $upf['basedir'].RCWD_DS.'gformsrcwduploads' );
		define( 'GFORMS_RCWDUPLOAD_UP_TEMP_URL', $upf['baseurl'].'/gformsrcwduploads_temp' );
		define( 'GFORMS_RCWDUPLOAD_UP_URL', $upf['baseurl'].'/gformsrcwduploads' );

		define( 'GFORMS_RCWDUPLOAD_DEBUG', false );

		register_activation_hook( $settings['basename'], array( $this, 'activate' ) );
		register_deactivation_hook( $settings['basename'], array( $this, 'deactivate' ) );
		add_action( 'GFRcwdUploadCheckit', array( 'GFRcwdCommon', 'checkit' )); 
	
		load_plugin_textdomain( 'gforms-rcwdupload', false, dirname(plugin_basename( __FILE__ )).RCWD_DS.'lang' );

		$v = get_site_option('gforms_rcwdupload_version');
		
		if(empty($v)){
			
			update_site_option( 'gforms_rcwdupload_version', $this->version );
			
			$new = get_site_option('gforms_rcwdupload_nv');
			
			if(empty($new))
				update_site_option( 'gforms_rcwdupload_nv', true );
			
		}
				
		add_action( 'admin_menu', array( $this, 'admin_menu' ), 11 );

		if(!GFRcwdCommon::serial_is_valid()){
			
			add_action( 'admin_notices', array( 'GFRcwdCommon', 'error_not_authenticated' ) );
			
			return false;
			
		}
		
		add_filter( 'init', array( $this, 'init' ) );
		
		if(!class_exists('GF_Field')){
			
			add_filter( 'gform_add_field_buttons', array( $this, 'gform_add_field_buttons' ) );
			add_filter( 'gform_field_type_title', array( $this, 'gform_field_type_title' ) );
			add_action( 'gform_field_input',  array( $this, 'gform_field_input' ), 11, 5 );
		
		}
		
		//add_filter( 'gform_save_field_value', array( $this, 'save_field_value' ), 10, 4 );
		add_filter( 'gform_entries_field_value', array( $this, 'entries_field_value' ), 10, 4 );
		add_filter( 'gform_entry_field_value', array( $this, 'entry_field_value' ), 10, 4 );
		add_filter( 'gform_tooltips', array( $this, 'tooltips' ) );
		add_filter( 'gform_pre_validation', array( $this, 'pre_validation' ));
		add_filter( 'gform_field_validation', array( $this, 'field_validation' ), 10, 4 );
		add_filter( 'gform_get_input_value', array( $this, 'get_input_value' ), 10, 4 );
		add_filter( 'gform_merge_tag_filter', array( $this, 'merge_tag_filter' ), 10, 5 );
		add_filter( 'gform_entry_post_save', array( $this, 'entry_post_save' ), 10, 2 );
		add_filter( 'gform_allowable_tags', array( $this, 'allowable_tags' ), 10, 3 );
	//	add_filter( 'gform_pre_render', array( $this, 'gform_pre_render' ) );
		add_filter( 'gform_trim_input_value', array( $this, 'gform_trim_input_value' ), 10, 3 );
		add_filter( 'gform_submission_values_pre_save', array( $this, 'gform_submission_values_pre_save' ), 10, 2 ); // FOR "SAVE & CONTINUE LATER" FEATURE
		add_filter( 'gform_noconflict_styles', array( $this, 'gform_noconflict_styles' ) );
		add_action( 'gform_post_data', array( $this, 'gform_post_data'), 9, 3 );
		add_action( 'admin_enqueue_scripts',  array( $this, 'enqueue_scripts' ) );
		add_action( 'gform_enqueue_scripts',  array( $this, 'enqueue_scripts' ), 10, 2 );
		add_action( 'gform_editor_js', array( $this, 'editor_js' ) );	
		add_action( 'gform_field_standard_settings', array( $this, 'rcwdupload_settings' ), 10, 2 );	
		add_action( 'gform_editor_js_set_default_values', array( $this, 'editor_js_set_default_values' ) );
		add_action( 'gform_admin_pre_render', array( $this, 'gform_admin_pre_render' ) );
		add_action( 'gform_field_css_class', array( $this, 'css_class' ), 10, 3 );
		add_action( 'admin_enqueue_scripts', array($this, 'admin_styles') );
		add_action( 'gform_preview_styles', array($this, 'preview_styles'), 10, 2 );
		add_action( 'gform_delete_lead', array( $this, 'gform_delete_lead' ) );
		add_action( 'gform_delete_entries', array( $this, 'gform_delete_entries' ) , 10, 2 );

		add_action( 'generate_rewrite_rules', array( 'GFRcwdRules', 'generate_rewrite_rules' ) );	
		add_action( 'init', array( 'GFRcwdCommon', 'clean_temp' ) );	
		add_action( 'init', array( 'GFRcwdCommon', 'handle_upload_request' ) );	
		add_action( 'admin_head', array( $this, 'gform_admin_head' ) );
		add_filter( 'gform_get_field_value', array( $this, 'gform_get_field_value' ), 10, 3 );
		
		// GFORMS STICKY LIST PLUGIN _____________________________________________________________________________

			add_filter( 'filter_entries', array( $this, 'filter_entries' ) );

		// GFORMS USER REGISTRATION PLUGIN _______________________________________________________________________

			add_action( 'gform_user_registered', array( $this, 'gform_user_registered' ), 10, 3 );
			add_action( 'gform_user_updated', array( $this, 'gform_user_updated' ), 10, 4 );			

			if( defined('GF_USER_REGISTRATION_VERSION') and version_compare( GF_USER_REGISTRATION_VERSION, '3', '>=' ) ){

				self::$gfurclass	= 'GF_User_Registration';
				self::$gfurd		= 'new';

			}else{
				
				self::$gfurclass	= 'GFUserData';
				self::$gfurd		= 'old';
				
			}

		// WOOCOMMERCE FILTERS ___________________________________________________________________________________
		
			add_filter( 'woocommerce_gforms_order_meta_value', array( $this, 'woocommerce_gforms_order_meta_value' ), 11, 6 );
			add_filter( 'woocommerce_gforms_strip_meta_html', array( $this, 'woocommerce_gforms_strip_meta_html' ), 11, 7 );
			add_filter( 'woocommerce_get_item_data', array( $this, 'woocommerce_get_item_data' ), 11, 2 ); // ITEM DATA IN CART

		// GFORM UPDATE POST HOOKS ______________________________________________________________________________
		
			if(class_exists('gform_update_post'))
				add_action( 'gform_update_post/setup_form', array( $this, 'gform_update_post_setup_form' ) );
			
		// GRAVITY VIEW HOOKS ______________________________________________________________________________
		
			add_filter( 'gravityview_view_entries', array( $this, 'gravityview_view_entries' ), 11, 2 ); 
			add_filter( 'gravityview/field_output/context/value', array( $this, 'gravityview_field_output_context_value' ), 11, 2 ); 
		
		// ______________________________________________________________________________________________________
			
        $version_info 	= GFCommon::get_version_info();
        $version 		= rgar( $version_info, "version" );

		if(version_compare(GFCommon::$version, '1.8.3', '<'))
			if( is_admin() and function_exists('rgpost') and class_exists('GFCommon') ){
				
				global $wpdb;	
				
				 $wpdb->query("ALTER TABLE {$wpdb->prefix}rg_lead_detail MODIFY value text");
				
			}
			
		if(version_compare(GFCommon::$version, '1.8.6', '<'))
			if( is_admin() and function_exists('rgpost') and class_exists('GFCommon') and GFCommon::current_user_can_any("gravityforms_delete_entries") and rgpost("button_delete_permanently") )
				if(@isset($_GET['id']))
					$this->gform_delete_entries( (int)$_GET['id'], 'trash' );

		if(is_admin()){
			
			$updater = new GFRcwdUpdater();
		
			$updater->init();

			new GFRcwdUpdaterManager( $settings['version'], GFORMS_RCWDUPLOAD_NAME );
		
		}

	}
	
	function filter_entries($entries){
		
		$form_id 	= $entries[0]['form_id'];
		$form 		= GFAPI::get_form($form_id);
		$fields		= $form['fields'];
		
		foreach($entries as $ekey => $entry){
			
			foreach($fields as $fkey => $field){
				
				if($field->type == 'rcwdupload'){
	
					$fid = $field->id;
					
					if(isset($entry[$fid]))
						$entries[$ekey][$fid] = GFRcwdCommon::format_value(array(
							
							'value' 	=> $entry[$fid],
							'lead' 		=> $entry,
							'field' 	=> $field,
							'form_id' 	=> $form_id
						
						));	
					
				}
				
			}
			
		}
		
		return $entries;
		
	}

	function gravityview_field_output_context_value( $value, $args ){
		
		$fields 	= $args['form']['fields'];
		$mode		= apply_filters( 'gforms_rcwdupload_gravityview_entry_mode', '', $args, $args['form'] );	
		
		foreach($fields as $fkey => $field){
			
			if( $field->type == 'rcwdupload' and $field->id == $args['field']['id'] ){

				$item = GFRcwdCommon::format_value(array(
					
					'value' 	=> $value,
					'lead' 		=> $args['entry'],
					'field' 	=> $field,
					'form_id' 	=> $args['entry']['form_id'],
					'source'	=> 'gravityview',
					'mode'		=> $mode
				
				));	
				
				$value = apply_filters( 'gforms_rcwdupload_gravityview_item', $item, $args, $form );	
				
			}
			
		}
			
		return $value;
		
	}
	
	function gravityview_get_entries( $parameters, $args, $form_id ){
		
		
		
	}
	
	
	function gravityview_view_entries( $entries, $args ){

		$post_id 		= $args['id'];
		$template_id	= GVCommon::get_meta_template_id($post_id);
		
		if( $template_id == 'datatables_table' and count($entries) > 0 ){
			
			$form_id	= $entries[0]['form_id'];
			$form 		= GFAPI::get_form($form_id);
			$fields		= $form['fields'];
			$mode		= apply_filters( 'gforms_rcwdupload_gravityview_entry_mode', '', $args, $entries[0]['form_id']);
			$rcwdfields	= array();

			foreach($fields as $key => $field)
				if($field->type == 'rcwdupload')
					$rcwdfields[$key] = $field;
		
			if(count($rcwdfields) > 0){
									
				foreach($entries as $ekey => $entry){
								
					foreach($rcwdfields as $rfkey => $rcwdfield){
						
						$item = GFRcwdCommon::format_value(array(
					
							'value' 	=> $entries[$ekey][$rfkey],
							'lead' 		=> $entry,
							'field' 	=> $rcwdfield,
							'form_id' 	=> $form_id,
							'source'	=> 'gravityview',
							'mode'		=> $mode
						
						));	
						
						$entries[$ekey][$rfkey] = apply_filters( 'gforms_rcwdupload_gravityview_item', $item, $args, $form );
						
					}
					
				}
				
			}
			
		}

		return $entries;
		
	}	
		
	function gform_get_field_value( $value, $lead, $field ){
	
		return $value;
		
	}
	
	function init(){

		self::$rnm_search	= array( '[form_id]', '[field_id]', '[lead_id]', '[fieldlabel]', '[field:ID]' );
		$rnm_search			= (array)apply_filters( 'gforms_rcwdupload_rename_tags', array() );
		
		if(count($rnm_search) > 0)
			self::$rnm_search = array_merge( self::$rnm_search, $rnm_search );
		
		if( class_exists("GFUser") or class_exists("GF_User_Registration") ){
		
			if(self::$gfurd == 'old'){	
		
				remove_action( "gform_after_submission", array( "GFUser", "gf_create_user" ), 10, 2 );
				add_action( "gform_entry_created", array( "GFUser", "gf_create_user" ), 10, 2 );
		
			}
		
		}
		
	}
	
	function gform_submission_values_pre_save( $submitted_values, $form ){

		foreach ( $form['fields'] as $field ){
			
			$field = (array)$field;
			
			if($field['type'] == 'rcwdupload'){
				
				$field_id 						= $field['id'];
				$value 							= $submitted_values[$field_id];
				$value['rndfldr']				= $_POST['rcwdupload_rndfldr'];
				$value				 			= maybe_serialize(GFRcwdCommon::field_value_correction( $value, $field ));
				$submitted_values[$field_id] 	= $value;
			}
			
		}

		return $submitted_values;
		
	}
	
	function gform_update_post_setup_form($args = array()){

		if (is_numeric($args)){
			
			$post_id = $args;
			$form_id = false;
			
		}elseif(is_array($args)){
			
			$defaults = array(
			
				'post_id' => 0,
				'form_id' => 0
				
			);
			
			$args = wp_parse_args( $args, $defaults );
			
			extract($args);
			
		}else
			return false;
		
		if( !$post_id and ! empty($GLOBALS['post']->ID) )
			$post_id = $GLOBALS['post']->ID;
		
		self::$post = get_post($post_id);
		
		if(is_object(self::$post)){		
		
			if($form_id)
				add_filter( 'gform_pre_render_'.$form_id, array( $this, 'gform_update_post_gform_pre_render' ) );
		
		}
				
	}

	public static function gform_update_post_gform_pre_render($form){
	
		$entry_ID 	= get_post_meta( self::$post->ID, '_gform-entry-id', true );
		$lead 		= GFRcwdCommon::get_lead($entry_ID);

		foreach($form['fields'] as $key => $field ){
		
			$field = (array)$field;
			
			if($field['type'] == 'rcwdupload'){
			
				$field_id 								= $field['id'];
				$form['fields'][$key]['defaultValue'] 	= $lead[$field_id];
	
			}
		
		}
		
		return $form;
		
	}
	
	public function gform_post_data( $post_data, $form, $entry ){ // COMPATIBILITY GFORMS UPDATE POST PLUGIN
		
		foreach($form['fields'] as $field){
			
			$field = (array)$field;
			
			if($field['type'] == 'rcwdupload'){
				
				$field_id	= $field['id'];
				$value 		= rgar( $entry, $field_id );

				if($value != '')
					$value = maybe_unserialize($value);
				else
					$value = array('');
				
				if(is_object(self::$post))	 // COMPATIBILITY GFORMS UPDATE POST PLUGIN
					if( !empty($value) and !empty($value[0])and isset($value[0]['file']) )
						update_post_meta( self::$post->ID, sanitize_title('_gforms_rcwdupload_'.$field['label']), $value );
					else
						delete_post_meta( self::$post->ID, sanitize_title('_gforms_rcwdupload_'.$field['label']) );
				
			}
			
		}
		
		return $post_data;
		
	}
	
	function woocommerce_gforms_order_meta_value( $display_value, $field, $lead, $form_meta, $item_id, $cart_item ){
		
		$field = (array)$field;
		
		if($field['type'] == 'rcwdupload'){
			
			$display_value 	= htmlspecialchars_decode($display_value);
			$item 			= maybe_unserialize($display_value);

			if(is_array($item) and count($item) > 0){
						
				if(is_array($item) and isset($item[0]['file']) and isset($item[0]['title']) and isset($item[0]['form_id']) and isset($item[0]['field_id']) and isset($item[0]['entry_id']) ){
											
					$entry_id 		= $item[0]['entry_id'];
					$form_id 		= $item[0]['form_id'];
					$form			= RGFormsModel::get_form_meta($form_id);
					$field 			= GFFormsModel::get_field( $form, $item[0]['field_id'] );
					$lead 			= GFRcwdCommon::get_lead($item[0]['entry_id']);			
					$display_value	= GFRcwdCommon::format_value(array(	'value' 	=> $display_value,
																		'lead' 		=> $lead,
																		'field' 	=> $field,
																		'form_id' 	=> $form_id ));			
	
				}else
					$display_value = '';
				
			}else
				$display_value = '';
			
		}	
		
		return $display_value;
		
	}

	function woocommerce_gforms_strip_meta_html( $strip_html, $display_value, $field, $lead, $form_meta, $item_id, $cart_item ){

		$field = (array)$field;
		
		if($field['type'] == 'rcwdupload')
			return false;
			
	}
		
	function woocommerce_get_item_data( $other_data, $cart_item ){ 
		
		if(isset($cart_item['_gravity_form_lead']) && isset($cart_item['_gravity_form_data'])){

			$gravity_form_data 	= $cart_item['_gravity_form_data'];
			$form_meta 			= RGFormsModel::get_form_meta($gravity_form_data['id']);
			
/*			if(isset($form_meta['fields'])){
				
				foreach($form_meta['fields'] as $fld){
					
					$fld = (array)$fld;
					
					if($fld['type'] == 'rcwdupload'){}
					
				}
				
			}*/

			if(!empty($form_meta)){
							
				if(is_array($other_data) and count($other_data) > 0){
					
					foreach($other_data as $keydata => $data){
						
						$data['value'] = htmlspecialchars_decode($data['value']);
						$item = maybe_unserialize($data['value']);
						
						if(is_array($item) and count($item) > 0){
						
							if(is_array($item) and isset($item[0]['file']) and isset($item[0]['title']) and isset($item[0]['form_id']) and isset($item[0]['field_id']) and isset($item[0]['entry_id']) ){

								$entry_id 	= $item[0]['entry_id'];
								$form_id 	= $item[0]['form_id'];
								$form		= RGFormsModel::get_form_meta($form_id);
								$field 		= GFFormsModel::get_field( $form, $item[0]['field_id'] );
								$lead 		= GFRcwdCommon::get_lead($item[0]['entry_id']);
								$value 		= GFRcwdCommon::format_value(array(	'value' 	=> $data['value'],
																				'lead' 		=> $lead,
																				'field' 	=> $field,
																				'form_id' 	=> $form_id ));
											
								$other_data[$keydata]['display']	= $value;								
								$other_data[$keydata]['value'] 		= $value;	

							}
														
						}				
						
					}
	
				}
			
			}
		
		}
		
		return $other_data;
		
	}
	
	function activate(){ 

		$v = get_site_option('gforms_rcwdupload_version');
		
		if(empty($v)){
			
			update_site_option( 'gforms_rcwdupload_version', $this->version );
			
			$new = get_site_option('gforms_rcwdupload_nv');
			
			if(empty($new))
				update_site_option( 'gforms_rcwdupload_nv', true );
			
		}
				
		update_site_option( 'gforms_rcwdupload_version', $this->version );
		
		wp_schedule_event( time(), 'daily', 'GFRcwdUploadCheckit' );
		
		GFRcwdRules::flush_rules();	
		
	}

	function deactivate(){
		
		wp_clear_scheduled_hook('GFRcwdUploadCheckit');
		
	}

	function admin_menu(){
		
		$page = add_submenu_page( 'gf_edit_forms', __( 'Rcwd Upload settings', 'gforms-rcwdupload' ), __( 'Rcwd Upload settings', 'gforms-rcwdupload' ), 'manage_options', 'gforms-rcwdupload', array( $this, 'settings' ) );
				
	}

	function settings(){
		
		include_once('envato/check.php');
		
	}
		
	function gform_add_field_buttons($field_groups){
		
		foreach( $field_groups as $key => $group ){
			
        	if( $group["name"] == "standard_fields" ){
				
				$field_groups[$key]["fields"][] = array(	'class'		=> 'button',
															'value'		=> __('RCWD Uploader', 'gforms-rcwdupload'),
															'onclick'	=> 'StartAddField(\'rcwdupload\');' );
				break;		
					
			}
		
		}
		return $field_groups;
		
	} 

	function gform_field_type_title($type){
		
		if ( $type == 'rcwdupload' )
			return __( 'RCWD Uploader' , 'gforms-rcwdupload' );
			
	}

	function gform_noconflict_styles($objs){
		
		$objs[] = 'gforms-rcwdupload-admin-style';
		
		return $objs;
		
	}
	
	function admin_styles(){
		
		$page = GFForms::get_page();

		if($page == 'form_editor')
			wp_enqueue_style( 'gforms-rcwdupload-admin-style', GFRcwdCommon::get_dir(__FILE__).'css/admin-style.css');			
		
	}
	
/*	function head(){
		
?>
		<script type="text/javascript">
            gforms_rcwdupload_url 					= '<?php echo admin_url('/?gformsrcwdupload') ?>';
            gforms_rcwdupload_flash_swf_url 		= '<?php echo GFRcwdCommon::get_dir(__FILE__) ?>/js/jquery/plupload/plupload.flash.swf';
            gforms_rcwdupload_silverlight_xap_url 	= '<?php echo GFRcwdCommon::get_dir(__FILE__) ?>/js/jquery/plupload/plupload.silverlight.xap';
        </script>
<?php

	}*/
	
	function enqueue_scripts( $form = '', $ajax = ''){
		
		global $pagenow;
		
		if(IS_ADMIN){

			if( $pagenow == 'admin.php' and isset($_GET['page']) and $_GET['page'] == 'gf_entries' and isset($_GET['view']) and $_GET['view'] == 'entry' ){

				if( ( ( isset($_POST['entry_id']) or isset($_GET['lid']) ) and isset($_POST['gforms_save_entry']) ) or (  isset($_GET['screen_mode']) and $_GET['screen_mode'] == 'edit' and isset($_GET['lid']) and is_numeric($_GET['lid']) ) ){

				$form_id 	= $_GET['id'];
				$form		= GFFormsModel::get_form_meta_by_id($form_id);
				$form		= (array)$form[0];
				
				}else
					return false;
	
			}else
				return false;
		
		}

		foreach ( $form['fields'] as $field ){
			
			if($field['type'] == 'rcwdupload'){

				$defaults 	= array(
				
					'rcwdupload_sizelimit'		=>  '',
					'rcwdupload_sizelimit_type'	=>  'kb'
				
				);
				
				$field			= array_merge( $defaults, (array)$field );
				$sizelimit 		= $field['rcwdupload_sizelimit'];
				$sizelimit_type	= $field['rcwdupload_sizelimit_type'];
				$maxfiles 		= 1;
				
				if((int)$sizelimit == 0)
					if($sizelimit_type == 'kb')
						$sizelimit = round( (int)wp_max_upload_size() / 1024 );
					else
						$sizelimit = round( (int)wp_max_upload_size() / 1024 / 1024 );
					
				if($sizelimit_type == 'kb')
					$max_file_size	= $sizelimit.'KB';
				else
					$max_file_size	= $sizelimit.'MB';

				global $rcwdupload_gform_admin_enqueue_scripts;
				
				if(empty($rcwdupload_gform_admin_enqueue_scripts)){	
												
					wp_enqueue_script('jquery');
					wp_enqueue_script( 'gforms-rcwdupload-scripts', GFRcwdCommon::get_dir(__FILE__).'js/scripts.js', array('jquery') );
					wp_enqueue_script( 'rcwdupload-plupload', GFRcwdCommon::get_dir(__FILE__).'js/jquery/plupload/plupload.full.min.js', array('jquery'), '2.1.8' );

					wp_enqueue_script( 'gforms-rcwdupload-impromptu', GFRcwdCommon::get_dir(__FILE__).'js/jquery/impromptu/jquery-impromptu.min.js', array('jquery'), '5.2.5' );
					wp_enqueue_style( 'gforms-rcwdupload-impromptu', GFRcwdCommon::get_dir(__FILE__).'js/jquery/impromptu/jquery-impromptu.min.css');	

					wp_enqueue_script( 'gforms-rcwdupload-cropper', GFRcwdCommon::get_dir(__FILE__).'js/jquery/cropper/cropper.min.js', array('jquery'), '2.3.4' );
					wp_enqueue_style( 'gforms-rcwdupload-cropper', GFRcwdCommon::get_dir(__FILE__).'js/jquery/cropper/cropper.min.css');
										 			
					wp_enqueue_style( 'gform_font_awesome' );
					
					wp_enqueue_script('jquery-ui-sortable'); 
					//wp_enqueue_script('jquery-ui-dialog'); 
					
					wp_enqueue_style( 'gforms-rcwdupload-jqueryui', GFRcwdCommon::get_dir(__FILE__).'css/jquery-ui-custom.min.css');	
					wp_enqueue_style( 'gforms-rcwdupload-style', GFRcwdCommon::get_dir(__FILE__).'css/style.css');	
					//wp_enqueue_style('wp-jquery-ui-dialog');
				
					$rcwdupload_gform_admin_enqueue_scripts = 1;
					
				}
					
				$i18n = array(	'err' 					=>  __( 'We have a problem...', 'gforms-rcwdupload' ),
								'err600' 				=> sprintf( __( 'Sorry, the file size must not be greater than %s. Please try another file.', 'gforms-rcwdupload' ), $max_file_size ),
								'err601' 				=> __( 'Sorry, the file extension is not permitted. Please try another file.', 'gforms-rcwdupload' ),
								'errqueue' 				=> __( 'It seems that some files need to be uploaded. Please check the upload fields.', 'gforms-rcwdupload' ),
								'queued'				=> __( 'queued', 'gforms-rcwdupload' ),
								'processing'			=> __( 'wait...', 'gforms-rcwdupload' ),
								//'url'					=> site_url('/?gformsrcwdupload'),
								'url'					=> site_url().'/wp-content/plugins/gravityforms-rcwdupload/upload.php?a=a',
								'pluginurl'				=> GFRcwdCommon::get_dir(__FILE__),
								'thumburl'				=> GFRcwdCommon::get_dir(__FILE__).'includes/PHPThumb/thumb.php',
								'flash_swf_url'			=> GFRcwdCommon::get_dir(__FILE__).'js/jquery/plupload/Moxie.swf',
								'silverlight_xap_url'	=> GFRcwdCommon::get_dir(__FILE__).'js/jquery/plupload/Moxie.xap',
								
				);

				wp_localize_script( 'gforms-rcwdupload-scripts', 'gformsrcwdi18n'.$form['id'].'_'.$field['id'], $i18n );
									
			}
			
		}	
			
	}

	function preview_styles( $styles, $form ){
		
		wp_register_style( 'gforms-rcwdupload-style', GFRcwdCommon::get_dir(__FILE__).'css/style.css');	
		$styles = array('gforms-rcwdupload-style');
		return $styles;
		
	}
	
	function editor_js(){

		$defaults = array(	'filetitle'    				=>  false,
							'rename'					=>  '',
							'clientpreview'	 			=>  'N',
							'clientpreview_max_width'	=>  150,
							'clientpreview_max_height'	=>  150,
							'clientpreview_crop'		=>  'N',
							'preview'	 				=>  'N',
							'preview_max_width'			=>  150,
							'preview_max_height'		=>  150,
							'preview_crop'				=>  'N',
							'repeater'    				=>  'N',
							'repeater_limit'   			=>  0,
							'repeater_min'   			=>  0,
							'repeater_sortable'   		=>  'N',
							'filter'    				=>  'Y',
							'filter_images'				=>  'jpg,gif,png,jpeg',
							'filter_docs'   			=>  'pdf,doc,docx,xml,txt,xls,xlsx',
							'filter_compr'				=>  'zip,rar,ace',
							'filter_others'				=>  '',
							'resize'					=>  'N',
							'resize_max_width'			=>  '0',
							'resize_max_height'			=>  '0',
							'resize_crop'				=>  'N',
							'max_quality'				=>  '90',
							'csresize'					=>  'N',
							'autoupload'				=>  'N',
							'hidebrowse'				=>  'N',
							'chunks'					=>  0,
							'chunks_max_retries'		=> 3,
							'sizelimit'					=>  '',
							'sizelimit_type'			=>  'kb' );
										
?>
		<script type='text/javascript'>		

			jQuery(document).ready(function($){

				fieldSettings["rcwdupload"] = '.label_setting, .admin_label_setting, .description_setting, .error_message_setting, .rules_setting, .visibility_setting, .css_class_setting, .conditional_logic_field_setting, .rcwdupload_settings';

				 $(document).bind("gform_load_field_settings", function(event, field, form){

					if(typeof field.rcwdupload_filetitle == "undefined")
						$("#field_rcwdupload_filetitle").attr( "checked", false );
					else
						$("#field_rcwdupload_filetitle").attr( "checked", field.rcwdupload_filetitle == true );

					if(typeof field.rcwdupload_rename == "undefined")
						$('#field_rcwdupload_rename').val('<?php echo $defaults['rename'] ?>');
					else
					  	$('#field_rcwdupload_rename').val(field.rcwdupload_rename);

					$('.rcwdupload_settings span.gformsrcwdupload_rename_tag').click(function(event){

						var range = document.createRange();
						
						range.selectNodeContents(this);
						
						window.getSelection().addRange(range);
						
					});
											
					if(typeof field.rcwdupload_clientpreview == "undefined")
						$('#field_rcwdupload_clientpreview').val('<?php echo $defaults['clientpreview'] ?>');
					else
					  	$('#field_rcwdupload_clientpreview').val(field.rcwdupload_clientpreview);

					if($('.rcwdupload_settings .field_rcwdupload_clientpreview_choose').val() == 'Y')
						$('.rcwdupload_settings .gformsrcwdupload_clientpreview_fields').fadeTo( 300, 1 );
													
					$('.rcwdupload_settings .field_rcwdupload_clientpreview_choose').on("change", function(event){
						
						if($(this).val() == 'Y')
							$('.rcwdupload_settings .gformsrcwdupload_clientpreview_fields').fadeTo( 300, 1 );
						else{
							
							$('.rcwdupload_settings .gformsrcwdupload_clientpreview_fields').fadeTo( 300, 0, function(){
								
								$(this).css( 'display', 'none' );
								
							});
							
						}
						
					});

					if(typeof field.rcwdupload_clientpreview_max_width == "undefined")
						$('#field_rcwdupload_clientpreview_max_width').val('<?php echo $defaults['clientpreview_max_width'] ?>');
					else
					  	$('#field_rcwdupload_clientpreview_max_width').val(field.rcwdupload_clientpreview_max_width);

					if(typeof field.rcwdupload_clientpreview_max_height == "undefined")
						$('#field_rcwdupload_clientpreview_max_height').val('<?php echo $defaults['clientpreview_max_height'] ?>');
					else
					  	$('#field_rcwdupload_clientpreview_max_height').val(field.rcwdupload_clientpreview_max_height);

					if(typeof field.rcwdupload_clientpreview_crop == "undefined")
						$('#field_rcwdupload_clientpreview_crop').val('<?php echo $defaults['clientpreview_crop'] ?>');
					else
					  	$('#field_rcwdupload_clientpreview_crop').val(field.rcwdupload_clientpreview_crop)

					if(typeof field.rcwdupload_preview == "undefined")
						$('#field_rcwdupload_preview').val('<?php echo $defaults['preview'] ?>');
					else
					  	$('#field_rcwdupload_preview').val(field.rcwdupload_preview);

					if($('.rcwdupload_settings .field_rcwdupload_preview_choose').val() == 'Y')
						$('.rcwdupload_settings .gformsrcwdupload_preview_fields').fadeTo( 300, 1 );
													
					$('.rcwdupload_settings .field_rcwdupload_preview_choose').on("change", function(event){
						
						if($(this).val() == 'Y')
							$('.rcwdupload_settings .gformsrcwdupload_preview_fields').fadeTo( 300, 1 );
						else{
							
							$('.rcwdupload_settings .gformsrcwdupload_preview_fields').fadeTo( 300, 0, function(){
								
								$(this).css( 'display', 'none' );
								
							});
							
						}
						
					});

					if(typeof field.rcwdupload_preview_max_width == "undefined")
						$('#field_rcwdupload_preview_max_width').val('<?php echo $defaults['preview_max_width'] ?>');
					else
					  	$('#field_rcwdupload_preview_max_width').val(field.rcwdupload_preview_max_width);

					if(typeof field.rcwdupload_preview_max_height == "undefined")
						$('#field_rcwdupload_preview_max_height').val('<?php echo $defaults['preview_max_height'] ?>');
					else
					  	$('#field_rcwdupload_preview_max_height').val(field.rcwdupload_preview_max_height);

					if(typeof field.rcwdupload_preview_crop == "undefined")
						$('#field_rcwdupload_preview_crop').val('<?php echo $defaults['preview_crop'] ?>');
					else
					  	$('#field_rcwdupload_preview_crop').val(field.rcwdupload_preview_crop)
										
					if(typeof field.rcwdupload_sizelimit == "undefined")
						$('#field_rcwdupload_sizelimit').val('<?php echo $defaults['sizelimit'] ?>');
					else
					  	$('#field_rcwdupload_sizelimit').val(field.rcwdupload_sizelimit);
						
					if(typeof field.rcwdupload_sizelimit_type == "undefined")
						$('#field_rcwdupload_sizelimit_type').val('<?php echo $defaults['sizelimit_type'] ?>');
					else
					  	$('#field_rcwdupload_sizelimit_type').val(field.rcwdupload_sizelimit_type)
																							
					if(typeof field.rcwdupload_repeater == "undefined")
						$('#field_rcwdupload_repeater').val('<?php echo $defaults['repeater'] ?>');
					else
					  	$('#field_rcwdupload_repeater').val(field.rcwdupload_repeater);

					if(typeof field.rcwdupload_repeater_limit == "undefined")
						$('#field_rcwdupload_repeater_limit').val('<?php echo $defaults['repeater_limit'] ?>');
					else
					  	$('#field_rcwdupload_repeater_limit').val(field.rcwdupload_repeater_limit);

					if(typeof field.rcwdupload_repeater_min == "undefined")
						$('#field_rcwdupload_repeater_min').val('<?php echo $defaults['repeater_min'] ?>');
					else
					  	$('#field_rcwdupload_repeater_min').val(field.rcwdupload_repeater_min);
						
					if(typeof field.rcwdupload_repeater_sortable == "undefined")
						$('#field_rcwdupload_repeater_sortable').val('<?php echo $defaults['repeater_sortable'] ?>');
					else
					  	$('#field_rcwdupload_repeater_sortable').val(field.rcwdupload_repeater_sortable);
																	  					 
					if(typeof field.rcwdupload_filter == "undefined")
						$('#field_rcwdupload_filter').val('<?php echo $defaults['filter'] ?>');
					else
					  	$('#field_rcwdupload_filter').val(field.rcwdupload_filter);
					 
					if(typeof field.rcwdupload_filter_images == "undefined")
						$('#field_rcwdupload_filter_images').val('<?php echo $defaults['filter_images'] ?>');
					else
					 	$('#field_rcwdupload_filter_images').val(field.rcwdupload_filter_images);
					 
					if(typeof field.rcwdupload_filter_docs == "undefined")
						$('#field_rcwdupload_filter_docs').val('<?php echo $defaults['filter_docs'] ?>');
					else
					 	$('#field_rcwdupload_filter_docs').val(field.rcwdupload_filter_docs);

					if(typeof field.rcwdupload_filter_compr == "undefined")
						$('#field_rcwdupload_filter_compr').val('<?php echo $defaults['filter_compr'] ?>');
					else
						$('#field_rcwdupload_filter_compr').val(field.rcwdupload_filter_compr);

					if(typeof field.rcwdupload_filter_others == "undefined")
						$('#field_rcwdupload_filter_others').val('<?php echo $defaults['filter_others'] ?>');
					else
					 	$('#field_rcwdupload_filter_others').val(field.rcwdupload_filter_others);					 					 					 
					 
					if(typeof field.rcwdupload_resize == "undefined")
						$('#field_rcwdupload_resize').val('<?php echo $defaults['resize'] ?>');
					else
					  	$('#field_rcwdupload_resize').val(field.rcwdupload_resize);

					if(typeof field.rcwdupload_resize_max_width == "undefined")
						$('#field_rcwdupload_resize_max_width').val('<?php echo $defaults['resize_max_width'] ?>');
					else
					  	$('#field_rcwdupload_resize_max_width').val(field.rcwdupload_resize_max_width);					  

					if(typeof field.rcwdupload_resize_max_height == "undefined")
						$('#field_rcwdupload_resize_max_height').val('<?php echo $defaults['resize_max_height'] ?>');
					else
					  	$('#field_rcwdupload_resize_max_height').val(field.rcwdupload_resize_max_height);

					if(typeof field.rcwdupload_resize_crop == "undefined")
						$('#field_rcwdupload_resize_crop').val('<?php echo $defaults['resize_crop'] ?>');
					else
					  	$('#field_rcwdupload_resize_crop').val(field.rcwdupload_resize_crop)
						
					if(typeof field.rcwdupload_resize_max_quality == "undefined")
						$('#field_rcwdupload_resize_max_quality').val('<?php echo $defaults['max_quality'] ?>');
					else
						$('#field_rcwdupload_resize_max_quality').val(field.rcwdupload_resize_max_quality);		
									  					  					 
					if(typeof field.rcwdupload_csresize == "undefined")
						$('#field_rcwdupload_csresize').val('<?php echo $defaults['csresize'] ?>');
					else
					  	$('#field_rcwdupload_csresize').val(field.rcwdupload_csresize);

					if(typeof field.rcwdupload_autoupload == "undefined")
						$('#field_rcwdupload_autoupload').val('<?php echo $defaults['autoupload'] ?>');
					else
					  	$('#field_rcwdupload_autoupload').val(field.rcwdupload_autoupload);
						
					if($('.rcwdupload_settings .field_rcwdupload_repeater_choose').val() == 'Y'){
						$(".field_selected .gformsrcwdupload-demoadd").fadeTo( 300, 1 );
						$('.rcwdupload_settings .gformsrcwdupload_repeater_fields').fadeTo( 300, 1 );
					}
										  					  
					$('.rcwdupload_settings .field_rcwdupload_repeater_choose').on("change", function(event){						
					 	if($(this).val() == 'Y'){
							$(".field_selected .gformsrcwdupload-demoadd").fadeTo( 300, 1 );
							$('.rcwdupload_settings .gformsrcwdupload_repeater_fields').fadeTo( 300, 1 );
						}else{
							$(".field_selected .gformsrcwdupload-demoadd").fadeTo( 300, 0 );
							$('.rcwdupload_settings .gformsrcwdupload_repeater_fields').fadeTo( 300, 0, function(){
								$(this).css( 'display', 'none' );
							});							
						}
					});
					
					if($('.rcwdupload_settings .field_rcwdupload_filter_choose').val() == 'Y'){
						$('.rcwdupload_settings .gformsrcwdupload_filter_fields').fadeTo( 300, 1 );
					}
	
					$('.rcwdupload_settings .field_rcwdupload_filter_choose').on("change", function(event){
					 	if($(this).val() == 'Y'){
							$('.rcwdupload_settings .gformsrcwdupload_filter_fields').fadeTo( 300, 1 );
						}else{
							$('.rcwdupload_settings .gformsrcwdupload_filter_fields').fadeTo( 300, 0, function(){
								$(this).css( 'display', 'none' );
							});
						}
					});
	
					if($('.rcwdupload_settings .field_rcwdupload_resize_choose').val() == 'Y')
						$('.rcwdupload_settings .gformsrcwdupload_resize_fields').fadeTo( 300, 1 );
													
					$('.rcwdupload_settings .field_rcwdupload_resize_choose').on("change", function(event){
						
						if($(this).val() == 'Y')
							$('.rcwdupload_settings .gformsrcwdupload_resize_fields').fadeTo( 300, 1 );
						else{
							
							$('.rcwdupload_settings .gformsrcwdupload_resize_fields').fadeTo( 300, 0, function(){
								
								$(this).css( 'display', 'none' );
								
							});
							
						}
						
					});	

					if(typeof field.rcwdupload_hidebrowse == "undefined")
						$('#field_rcwdupload_hidebrowse').val('<?php echo $defaults['hidebrowse'] ?>');
					else
					  	$('#field_rcwdupload_hidebrowse').val(field.rcwdupload_hidebrowse);
						
/*					if($('.rcwdupload_settings .field_rcwdupload_autoupload').val() == 'Y')
						$('.rcwdupload_settings .gformsrcwdupload_autoupload_fields').fadeTo( 300, 0, function(){
								
							$(this).css( 'display', 'none' );
								
						});
													
					$('.rcwdupload_settings .field_rcwdupload_autoupload').on("change", function(event){
						
						if($(this).val() == 'N')
							$('.rcwdupload_settings .gformsrcwdupload_autoupload_fields').fadeTo( 300, 1 );
						else{
							
							$('.rcwdupload_settings .gformsrcwdupload_autoupload_fields').fadeTo( 300, 0, function(){
								
								$(this).css( 'display', 'none' );
								
							});
							
						}
						
					});*/
					
				});
																											
			});
		
		</script>
<?php	
		
	}
	
	function css_class( $classes, $field, $form ){

		$field = (array)$field;

    	if($field["type"] == "rcwdupload")
        	$classes .= " gform_rcwdupload";
   
    	return $classes;	
			
	}
	
	function tooltips($tooltips){
		
		$ttff 														= __('Enter the file extensions, separated by commas, to enable file uploading.', 'gforms-rcwdupload');
   		$tooltips["form_field_rcwdupload_filetitle"] 				= '<h6>'.__('Title', 'gforms-rcwdupload').'</h6>'.__('Check this box if you need to add a title for the file.', 'gforms-rcwdupload');  
   		$tooltips["form_field_rcwdupload_rename"] 					= '<h6>'.__('Rename', 'gforms-rcwdupload').'</h6>'.__('Change the file name, keeping the original extension.<br />If the repeater is active, a progressive numeric suffix will be added to the filename.<br /> ', 'gforms-rcwdupload').'<br>'.__('To use the tags, click the one you want to add, it will be automatically selected, then copy and paste inside the field.<br /> ', 'gforms-rcwdupload');  
		$tooltips["form_field_rcwdupload_rename"]					.= __( '<br>About the [field:ID] tag: change the ID with the numeric ID of another field.', 'gforms-rcwdupload' );
   		$tooltips["form_field_rcwdupload_clientpreview"] 			= '<h6>'.__('Image preview before upload', 'gforms-rcwdupload').'</h6>'.__('Choose YES if you want to show the image preview before upload it. It works in all modern browsers.', 'gforms-rcwdupload');  
   		$tooltips["form_field_rcwdupload_clientpreview_max_width"]	= '<h6>'.__('Width', 'gforms-rcwdupload').'</h6>'.__('Resize the image to the specified width.', 'gforms-rcwdupload');  
   		$tooltips["form_field_rcwdupload_clientpreview_max_height"]	= '<h6>'.__('Height', 'gforms-rcwdupload').'</h6>'.__('Resize the image to the specified height.', 'gforms-rcwdupload'); 
   		$tooltips["form_field_rcwdupload_clientpreview_crop"]		= '<h6>'.__('Crop', 'gforms-rcwdupload').'</h6>'.__('Crop the image to the specified size.', 'gforms-rcwdupload'); 

   		$tooltips["form_field_rcwdupload_preview"] 					= '<h6>'.__('Image preview after upload', 'gforms-rcwdupload').'</h6>'.__('Choose YES if you want to show the image preview after upload it.', 'gforms-rcwdupload');  
   		$tooltips["form_field_rcwdupload_preview_max_width"]		= '<h6>'.__('Width', 'gforms-rcwdupload').'</h6>'.__('Resize the image to the specified width.', 'gforms-rcwdupload');  
   		$tooltips["form_field_rcwdupload_preview_max_height"]		= '<h6>'.__('Height', 'gforms-rcwdupload').'</h6>'.__('Resize the image to the specified height.', 'gforms-rcwdupload'); 
   		$tooltips["form_field_rcwdupload_preview_crop"]				= '<h6>'.__('Crop', 'gforms-rcwdupload').'</h6>'.__('Crop the image to the specified size.', 'gforms-rcwdupload'); 
				
   		$tooltips["form_field_rcwdupload_repeater"] 				= '<h6>'.__('Repeater', 'gforms-rcwdupload').'</h6>'.__('Choose YES if you want to let the user upload mor than 1 file.', 'gforms-rcwdupload');  
   		$tooltips["form_field_rcwdupload_repeater_limit"]			= '<h6>'.__('Repeater limit', 'gforms-rcwdupload').'</h6>'.__('Limit the repetition of the fields by adding a number to this field (0 or empty is for unlimited).', 'gforms-rcwdupload');
   		$tooltips["form_field_rcwdupload_repeater_min"]				= '<h6>'.__('Start with n fields', 'gforms-rcwdupload').'</h6>'.__('If repeater is ON, start with n fields.', 'gforms-rcwdupload');
   		$tooltips["form_field_rcwdupload_repeater_sortable"]		= '<h6>'.__('Sortable', 'gforms-rcwdupload').'</h6>'.__('Reorder elements in list using drag&drop.', 'gforms-rcwdupload');
		$tooltips["form_field_rcwdupload_filter"] 					= '<h6>'.__('Filters', 'gforms-rcwdupload').'</h6>'.$ttff; 
   		$tooltips["form_field_rcwdupload_filter_images"]			= '<h6>'.__('Images', 'gforms-rcwdupload').'</h6>'.$ttff;  
   		$tooltips["form_field_rcwdupload_filter_docs"]				= '<h6>'.__('Documents', 'gforms-rcwdupload').'</h6>'.$ttff;  
   		$tooltips["form_field_rcwdupload_filter_compr"]				= '<h6>'.__('Compressed files', 'gforms-rcwdupload').'</h6>'.$ttff;  
   		$tooltips["form_field_rcwdupload_filter_others"]			= '<h6>'.__('Other files', 'gforms-rcwdupload').'</h6>'.$ttff;  
   		$tooltips["form_field_rcwdupload_resize"]					= '<h6>'.__('Resize', 'gforms-rcwdupload').'</h6>'.__('Enable options for image resizing.', 'gforms-rcwdupload');  
   		$tooltips["form_field_rcwdupload_resize_max_width"]			= '<h6>'.__('Width', 'gforms-rcwdupload').'</h6>'.__('Resize the image to the specified width (0 for proportional).', 'gforms-rcwdupload');  
   		$tooltips["form_field_rcwdupload_resize_max_height"]		= '<h6>'.__('Height', 'gforms-rcwdupload').'</h6>'.__('Resize the image to the specified height (0 for proportional).', 'gforms-rcwdupload');  
   		$tooltips["form_field_rcwdupload_resize_max_quality"]		= '<h6>'.__('Quality', 'gforms-rcwdupload').'</h6>'.__('Compress the image to the specified quality (0 for original).', 'gforms-rcwdupload');  
   		$tooltips["form_field_rcwdupload_resize_crop"]				= '<h6>'.__('Crop', 'gforms-rcwdupload').'</h6>'.__('Crop the image to the specified size.', 'gforms-rcwdupload'); 
   		$tooltips["form_field_rcwdupload_csresize"]					= '<h6>'.__('Clientside resize', 'gforms-rcwdupload').'</h6>'.__('Images will be automatically resized before the upload step in order to reduce the weight.', 'gforms-rcwdupload');  
   		$tooltips["form_field_rcwdupload_autoupload"]				= '<h6>'.__('Autoupload', 'gforms-rcwdupload').'</h6>'.__('Files will be automatically uploaded after selection.', 'gforms-rcwdupload');  
   		$tooltips["form_field_rcwdupload_hidebrowse"]				= '<h6>'.__('Hide browse button', 'gforms-rcwdupload').'</h6>'.__('Hide the browser button after the file is selected.', 'gforms-rcwdupload');  
   		$tooltips["form_field_rcwdupload_sizelimit"]				= '<h6>'.__('Sizelimit', 'gforms-rcwdupload').'</h6>'.__('Limit the upload size of the files.', 'gforms-rcwdupload');  
		
	   return $tooltips;
		
	}
	
	function editor_js_set_default_values(){
/*		
?>	
		case 'rcwdupload':
        	console.log(field);
			break;
<?php
	*/	
	}
	
	function gform_admin_head(){
		
		global $pagenow;

		if( IS_ADMIN and $pagenow == 'admin.php' and isset($_GET['page']) and $_GET['page'] == 'gf_entries' and isset($_GET['view']) and $_GET['view'] == 'entry' ){

			if( ( isset($_POST['entry_id']) and isset($_POST['gforms_save_entry']) ) or ( isset($_GET['screen_mode']) and $_GET['screen_mode'] == 'edit' and isset($_GET['lid']) and is_numeric($_GET['lid']) ) )
				echo '<script type="text/javascript">jQuery(document).ready(function($){if (typeof gformsrcwdplupload_init != "undefined" && $.isFunction(gformsrcwdplupload_init)) {gformsrcwdplupload_init();}});</script>';
				
		}
		
	}

	function gform_admin_pre_render($form){

		foreach ( $form['fields'] as $field ){
			
			if($field['type'] == 'rcwdupload'){

				global $rcwdupload_gform_admin_pre_render;
				
				if(empty($rcwdupload_gform_admin_pre_render)){				
?>
					<script type="text/javascript">	
<?php
						global $pagenow;
?>					
						if(typeof gform !== 'undefined'){
							
							function rcwdupload_allow_conditional_logic_date_fields( isConditionalLogicField, field ){
				
								return isConditionalLogicField || field.type == 'rcwdupload';
								
							}
							
							gform.addFilter( 'gform_is_conditional_logic_field', 'rcwdupload_allow_conditional_logic_date_fields' );
							
							function rcwdupload_gform_conditional_logic_operators( operators, objectType, fieldId ){
				
				/*				var field = GetFieldById(fieldId);
								
								if(field['type'] == 'rcwdupload')
									return {"is":"is","isnot":"isNot"};*/
				
								return operators;
								
							}
							
							gform.addFilter( 'gform_conditional_logic_operators', 'rcwdupload_gform_conditional_logic_operators' );
							
							function rcwdupload_gform_conditional_logic_values_input( str, objectType, ruleIndex, selectedFieldId, selectedValue ){
				
								var field = GetFieldById(selectedFieldId);
								
								if(field['type'] == 'rcwdupload'){
									
									var dropdown_id = objectType + '_rule_value_' + ruleIndex;
									
									return "<select id='" + dropdown_id + "' class='gfield_rule_select gfield_rule_value_dropdown gfield_category_dropdown'><option value=''>Empty</option></select>";
								}
								
								return str;
								
							}
							
							gform.addFilter( 'gform_conditional_logic_values_input', 'rcwdupload_gform_conditional_logic_values_input' );	
						
						}
                        
                    </script>
<?php				
					$rcwdupload_gform_admin_pre_render = 1;
					
				}
				
				break;				
			
			}
			
		}
			
		return $form;	
			
	}
	
/*	function gform_pre_render($form){
		
		global $rcwdupload_gform_is_value_match;
		
		if(empty($rcwdupload_gform_is_value_match)){
?>
			<script type="text/javascript">	
    
                function rcwdupload_gform_is_value_match( isMatch, formId, rule ){
                    
                    return isMatch;
                    
                }
                
            </script>
<?php	
			$rcwdupload_gform_is_value_match = 1;
			
		}
		
		return $form;
		       		
	}*/
	
	function rcwdupload_settings( $position, $form_id ){

		if($position == 1430){

			//if(file_exists(GFORMS_RCWDUPLOAD_UP_DIR)){												
?>
            <li class="rcwdupload_settings field_setting">
                <div class="gformsrcwdupload_sspace">
					<input type="checkbox" id="field_rcwdupload_filetitle" onclick="SetFieldProperty('rcwdupload_filetitle', this.checked);" />
                    <label for="field_rcwdupload_filetitle" class="inline"><?php _e("Add a field for title", "gforms-rcwdupload"); ?> <?php gform_tooltip("form_field_rcwdupload_filetitle"); ?></label>
                </div>        

                <div class="gformsrcwdupload_sspace">
                
                    <label for="field_rcwdupload_sizelimit"><?php _e( 'Filesize limit', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_sizelimit") ?></label>
                    <input type="text" id="field_rcwdupload_sizelimit" class="gformsrcwdupload_sizelimit" onkeyup="SetFieldProperty('rcwdupload_sizelimit', this.value);" />
                    <select id="field_rcwdupload_sizelimit_type" class="field_rcwdupload_sizelimit_type" onchange="SetFieldProperty('rcwdupload_sizelimit_type', jQuery(this).val() );">
                        <option value="kb"><?php _e( 'KB', 'gforms-rcwdupload' ) ?></option>
                        <option value="mb"><?php _e( 'MB', 'gforms-rcwdupload' ) ?></option>
                    </select>                        

                    <div class="gformsrcwdupload_3cols">

                    </div>
                    
                    <div class="formsrcwdupload_clear"></div>                                       
                </div>

                <div class="gformsrcwdupload_sspace">
                
                    <label for="field_rcwdupload_rename"><?php _e( 'Rename the file', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_rename") ?></label>
<?php
					echo '<div class="gformsrcwdupload_rename_tag-wrapper"><span class="gformsrcwdupload_rename_tag">'.implode( '</span>&nbsp; &nbsp;<span class="gformsrcwdupload_rename_tag">', self::$rnm_search ).'</span></div>';
?>                    
                    <input type="text" id="field_rcwdupload_rename" class="gformsrcwdupload_rename" onkeyup="SetFieldProperty('rcwdupload_rename', this.value);" /> 
                    <div class="gformsrcwdupload_note"><?php _e( 'Note: the file will we renamed after the form is submitted', 'gforms-rcwdupload' ) ?></div>                     

                    <div class="gformsrcwdupload_3cols">

                    </div>
                    
                    <div class="formsrcwdupload_clear"></div>                                       
                </div>                    
                                      
                <div class="gformsrcwdupload_sspace">
            		<label for="field_rcwdupload_repeater"><?php _e( 'Activate repeater', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_repeater") ?></label>
                    <select id="field_rcwdupload_repeater" class="field_rcwdupload_repeater_choose" onchange="SetFieldProperty('rcwdupload_repeater', jQuery(this).val() );">
						<option value="N"><?php _e( 'No', 'gforms-rcwdupload' ) ?></option>
                  		<option value="Y"><?php _e( 'Yes', 'gforms-rcwdupload' ) ?></option>
                    </select>
                </div>

                <div class="gformsrcwdupload_repeater_fields">
                
                    <div class="gformsrcwdupload_sspace">
                    	<div class="gformsrcwdupload_3cols">
                            <label for="field_rcwdupload_repeater_limit"><?php _e("Repeater limit", "gforms-rcwdupload"); ?> <?php gform_tooltip("form_field_rcwdupload_repeater_limit"); ?>
                            </label>
                            <input type="text" id="field_rcwdupload_repeater_limit" class="gformsrcwdupload_repeater_limit_field" onkeyup="SetFieldProperty('rcwdupload_repeater_limit', this.value);" />
                        </div>
                    	<div class="gformsrcwdupload_3cols">
                            <label for="field_rcwdupload_repeater_min"><?php _e("Start with n fields", "gforms-rcwdupload"); ?> <?php gform_tooltip("form_field_rcwdupload_repeater_min"); ?>
                            </label>
                            <input type="text" id="field_rcwdupload_repeater_min" class="gformsrcwdupload_repeater_min_field" onkeyup="SetFieldProperty('rcwdupload_repeater_min', this.value);" />
                        </div>
                        <div class="formsrcwdupload_clear"></div>
                    </div>

                    <div class="gformsrcwdupload_sspace">
                        <label for="field_rcwdupload_repeater_sortable"><?php _e( 'Sortable feature', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_repeater_sortable") ?></label>
                        <select id="field_rcwdupload_repeater_sortable" onchange="SetFieldProperty('rcwdupload_repeater_sortable', jQuery(this).val() );">
                            <option value="N"><?php _e( 'No', 'gforms-rcwdupload' ) ?></option>
                            <option value="Y"><?php _e( 'Yes', 'gforms-rcwdupload' ) ?></option>
                        </select>
                    </div>
                                        
                </div>
                
                <div class="gformsrcwdupload_sspace">
            		<label for="field_rcwdupload_clientpreview"><?php _e( 'Activate image preview before upload', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_clientpreview") ?></label>
                    <select id="field_rcwdupload_clientpreview" class="field_rcwdupload_clientpreview_choose" onchange="SetFieldProperty('rcwdupload_clientpreview', jQuery(this).val() );">
						<option value="N"><?php _e( 'No', 'gforms-rcwdupload' ) ?></option>
                  		<option value="Y"><?php _e( 'Yes', 'gforms-rcwdupload' ) ?></option>
                    </select>
                </div>  

                <div class="gformsrcwdupload_clientpreview_fields">
                
                    <div class="gformsrcwdupload_sspace">
                        <div class="gformsrcwdupload_3cols">
                            <label for="field_rcwdupload_clientpreview_max_width"><?php _e( 'Width', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_clientpreview_max_width") ?></label>
                            <input type="text" id="field_rcwdupload_clientpreview_max_width" class="gformsrcwdupload_clientpreview_field" onkeyup="SetFieldProperty('rcwdupload_clientpreview_max_width', this.value);" />
                        </div>
                        <div class="gformsrcwdupload_3cols">
                            <label for="field_rcwdupload_clientpreview_max_height"><?php _e( 'Height', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_clientpreview_max_height") ?></label>
                            <input type="text" id="field_rcwdupload_clientpreview_max_height" class="gformsrcwdupload_clientpreview_field" onkeyup="SetFieldProperty('rcwdupload_clientpreview_max_height', this.value);" />
                        </div>
                        <div class="gformsrcwdupload_3cols">
                            <label for="field_rcwdupload_clientpreview_crop"><?php _e( 'Crop', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_clientpreview_crop") ?></label>
                            <select id="field_rcwdupload_clientpreview_crop" onchange="SetFieldProperty('rcwdupload_clientpreview_crop', jQuery(this).val() );">
                                <option value="N"><?php _e( 'No', 'gforms-rcwdupload' ) ?></option>
                                <option value="Y"><?php _e( 'Yes', 'gforms-rcwdupload' ) ?></option>
                            </select>
                        </div> 
                        <div class="formsrcwdupload_clear"></div>                                       
                    </div>
                    
                </div>

                <div class="gformsrcwdupload_sspace">
            		<label for="field_rcwdupload_preview"><?php _e( 'Show uploaded image preview', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_preview") ?></label>
                    <select id="field_rcwdupload_preview" class="field_rcwdupload_preview_choose" onchange="SetFieldProperty('rcwdupload_preview', jQuery(this).val() );">
						<option value="N"><?php _e( 'No', 'gforms-rcwdupload' ) ?></option>
                  		<option value="Y"><?php _e( 'Yes', 'gforms-rcwdupload' ) ?></option>
                    </select>
                </div>  

                <div class="gformsrcwdupload_preview_fields">
                
                    <div class="gformsrcwdupload_sspace">
                        <div class="gformsrcwdupload_3cols">
                            <label for="field_rcwdupload_preview_max_width"><?php _e( 'Width', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_preview_max_width") ?></label>
                            <input type="text" id="field_rcwdupload_preview_max_width" class="gformsrcwdupload_preview_field" onkeyup="SetFieldProperty('rcwdupload_preview_max_width', this.value);" />
                        </div>
                        <div class="gformsrcwdupload_3cols">
                            <label for="field_rcwdupload_preview_max_height"><?php _e( 'Height', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_preview_max_height") ?></label>
                            <input type="text" id="field_rcwdupload_preview_max_height" class="gformsrcwdupload_preview_field" onkeyup="SetFieldProperty('rcwdupload_preview_max_height', this.value);" />
                        </div>
                        <div class="gformsrcwdupload_3cols">
                            <label for="field_rcwdupload_preview_crop"><?php _e( 'Crop', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_preview_crop") ?></label>
                            <select id="field_rcwdupload_preview_crop" onchange="SetFieldProperty('rcwdupload_preview_crop', jQuery(this).val() );">
                                <option value="N"><?php _e( 'No', 'gforms-rcwdupload' ) ?></option>
                                <option value="Y"><?php _e( 'Yes', 'gforms-rcwdupload' ) ?></option>
                            </select>
                        </div> 
                        <div class="formsrcwdupload_clear"></div>                                       
                    </div>
                    
                </div>
                
                <div class="gformsrcwdupload_sspace">
            		<label for="field_rcwdupload_filter"><?php _e( 'Filters the files', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_filter") ?></label>
                    <select id="field_rcwdupload_filter" class="field_rcwdupload_filter_choose" onchange="SetFieldProperty('rcwdupload_filter', jQuery(this).val() );">
                        <option value="Y"><?php _e( 'Yes', 'gforms-rcwdupload' ) ?></option>
                        <option value="N"><?php _e( 'No', 'gforms-rcwdupload' ) ?></option>
                    </select>
                </div>
                
                <div class="gformsrcwdupload_filter_fields">
                    <div class="gformsrcwdupload_sspace">
                        <label for="field_rcwdupload_filter_images"><?php _e("Images", "gforms-rcwdupload"); ?> <?php gform_tooltip("form_field_rcwdupload_filter_images"); ?>
                        </label>
                        <input type="text" id="field_rcwdupload_filter_images" class="fieldwidth-3" onkeyup="SetFieldProperty('rcwdupload_filter_images', this.value);" />
                    </div>
    
                    <div class="gformsrcwdupload_sspace">
                        <label for="field_rcwdupload_filter_docs"><?php _e("Documents", "gforms-rcwdupload"); ?> <?php gform_tooltip("form_field_rcwdupload_filter_docs"); ?>
                        </label>
                        <input type="text" id="field_rcwdupload_filter_docs" class="fieldwidth-3" onkeyup="SetFieldProperty('rcwdupload_filter_docs', this.value);" />
                    </div>
                    
                    <div class="gformsrcwdupload_sspace">
                        <label for="field_rcwdupload_filter_compr"><?php _e("Compressed files", "gforms-rcwdupload"); ?> <?php gform_tooltip("form_field_rcwdupload_filter_compr"); ?>
                        </label>
                        <input type="text" id="field_rcwdupload_filter_compr" class="fieldwidth-3" onkeyup="SetFieldProperty('rcwdupload_filter_compr', this.value);" />
                    </div>
                    
                    <div class="gformsrcwdupload_sspace">
                        <label for="field_rcwdupload_filter_others"><?php _e("Other files", "gforms-rcwdupload"); ?> <?php gform_tooltip("form_field_rcwdupload_filter_others"); ?>
                        </label>
                        <input type="text" id="field_rcwdupload_filter_others" class="fieldwidth-3" onkeyup="SetFieldProperty('rcwdupload_filter_others', this.value);" />
                    </div>
                </div>

				<div class="gformsrcwdupload_sspace">
                    <label for="field_rcwdupload_resize"><?php _e( 'Enable resizing', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_resize") ?></label>
                    <select id="field_rcwdupload_resize" class="field_rcwdupload_resize_choose" onchange="SetFieldProperty('rcwdupload_resize', jQuery(this).val() );">
                        <option value="Y"><?php _e( 'Yes', 'gforms-rcwdupload' ) ?></option>
                        <option value="N"><?php _e( 'No', 'gforms-rcwdupload' ) ?></option>
                    </select>
                </div>
				
                <div class="gformsrcwdupload_resize_fields">
                
                    <div class="gformsrcwdupload_sspace">
                        <div class="gformsrcwdupload_3cols">
                            <label for="field_rcwdupload_resize_max_width"><?php _e( 'Width', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_resize_max_width") ?></label>
                            <input type="text" id="field_rcwdupload_resize_max_width" class="gformsrcwdupload_resize_field" onkeyup="SetFieldProperty('rcwdupload_resize_max_width', this.value);" />
                        </div>
                        <div class="gformsrcwdupload_2cols">
                            <label for="field_rcwdupload_resize_max_height"><?php _e( 'Height', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_resize_max_height") ?></label>
                            <input type="text" id="field_rcwdupload_resize_max_height" class="gformsrcwdupload_resize_field" onkeyup="SetFieldProperty('rcwdupload_resize_max_height', this.value);" />
                        </div>
                        <div class="gformsrcwdupload_2cols">
                            <label for="field_rcwdupload_resize_max_quality"><?php _e( 'Quality', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_resize_max_quality") ?></label>
                            <input type="text" id="field_rcwdupload_resize_max_quality" class="gformsrcwdupload_resize_field" onkeyup="SetFieldProperty('rcwdupload_resize_max_quality', this.value);" />
                        </div> 
                        <div class="gformsrcwdupload_2cols">
                            <label for="field_rcwdupload_resize_crop"><?php _e( 'Crop', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_resize_crop") ?></label>
                            <select id="field_rcwdupload_resize_crop" onchange="SetFieldProperty('rcwdupload_resize_crop', jQuery(this).val() );">
                                <option value="Y"><?php _e( 'Yes', 'gforms-rcwdupload' ) ?></option>
                                <option value="N"><?php _e( 'No', 'gforms-rcwdupload' ) ?></option>
                            </select>
                            
                        </div>                        
                        <div class="formsrcwdupload_clear"></div>                                       
                    </div>
                        
                    <div class="gformsrcwdupload_sspace">
                        <label for="field_rcwdupload_csresize"><?php _e( 'Resize the images to clientside', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_csresize") ?></label>
                        <select id="field_rcwdupload_csresize" onchange="SetFieldProperty('rcwdupload_csresize', jQuery(this).val() );">
                            <option value="Y"><?php _e( 'Yes', 'gforms-rcwdupload' ) ?></option>
                            <option value="N"><?php _e( 'No', 'gforms-rcwdupload' ) ?></option>
                        </select>
                    </div>
                    
                </div> 

                <div class="gformsrcwdupload_sspace">
            		<label for="field_rcwdupload_autoupload"><?php _e( 'Upload the file after selection', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_autoupload") ?></label>
                    <select id="field_rcwdupload_autoupload" class="field_rcwdupload_autoupload" onchange="SetFieldProperty('rcwdupload_autoupload', jQuery(this).val() );">
						<option value="N"><?php _e( 'No', 'gforms-rcwdupload' ) ?></option>
                  		<option value="Y"><?php _e( 'Yes', 'gforms-rcwdupload' ) ?></option>
                    </select>
                </div>
                
                <div class="gformsrcwdupload_autoupload_fields">
                    <div class="gformsrcwdupload_sspace">
                            <label for="field_rcwdupload_hidebrowse"><?php _e( 'Hide the browse button after selection', 'gforms-rcwdupload' ) ?> <?php gform_tooltip("form_field_rcwdupload_hidebrowse") ?></label>
                            <select id="field_rcwdupload_hidebrowse" onchange="SetFieldProperty('rcwdupload_hidebrowse', jQuery(this).val() );">
                                <option value="N"><?php _e( 'No', 'gforms-rcwdupload' ) ?></option>
                                <option value="Y"><?php _e( 'Yes but show it after uploaded', 'gforms-rcwdupload' ) ?></option>
                                <option value="Y2"><?php _e( 'Yes and keep it hidden until file is removed', 'gforms-rcwdupload' ) ?></option>
                            </select>
                    </div>                
                </div>
                                                                                                             
       		</li>
<?php
			//}
		}
			
	}
	
	function gform_trim_input_value( $trim, $form_id, $field ){

		$field	= (array)$field;
		$mode	= isset($_POST["screen_mode"]) ?  $_POST["screen_mode"] : '';
	
		if( IS_ADMIN and $mode != 'edit' and $field["type"] == "rcwdupload" and ( !defined('DOING_AJAX') or !DOING_AJAX or ( DOING_AJAX and !isset($_REQUEST['action']) or ( $_REQUEST['action'] != 'quick_checkout_action' and $_REQUEST['action'] != 'woocommerce_update_order_review' ) ) ) )
			return false;
		elseif($field["type"] == "rcwdupload"){
			
			if( isset($_POST) and isset($_POST['input_'.$field['id']]) ){
				
				if(is_array(rgpost('input_'.$field['id'])))
					return false;
				
			}

		}
		
		return true;

	}
	
	static function gform_field_input( $input, $field, $value, $lead_id, $form_id ){

		$field = (array)$field;
			
		if($field["type"] == "rcwdupload"){						
										
			$ftype 		= GFORMS_RCWDUPLOAD_DEBUG ? 'text' : 'hidden';
			$field 		= (array)$field;
			$user_id	= 0;
			$mode 		= isset($_POST["screen_mode"]) ?  $_POST["screen_mode"] : '';

			if( IS_ADMIN and ( ( isset($_GET['page']) and $_GET['page'] == 'gf_edit_forms' and isset($_GET['id']) and is_numeric($_GET['id']) and $_GET['id'] > 0 ) or ( isset($_POST['action']) and $_POST['action'] == 'rg_add_field' ) ) ){
				
				$input = "<input type='file' disabled='disabled' class='medium gformsrcwdupload-demofield' size='20' value='' id='input_".$field["id"]."' name='input_".$field["id"]."'><img style='cursor:default; margin:0 3px;' alt='' disabled='disabled' class='gformsrcwdupload-demoadd' src='". GFCommon::get_base_url()."/images/add.png'>";
								
			}elseif( IS_ADMIN and $mode != 'edit' and( !defined('DOING_AJAX') or !DOING_AJAX or ( DOING_AJAX and !isset($_REQUEST['action']) or ( $_REQUEST['action'] != 'quick_checkout_action' and $_REQUEST['action'] != 'woocommerce_update_order_review' ) ) ) ){ 
				
				$vvv		= $value;
				$input_name = $form_id.'_'.$field["id"];
				
				if($value != '')
					$value = maybe_unserialize($value);
				else
					$value = array('');

				$idsuffix 	= '';
				$count		= 0;

				ob_start();
?>
				<div class='ginput_container'><?php _e( 'Sorry, this field is not editable', 'gforms-rcwdupload' ) ?></div>
<?php					
				foreach($value as $val_){

					$val = is_array($val_) ?  $val_['file'] : '';
					
					if($count > 0)
						$idsuffix = '_'.$count;
?>
					<input type="<?php echo $ftype ?>" id="<?php echo 'input_'.$input_name.$idsuffix ?>" name="<?php echo 'input_'.$field['id']; ?>[file][]" value="<?php echo $val ?>" />
                    <input type="<?php echo $ftype ?>" name="gformrcwduploadleadid" value="<?php echo $lead_id ?>" />
<?php
					if(isset($field['rcwdupload_filetitle'])){
						$val_title 	= ( is_array($val_) and isset($val_['title']) ) ? stripslashes($val_['title']) : '';
?>
							<input type="<?php echo $ftype ?>" value="<?php echo $val_title ?>" id="<?php echo 'input_'.$input_name.'_title_'.$idsuffix ?>" name="<?php echo 'input_'.$field['id'] ?>[title][]"> 
<?php							
					}
										
				}
				
				$input = ob_get_contents();
				ob_end_clean();				
					
/*				}else{

			
				}*/
				
			}else{

				if( class_exists("GFUser") or class_exists("GF_User_Registration") ){
			
					if(is_user_logged_in()){
						
						$gfurclass = static::$gfurclass;

						if(static::$gfurd == 'old')
							$config = $gfurclass::get_update_feed($form_id);
						else
							$config = gf_user_registration()->get_update_feed($form_id);
	
						if( $form_id == $config['form_id'] and $config['meta']['feedType'] == 'update' ){					
						
							$user 		= wp_get_current_user();
							$user_id	= $user->ID;
							$lead_id 	= get_user_meta( $user_id, '_gform-update-entry-id', true ); 
							$formmode = 'userupdate';
							
						}
					
					}
					
				}
				
				$field_values  = RGForms::post("gform_field_values");
				
				if(!IS_ADMIN){
					
					$source_page	= GFFormDisplay::get_source_page($form_id);
					$target_page 	= GFFormDisplay::get_target_page( RGFormsModel::get_form_meta($form_id), $source_page, $field_values );			

					if( !empty($target_page) and $target_page < $source_page )
						$value = maybe_serialize(GFRcwdCommon::field_value_correction( $_POST['input_'.$field['id']], $field ));
									
				}
				
				if($value != '')
					$value = maybe_unserialize($value);
				else
					$value = array('');
				
			
				if(is_object(self::$post)){	 // COMPATIBILITY GFORMS UPDATE POST PLUGIN

					//$entry_ID	= get_post_meta( self::$post->ID, '_gform-entry-id', true );
					$value = get_post_meta( self::$post->ID, sanitize_title('_gforms_rcwdupload_'.$field['label']), true );
					
					if( !empty($value) and !empty($value[0]) ){

						$value_p	= maybe_unserialize($value);						
						$form_id_p	= $value_p[0]['form_id'];
						$lead_id_p  = $value_p[0]['entry_id'];
									
					}else
						$value_p = array('');
							
				}
					
				$rndfldr		= isset($value[0]['rndfldr']) ? $value[0]['rndfldr'] : '';
				$input_name 	= $form_id.'_'.$field["id"];
				$tabindex 		= GFCommon::get_tabindex();
				$data_showtemp	= $fsize = '';
				$defaults		= array(
				
					'rcwdupload_filetitle'  				=>  false,
					'rcwdupload_rename'  					=>  '',
					'rcwdupload_clientpreview'  			=>  'N',
					'rcwdupload_clientpreview_max_width'	=>  150,
					'rcwdupload_clientpreview_max_height'	=>  150,
					'rcwdupload_clientpreview_crop'			=>  'N',
					'rcwdupload_preview'	 				=>  'N',
					'rcwdupload_preview_max_width'			=>  150,
					'rcwdupload_preview_max_height'			=>  150,
					'rcwdupload_preview_crop'				=>  'N',					
					'rcwdupload_repeater'  					=>  'N',
					'rcwdupload_repeater_limit' 			=>  0,
					'rcwdupload_repeater_min' 				=>  0,
					'rcwdupload_repeater_sortable'			=>  'N',
					'rcwdupload_filter'    					=>  'Y',
					'rcwdupload_filter_images'				=>  'jpg,gif,png,jpeg',
					'rcwdupload_filter_docs'   				=>  'pdf,doc,docx,xml,txt,xls,xlsx',
					'rcwdupload_filter_compr'				=>  'zip,rar,ace',
					'rcwdupload_filter_others'				=>  '',
					'rcwdupload_resize'						=>  'N',
					'rcwdupload_resize_max_width'			=>  '0',
					'rcwdupload_resize_max_height'			=>  '0',												
					'rcwdupload_resize_crop'				=>  'N',					
					'rcwdupload_max_quality'				=>  '90',
					'rcwdupload_csresize'					=>  'N',
					'rcwdupload_autoupload'					=>  'N',
					'rcwdupload_hidebrowse'					=>  'N',
					'rcwdupload_sizelimit'					=>  '',
					'rcwdupload_sizelimit_type'				=>  'kb',
					'rcwdupload_chunks'						=> '0',
					'rcwdupload_chunks_max_retries'			=> 3
												
				);

				$field 						= array_merge( $defaults, (array)$field );
				$repeater					= $field['rcwdupload_repeater'];
				$repeater_limit				= (int)apply_filters( 'gforms_rcwdupload_repeater_limit_'.$form_id.'_'.$field['id'], (int)apply_filters( 'gforms_rcwdupload_repeater_limit_'.$form_id, (int)apply_filters( 'gforms_rcwdupload_repeater_limit', $field['rcwdupload_repeater_limit'], $form_id, $field['id'], $lead_id ), $field['id'], $lead_id ), $lead_id );
				$repeater_min				= (int)apply_filters( 'gforms_rcwdupload_repeater_min_'.$form_id.'_'.$field['id'], (int)apply_filters( 'gforms_rcwdupload_repeater_min_'.$form_id, (int)apply_filters( 'gforms_rcwdupload_repeater_min', $field['rcwdupload_repeater_min'], $form_id, $field['id'], $lead_id ), $field['id'], $lead_id ), $lead_id );
				$repeater_sortable			= $field['rcwdupload_repeater_sortable'];
				$css 						= isset( $field['cssClass'] ) ? $field['cssClass'] : '';
				$rename						= trim(filter_var( $field['rcwdupload_rename'], FILTER_SANITIZE_STRING ));
				$clientpreview				= $field['rcwdupload_clientpreview'];
				$clientpreview_max_width	= (int)$field['rcwdupload_clientpreview_max_width'];
				$clientpreview_max_height 	= (int)$field['rcwdupload_clientpreview_max_height'];
				$clientpreview_crop 		= $field['rcwdupload_clientpreview_crop'];
				$preview					= $field['rcwdupload_preview'];
				$preview_max_width			= (int)$field['rcwdupload_preview_max_width'];
				$preview_max_height 		= (int)$field['rcwdupload_preview_max_height'];
				$preview_crop 				= $field['rcwdupload_preview_crop'];				
				$autoupload 				= $field['rcwdupload_autoupload'];
				$sizelimit 					= $field['rcwdupload_sizelimit'];
				$sizelimit_type				= $field['rcwdupload_sizelimit_type'];
				$hidebrowse					= $field['rcwdupload_hidebrowse'];

				if( $repeater_limit > 0 and $repeater_min > $repeater_limit )
					$repeater_min = $repeater_limit;
					
				if( $preview == 'Y' and !class_exists('PhpThumb') )
					require_once 'includes'.DIRECTORY_SEPARATOR.'PHPThumb'.DIRECTORY_SEPARATOR.'ThumbLib.inc.php';
				
				if($repeater_limit == 0)
					$repeater_limit = 999;
	
				if($repeater == 'N'){
					
					$maxfiles 			= 1;
					$repeater_sortable 	= 'N';
					
				}else
					$maxfiles = $repeater_limit > 0 ? $repeater_limit : 1;
				
				if((int)$sizelimit == 0)
					if($sizelimit_type == 'kb')
						$sizelimit = round( (int)wp_max_upload_size() / 1024 );
					else
						$sizelimit = round( (int)wp_max_upload_size() / 1024 / 1024 );
					
				if($sizelimit_type == 'kb')
					$max_file_size	= $sizelimit.'KB';
				else
					$max_file_size	= $sizelimit.'MB';

				$multiselection	= true;
				$overwrite		= 0;
				
				if($maxfiles == 1){
					
					$multiselection	= false;
					$overwrite		= 1;
					
				}
				
				if($field['rcwdupload_repeater'] == 'Y')
					 $overwrite = 0;
					 
				$chunks = filter_var( apply_filters( 'gforms_rcwdupload_chunks_'.$form_id.'_'.$field['id'], apply_filters( 'gforms_rcwdupload_chunks_'.$form_id, apply_filters( 'gforms_rcwdupload_chunks', $field['rcwdupload_chunks'], $form_id, $field['id'], $lead_id ), $field['id'], $lead_id ), $lead_id ), FILTER_SANITIZE_STRING );

				// resize settings ___________________________________________
				
					$doresize 		= $field['rcwdupload_resize'];
					$resize			= '';
					$resize_or		= '';
					$csresize		= '';
					$csresize_or	= '';
					
					if($doresize == 'Y'){
			
						// serverside resize settings
						
							$resize = array('quality' => (int)$field['rcwdupload_max_quality']);
							
							if((int)$field['rcwdupload_resize_max_width'] > 0)
								$resize['width'] = $field['rcwdupload_resize_max_width'];
								
							if((int)$field['rcwdupload_resize_max_height'] > 0)
								$resize['height'] = $field['rcwdupload_resize_max_height'];	
								
							if($field['rcwdupload_resize_crop'] == 'Y')	
								$resize['crop'] = true;	
								
							$resize_or 	= $resize;
							$resize 	= json_encode($resize);				
					
						// clientside resize settings
					
							$do_csresize	= $field['rcwdupload_csresize'];
							$csresize		= '';
							
							if($do_csresize == 'Y'){
								
								$csresize = array( 'quality' => (int)$field['rcwdupload_max_quality'] );
								
								if((int)$field['rcwdupload_resize_max_width'] > 0)
									$csresize['width'] = $field['rcwdupload_resize_max_width'];
									
								if((int)$field['rcwdupload_resize_max_height'] > 0)
									$csresize['height'] = $field['rcwdupload_resize_max_height'];	

								if($field['rcwdupload_resize_crop'] == 'Y')	
									$csresize['crop'] = true;	
								else
									$csresize['crop'] = false;
									
								$csresize_or	= $csresize;	
								$csresize 		= json_encode($csresize);		
			
							}
			
					}
	
				// ___________________________________________________________

				$dofilters = $field['rcwdupload_filter'];
				$upfilters = '';
				
				if($dofilters == 'Y'){
					
					$filter_images 	= preg_replace('/\s+/', '', strtolower($field['rcwdupload_filter_images']));
					$filter_docs 	= preg_replace('/\s+/', '', strtolower($field['rcwdupload_filter_docs']));
					$filter_compr 	= preg_replace('/\s+/', '', strtolower($field['rcwdupload_filter_compr']));
					$filter_others 	= preg_replace('/\s+/', '', strtolower($field['rcwdupload_filter_others']));
					
					if( $filter_images != '')
						$upfilters[] = array( 'title' => __( 'Image files', 'gforms-rcwdupload' ), 'extensions' => $filter_images );
						
					if( $filter_docs != '')
						$upfilters[] = array( 'title' => __( 'Document files', 'gforms-rcwdupload' ), 'extensions' => $filter_docs );
						
					if( $filter_compr != '')
						$upfilters[] = array( 'title' => __( 'Compressed files', 'gforms-rcwdupload' ), 'extensions' => $filter_compr );
						
					if( $filter_others != '')
						$upfilters[] = array( 'title' => __( 'Various files', 'gforms-rcwdupload' ), 'extensions' => $filter_others );	
						
					if(count($upfilters) > 0)
						$upfilters = json_encode(array('mime_types' => $upfilters));	
		
				}

				$upload_info 	= GFRcwdCommon::upload_info( $form_id, $field['id'], $lead_id, 0, $rndfldr );
				$path_temp		= $upload_info['path_temp'];
				$path			= $upload_info['path'];
				$url_temp		= $upload_info['url_temp'];
				$url			= $upload_info['url'];
				$rndfldr		= $upload_info['rndfldr'];
				$idsuffix 		= '';
				$count			= 0;
				$logic_event	= '';
				$frc 			= (bool)apply_filters( 'gforms_rcwdupload_thumb_force_http', false, $form_id, $field['id'], $lead_id );	
				
				if($frc)
					$frc = 1;
				else
					$frc = 0;

				ob_start();
				
				if(!empty($field["conditionalLogicFields"]))
					$logic_event = "onchange='gf_apply_rules(" . $field["formId"] . "," . GFCommon::json_encode($field["conditionalLogicFields"]) . ");' 
				onpaste='clearTimeout(__gf_timeout_handle); __gf_timeout_handle = setTimeout(\"gf_apply_rules(" . $field["formId"] . "," . GFCommon::json_encode($field["conditionalLogicFields"]) . ")\", 300);' 
				onkeyup='clearTimeout(__gf_timeout_handle); __gf_timeout_handle = setTimeout(\"gf_apply_rules(" . $field["formId"] . "," . GFCommon::json_encode($field["conditionalLogicFields"]) . ")\", 300);'";
?>
				<input type="<?php echo $ftype ?>" id="rcwdupload_rndfldr" name="rcwdupload_rndfldr" value="<?php echo $rndfldr ?>" />
                <div id="gformsrcwdupload-wrapper-<?php echo $form_id.'-'.$field['id'] ?>" class="gformsrcwdupload-wrapper">
<?php
				if(is_object(self::$post)){	 // COMPATIBILITY GFORMS UPDATE POST PLUGIN

					if( count($value_p) > 0 and !empty($value_p[0]) ){
						
						$value 		= $value_p;
						$lead_id 	= $lead_id_p;

						$upload_info 	= GFRcwdCommon::upload_info( $form_id_p, $field['id'], $lead_id_p, 0, $rndfldr );
						
						$path_temp		= $upload_info['path_temp'];
						$path			= $upload_info['path'];
						$url_temp		= $upload_info['url_temp'];
						$url			= $upload_info['url'];
						$rndfldr		= $upload_info['rndfldr'];
										
					}else
						$value = array('');
							
				}
			
				$fcount	= 1;
				
				if($repeater == 'Y' and $repeater_min > 0 and ( $repeater_limit == 0 or $repeater_min <= $repeater_limit ) and ( $crflds = count($value) ) < $repeater_min )
					for( $i = $crflds; $i < $repeater_min; $i++)
						$value[] = array();
				
				foreach($value as $val_){

					$val = is_array($val_) ?  $val_['file'] : '';
					
					if($count > 0)
						$idsuffix = '_'.$count;
					
					if( $val != '' and $lead_id > 0 and ( !isset($_POST) or !isset($_POST['gform_target_page_number_'.$form_id]) or !isset($_POST['gform_source_page_number_'.$form_id]) )  )
						$nf_txt = __( 'To change with:', 'gforms-rcwdupload' );
					else
						$nf_txt = __( 'File:', 'gforms-rcwdupload' );												
?>
                    <div id="gforms_rcwdupload-<?php echo $form_id.$field['id'].$idsuffix ?>" class="gforms_rcwdupload <?php echo ($repeater == 'Y' ? 'rcwddragme' : '') ?> ginput_complex <?php echo $css ?>">
    					
                        <div id="gformsrcwdupload-field-inner-wrapper-<?php echo $form_id.$field['id'].$idsuffix ?>" class="gformsrcwdupload-field-inner-wrapper">
                        	<span class="gformsrcwdupload-dragme"><span><?php  _e( 'Drag me', 'gforms-rcwdupload' ); ?></span></span>
<?php
							if($repeater == 'Y'){
?>                        
                        		<span class="gformsrcwdupload-filecount"><span><?php echo $fcount ?></span></span>
<?php
							}
							
							$randomcode	= GFRcwdCommon::randomcode(array( 'length' => 3, 'uppercase' => false ));
							$datainfo 	= strrev($randomcode).base64_encode(json_encode(array(
							
								'path_temp' 			=> $path_temp,
								'formid' 				=> $form_id,
								'fid' 					=> $field['id'],
								'overw' 				=> $overwrite,
								'resize_qs'				=> $resize_or,
								'rnm' 					=> $rename,
								'rcwdupload_rndfldr' 	=> $rndfldr,
								'pv_' 					=> $preview,
								'pv_mw' 				=> $preview_max_width,
								'pv_mh' 				=> $preview_max_height,
								'pv_cr' 				=> $preview_crop,
								'randomcode'			=> $randomcode
								
							)));
?>                         
                        	<span id="ddbox-<?php echo $form_id.$field['id'].$idsuffix ?>" class="gformsrcwdplupload-ddbox"><span class="gformsrcwdplupload-ddbox-inner"><?php _e( 'Drag your file here', 'gforms-rcwdupload' ) ?></span></span>
                        	<div id="gformsrcwdplupload-container-<?php echo $form_id.$field['id'].$idsuffix ?>" class="gformsrcwdplupload-container" data-formid="<?php echo $form_id ?>" data-fid="<?php echo $field['id'] ?>" data-maxf="<?php echo $maxfiles ?>" data-upflrs='<?php echo $upfilters ?>' data-maxfsize="<?php echo $max_file_size ?>" data-overw="<?php echo $overwrite ?>" data-resize='<?php echo $resize ?>' data-csresize='<?php echo $csresize ?>' data-msel='<?php echo $multiselection ?>' data-nftxt="<?php echo $nf_txt ?>" data-clientpreview='<?php echo $clientpreview ?>' data-clientpreview_max_width='<?php echo $clientpreview_max_width ?>' data-clientpreview_max_height='<?php echo $clientpreview_max_height ?>' data-clientpreview_crop='<?php echo $clientpreview_crop ?>' data-preview='<?php echo $preview ?>' data-preview_max_width='<?php echo $preview_max_width ?>' data-preview_max_height='<?php echo $preview_max_height ?>' data-preview_crop='<?php echo $preview_crop ?>' data-repeater='<?php echo $repeater ?>' data-repeaterlimit='<?php echo $repeater_limit ?>' data-repeatermin="<?php echo $repeater_min ?>" data-repeatersortable='<?php echo $repeater_sortable ?>' data-autoupload='<?php echo $autoupload ?>' data-rename='<?php echo $rename ?>' data-chunks='<?php echo $chunks ?>' data-frc='<?php echo $frc ?>' data-hidebrowse='<?php echo $hidebrowse ?>' data-info="<?php echo $datainfo ?>">
<?php

							if( $val != '' and $lead_id > 0 and file_exists($path.$val) ){
			
								$file 			= $url.$val;
								$fsize			= size_format(filesize($path.$val));
								$flnm_pathinfo 	= pathinfo($path.$val);
								$flnm_ext		= strtolower($flnm_pathinfo['extension']);
								$editname		= IS_ADMIN ? ' <i class="fa fa-pencil gformsrcwdplupload-editname" data-formid="'.$form_id.'" data-leadid="'.$lead_id.'" data-fieldid="'.$field['id'].'" data-idsuffix="'.$idsuffix.'" onclick="gformsrcwd.rename(this)"></i>' : '';	
?>
								<div id="current-<?php echo $form_id.$field['id'].$idsuffix ?>" class="gformsrcwdplupload-current">
									<a id="removecf-<?php echo $form_id.$field['id'].$idsuffix ?>" class="gformsrcwdplupload-removecf gformsrcwd-button-delete ir" href="#"><?php _e( 'Remove', 'gforms-rcwdupload' ) ?></a>
									<div id="current-file-<?php echo $form_id.$field['id'].$idsuffix ?>" class="gformsrcwdplupload-current-file"><strong><?php _e( 'Current file:', 'gforms-rcwdupload' ) ?></strong> <a href="<?php echo $file ?>" target="_blank"><?php echo $val ?></a><?php echo $editname?></div>
									<div id="current-size-<?php echo $form_id.$field['id'].$idsuffix ?>" class="gformsrcwdplupload-current-size"><strong><?php _e( 'Size:', 'gforms-rcwdupload' ) ?></strong> <?php echo $fsize ?></div>
<?php
									if( $preview == 'Y' and in_array( strtolower($flnm_ext), array( 'jpg', 'jpeg', 'png', 'gif', 'tif', 'tiff', 'svg' ) ) ){

										if(strtolower($flnm_ext) == 'svg')
											$imgtag = '<img src="'.$file.'" alt="" style="max-width:100px">';
										else
											$imgtag = '<img src="'.GFRcwdCommon::get_dir(__FILE__).'includes/PHPThumb/thumb.php?f='.GFRcwdCommon::randomcode(array( 'length' => 3, 'uppercase' => false )).base64_encode($file).'&w='.$preview_max_width.'&h='.$preview_max_height.'&c='.$preview_crop.'&t=0&frc='.$frc.'" alt="">';										
?>                                    
                                        <div class="gformsrcwdplupload-current-preview">
                                            <?php echo $imgtag ?>
                                        </div>
<?php
									}
?>                                       
								</div>
<?php
							}
							
							if( $val != '' and ( $lead_id == 0 or ( isset($_POST) and isset($_POST['gform_target_page_number_'.$form_id]) and isset($_POST['gform_source_page_number_'.$form_id]) ) ) ){
								
								$data_showtemp 	= ' data-showtemp="1"';	
								$fsizeee		= ' data-size="'.size_format(filesize($path_temp.$val)).'"';

								if(file_exists($path_temp.$val)){
									
									$file 			= $url_temp.$val;
									$fsize			= size_format(filesize($path_temp.$val));
									$flnm_pathinfo 	= pathinfo($path_temp.$val);
									$flnm_ext		= strtolower($flnm_pathinfo['extension']);	
								
								}
																
							}else
								$data_showtemp = $fsizeee = '';
?>
                            <div id="temp-<?php echo $form_id.$field['id'].$idsuffix ?>" class="gformsrcwdplupload-temp"<?php echo $data_showtemp.$fsizeee ?>>
                                <a id="removetf-<?php echo $form_id.$field['id'].$idsuffix ?>" class="gformsrcwdplupload-removetf gformsrcwd-button-delete ir" href="#"><?php _e( 'Remove', 'gforms-rcwdupload' ) ?></a>
                                <div id="temp-file-<?php echo $form_id.$field['id'].$idsuffix ?>" class="gformsrcwdplupload-temp-file" data-temp="<?php echo urlencode($url_temp) ?>"><strong><span class="gformsrcwdplupload-temp-file-txt"></span> <a href="<?php echo $url_temp ?>" target="_blank"></a></strong></div>
                                <div id="temp-size-<?php echo $form_id.$field['id'].$idsuffix ?>" class="gformsrcwdplupload-temp-size"><strong><?php _e( 'Size:', 'gforms-rcwdupload' ) ?></strong> <span></span></div>
<?php
								if( !empty($val) and $preview == 'Y' and file_exists($path_temp.$val) and in_array( strtolower($flnm_ext), array( 'jpg', 'jpeg', 'png', 'gif', 'tif', 'tiff', 'svg' ) ) ){

									if(strtolower($flnm_ext) == 'svg')
										$imgtag = '<img src="'.$file.'" alt="" style="max-width:100px">';
									else
										$imgtag = '<img src="'.GFRcwdCommon::get_dir(__FILE__).'includes/PHPThumb/thumb.php?f='.GFRcwdCommon::randomcode(array( 'length' => 3, 'uppercase' => false )).base64_encode($file).'&w='.$preview_max_width.'&h='.$preview_max_height.'&c='.$preview_crop.'&t=0&frc='.$frc.'" alt="">';	
																			
?> 
									<div class="gformsrcwdplupload-temp-preview"><img src="<?php echo $imgtag  ?>" alt="" /></div>
<?php
									}
?>                                   
                            </div>
                            <input class="gformsrcwdplupload-file-value" type="<?php echo $ftype ?>" id="<?php echo 'input_'.$input_name.$idsuffix ?>" name="<?php echo 'input_'.$field['id']; ?>[file][]" value="<?php echo $val ?>" <?php echo $logic_event ?> autocomplete=off />
                    		<input type="<?php echo $ftype ?>" name="gformrcwduploadleadid" value="<?php echo $lead_id ?>" />
                           
                            <div id="filelist-<?php echo $form_id.$field['id'].$idsuffix ?>" class="gformsrcwdplupload-filelist">
                                <div class="gformsrcwdplupload-filewrapper">
                                    <span class="gformsrcwdplupload-filename">...</span><span id="remove-<?php echo $form_id.$field['id'].$idsuffix ?>" class="gformsrcwdplupload-remove"></span>
                                </div>
                            </div>                
                            <a id="pickfiles-<?php echo $field['id'].'-'.$form_id.$idsuffix ?>" class="button gformsrcwdplupload-button gformsrcwdplupload-pickfiles" href="#"><?php _e( 'Browse', 'gforms-rcwdupload' ) ?></a>
                            <a id="uploadfiles-<?php echo $field['id'].'-'.$form_id.$idsuffix ?>" class="button button-primary gformsrcwdplupload-button gformsrcwdplupload-uploadfiles" href="#"><?php _e( 'Upload', 'gforms-rcwdupload' ) ?></a>
<?php
                            if($field['rcwdupload_repeater'] == 'Y'){
								
								$showremove = count($value) > 1 ? ' delete_list_item_show' : '';
?>                        
                                <img style="cursor:pointer; margin:0 5px;" onclick="gformsrcwd.addItem(this, <?php echo $repeater_limit ?>)" alt="<?php _e( 'Add new line', 'gforms-rcwdupload' ) ?>" title="<?php _e( 'Add new line', 'gforms-rcwdupload' ) ?>" class="add_list_item " src="<?php echo GFCommon::get_base_url() ?>/images/add.png">
                                
                                <img onclick="gformsrcwd.deleteItem(this, 0)" style="cursor:pointer; " class="delete_list_item<?php echo $showremove ?>" alt="<?php _e( 'Remove this line', 'gforms-rcwdupload' ) ?>" title="<?php _e( 'Remove this line', 'gforms-rcwdupload' ) ?>" src="<?php echo GFCommon::get_base_url() ?>/images/remove.png">
<?php
                            }
?>                        
                            <div class="gformsrcwdplupload-clear"></div>
                            <span id="clientpreview-<?php echo $form_id.$field['id'].$idsuffix ?>" class="gformsrcwdplupload-clientpreview"></span>
                            <span id="filesize-<?php echo $form_id.$field['id'].$idsuffix ?>" class="gformsrcwdplupload-filesize"><strong><?php _e( 'Size:', 'gforms-rcwdupload' ) ?></strong><span></span></span>
                        
                        </div>
<?php
						if($field['rcwdupload_filetitle']){
							
							$val_title 	= ( is_array($val_) and isset($val_['title']) ) ? stripslashes($val_['title']) : '';
?>
                            <span class="ginput_full ginput_post_image_title gformsrcwdlupload-title">
                                <input type="text" tabindex="4" value="<?php echo $val_title ?>" id="<?php echo 'input_'.$input_name.'_title'.$idsuffix ?>" name="<?php echo 'input_'.$field['id'] ?>[title][]"> 
                                <label for="<?php echo 'input_'.$input_name.'_title'.$idsuffix ?>"><?php _e( 'File title', 'gforms-rcwdupload' ) ?></label>
                            </span>
<?php							
						}
?>                      
                    	</div>                
                    </div>                
<?php
					$fcount++;
					$count++;
				}
?>
				</div>
<?php				
				
				$input = ob_get_contents();
				ob_end_clean();
				
			}
			
			return $input;
		}
		
		return $input;
	
	}
	
	function pre_validation($form){
		
		foreach ( $form['fields'] as $field ){
			
			$field = (array)$field;
			
			if($field['type'] == 'rcwdupload')
				$_POST['input_'.$field['id']] = maybe_serialize(GFRcwdCommon::field_value_correction( $_POST['input_'.$field['id']], $field ));
						
		}
		
		return $form;
		
	}
	
	function field_validation( $result, $value, $form, $field ){
		
		if( $field['type'] == 'rcwdupload' and $field['isRequired'] ){
			
			$valid = true;

			if($value != '')
				$value = maybe_unserialize($value);
								
			if( is_array($value) and count($value) > 0){
				
				foreach($value as $k => $v){
					
					if($v['file'] == ''){
					
						$valid				= false;
						$result['is_valid']	= false;
						$result['message']	= __( 'This field is required.', 'gforms-rcwdupload' );
						
						break;
							
					}
					
				}
				
			}
			
		}
		
		return $result;
		
	}
	
	static function save_field_value( $value, $lead, $field, $form ){

		$field = (array)$field;

		if($field['type'] == 'rcwdupload'){
									
			$mode = isset($_POST["screen_mode"]) ?  $_POST["screen_mode"] : '';

			if( IS_ADMIN and $mode != 'view' and ( !isset($_POST['action']) or $_POST['action'] != 'update' ) and ( !defined('DOING_AJAX') or !DOING_AJAX or ( DOING_AJAX and !isset($_REQUEST['action']) or ( $_REQUEST['action'] != 'quick_checkout_action' and $_REQUEST['action'] != 'woocommerce_update_order_review' ) ) ) ){ 

				if($value != '')
					$value = GFRcwdCommon::field_value_correction( maybe_unserialize($value), $field );
				
			}else{
				
				if($mode == 'view')
					if($value != '')
						$value = GFRcwdCommon::field_value_correction( maybe_unserialize($value), $field );	
										
				if(!empty($lead['id'])){
						
					if($value != '')
						$value = maybe_unserialize($value);

					$value_ 		= $value;					
					$ftodelete 		= false;
					$upload_info	= GFRcwdCommon::upload_info( $form['id'], $field['id'], $lead['id'] );
					$rename 		= isset($field['rcwdupload_rename']) ? $field['rcwdupload_rename'] : '';
					$rnm_replace	= array( $form['id'], $field['id'], $lead['id'],  preg_replace( '/[^\w\._]+/', '_', $field['label'] ) );
					$rnm_creplace	= (array)apply_filters( 'gforms_rcwdupload_rename_tags_replace', array(), $form['id'], $field['id'], $lead['id'] );
					
					if(count($rnm_creplace) > 0)
						$rnm_creplace = array_merge( $rnm_replace, $rnm_creplace );

					if(!empty($rename)){
						
						preg_match_all('/\[field:(\d)+\.?(\d)*\]/i', $rename, $matches );
	
						if(count($matches[0]) > 0){
							
							foreach($matches[0] as $match){
								
								$ofid	= str_replace( array( '[field:', ']' ), '', $match );
								$ofield	= GFFormsModel::get_field( $form, $ofid );

								if($ofield->type == 'name'){
									
									$ofvalue = array();
									
									foreach($ofield['inputs'] as $namei){
										
										$nameid = $namei['id'];
										$rgpost	= rgpost('input_'.str_replace( '.', '_', $nameid ));
										
										if(!empty($rgpost))
											$ofvalue[] = str_replace( '.', '', $rgpost );
										
									}
									
									$ofvalue = implode( '-', $ofvalue );
									
								}else{
									
									$ofinput_name	= 'input_'.str_replace( '.', '_', $ofid );
									$rgpost			= rgpost($ofinput_name);
									$ofvalue 		= str_replace( '.', '', $rgpost );
									
								}
								
								$rename = str_replace( $match, $ofvalue, $rename );
								
							}
							
						}
						
					}

					if( class_exists("GFUser") or class_exists("GF_User_Registration") ){					

						$gfurclass = self::$gfurclass;
					
						if(self::$gfurd == 'old'){
							
							$feed			= $gfurclass::get_current_feed();
							$has_feed_type	= $gfurclass::has_feed_type( 'create', $form, $feed['id'] );
							$config			= $gfurclass::get_feeds($form_id);
							
						}else{
							
							$feed 			= gf_user_registration()->get_current_feed();
							$has_feed_type	= gf_user_registration()->has_feed_type( 'create', $form, $feed['id'] );
							$config 		= gf_user_registration()->get_feeds($form_id);
							
						}
	
						if($has_feed_type){
							
							global $rcwduploadgf_names;
							
							if(empty($rcwduploadgf_names)){	
							
								$changed = false;
							
								$rcwduploadgf_names[$form['id']] = array(
								
									'changed' 	=> false,
									'names'		=> array()
									
								);
							
							}
													
						}	
					
					}

					if( is_array($value) and count($value) > 0){
						
						foreach($value_ as $key => $v){

							if(!empty($v['file'])){
								
								$flnm 			= $v['file'];
								$flnm_pathinfo 	= pathinfo($flnm);
								$flnm_ext		= strtolower($flnm_pathinfo['extension']);
								$flnmonly		= $flnm_pathinfo['filename'];

								if(!empty($rename)){
																	
									$flnm_		= sanitize_file_name(str_replace( self::$rnm_search, $rnm_replace, $rename ));
									$flnm		= $flnm_.'.'.$flnm_ext;
									$flnmonly	= $flnm_;
								
								}
								
								$fnt			= $upload_info['path_temp'].$v['file'];
								$f				= $upload_info['path'];
								$fn				= $f.$flnm;
								$mtn			= false;
								$currleadid 	= (int)$_POST['gformrcwduploadleadid'];
								$currlead		= GFRcwdCommon::get_lead($currleadid);
								$currfilename	= '';
								
								if(!empty($currlead)){									
													
									if (!isset($field['rcwdupload_repeater']) or strtolower($field['rcwdupload_repeater']) != 'Y'){

										$lllead = RGFormsModel::get_lead($currleadid);
	
										foreach( $form['fields'] as $fffield ){
											
											$fffield = (array)$fffield;
	
											if( $fffield['type'] == 'rcwdupload' and $fffield['id'] == $field['id'] ){
												
												$currfieldvalue = $lllead[$field['id']]; 
	
												break;
												
											}
											
										}
									
										if(!empty($value)){
											
											$currfieldvalue = maybe_unserialize($currfieldvalue);
										
											if( is_array($currfieldvalue) and count($currfieldvalue) > 0 and is_array($currfieldvalue[0]) and isset($currfieldvalue[0]['file']) and !empty($currfieldvalue[0]['file']) ){
												
												$currfilename = $currfieldvalue[0]['file'];
												
											}
											
										}
										
									}
									
								}

								if( file_exists($fnt) and file_exists($fn) and ( empty($currfilename) or $currfilename != $flnm ) ){

									$count = 1;
									
									while (file_exists($f.$flnmonly.'_'.$count.'.'.$flnm_ext))
										$count++;
										
									$flnm	= $flnmonly.'_'.$count.'.'.$flnm_ext;
									$fn 	= $f.$flnm;
									
								}
															
								if( ( class_exists("GFUser") or class_exists("GF_User_Registration") ) and $has_feed_type ){
									
									if(count($rcwduploadgf_names[$form['id']]['names']) > 0){
										
										if(in_array( $flnm, $rcwduploadgf_names[$form['id']]['names'] )){
											
											$count = 1;
											
											while (in_array( $flnmonly.'_'.$count.'.'.$flnm_ext, $rcwduploadgf_names[$form['id']]['names'] ))
												$count++;	
												
											$flnm										= $flnmonly.'_'.$count.'.'.$flnm_ext;	
											$fn 										= $f.$flnm;	
											$rcwduploadgf_names[$form['id']]['changed'] = true;									
											
										}
										
									}
									
									$rcwduploadgf_names[$form['id']]['names'][] = $flnm; 
									
								}

								if(is_object(self::$post)){	 // COMPATIBILITY GFORMS UPDATE POST PLUGIN
							
									$value_p = get_post_meta( self::$post->ID, sanitize_title('_gforms_rcwdupload_'.$field['label']), true );

									if( !empty($value_p) and !empty($value_p[0]) ){
									
										$value_p		= maybe_unserialize($value_p);
										$form_id_p		= $value_p[0]['form_id'];
										$lead_id_p  	= $value_p[0]['entry_id'];

										if(!empty($rename)){
		
											$rnm_replace[2]	= $lead_id_p;
											$flnm_ 			= str_replace( self::$rnm_search, $rnm_replace, $rename );
											$flnm 			= $flnm_.'.'.$flnm_ext;
											
										}
																		
										$upload_info_p 	= GFRcwdCommon::upload_info( $form_id_p, $field['id'], $lead_id_p );	
										$f				= $upload_info_p['path'];	
										$fn_			= $fn;
										$fn				= $f.$flnm;
										$mtn			= true;

										if( file_exists($fnt) and file_exists($fn) and ( empty($currfilename) or $currfilename != $flnm ) ){
											
											$count = 1;
											
											while (file_exists($f.$flnmonly.'_'.$count.'.'.$flnm_ext))
												$count++;
												
											$flnm	= $flnmonly.'_'.$count.'.'.$flnm_ext;
											$fn 	= $f.$flnm;
											
										}
								
									}
											
								}
		
								if(file_exists($fnt)){

									$external = (bool)apply_filters( 'gforms_rcwdupload_up_is_external_'.$form['id'].'_'.$field['id'], (bool)apply_filters( 'gforms_rcwdupload_up_is_external_'.$form['id'], (bool)apply_filters( 'gforms_rcwdupload_up_is_external', false, $form['id'], $field['id'], $lead['id'] ), $field['id'], $lead['id'] ), $lead['id'] );
		
									if($external){
		
										do_action( 'gforms_rcwdupload_up_in_external', $fnt, $form['id'], $field['id'], $lead['id'] );
											
										$value[$key]['file'] = apply_filters( 'gforms_rcwdupload_filter_up_in_external', $v['file'], $fnt, $form['id'], $field['id'], $lead['id'] );
										
									}else{

										do_action( 'gforms_rcwdupload_before_move_file_to_realpath', $fnt, $fn, $form['id'], $field['id'], $lead['id'] );

										if( !empty($currfilename) and file_exists($f.$currfilename) )
											@unlink($f.$currfilename);
										
										copy( $fnt, $fn );

										do_action( 'gforms_rcwdupload_after_move_file_to_realpath', $fn, $form['id'], $field['id'], $lead['id'] );
									
									}
									
								}elseif(!file_exists($fn)){

									unset($value[$key]);
									
								}elseif($mtn){

									copy( $fn, $fn_ );
								
								}
								
								$value[$key]['file'] 		= $flnm;
								$value[$key]['form_id'] 	= $form['id'];
								$value[$key]['field_id']	= $field['id'];
								$value[$key]['entry_id']	= $lead['id'];						
						
								
							}else{
							
								unset($value[$key]);
								
							}
							
						}
						
					}
				
				}

			}
	
			if( is_array($value) and count($value) > 0 )
				$value = maybe_serialize($value);
			else
				$value = '';
			
		}

		return $value;
		
	}	

	function gform_user_registered( $user_id, $config, $entry ){

		$form 	= RGFormsModel::get_form_meta($entry['form_id']);
		$fields	= $form['fields'];
		$names	= array();

		foreach($fields as $field){
			
			$changed = false;
			
			if($field['type'] == 'rcwdupload'){
				
				$upload_info 	= GFRcwdCommon::upload_info( $entry['form_id'], $field['id'], $entry['id'] );	
				$filefields		= $entry[$field['id']];
				$filefields		= maybe_unserialize($filefields);
				$newpath		= GFORMS_RCWDUPLOAD_UP_DIR.RCWD_DS.'users'.RCWD_DS.$user_id.RCWD_DS;
				
				if(!empty($filefields)){
					
					wp_mkdir_p($newpath);
					
					foreach($filefields as $key => $filefield){
						
						$filename	= $filefield['file'];
						$origname	= $filename;

						if(count($names) > 0){
							
							if(in_array( $filename, $names )){

								$flnm_pathinfo 	= pathinfo($filename);
								$flnm_ext		= strtolower($flnm_pathinfo['extension']);
								$flnmonly		= $flnm_pathinfo['filename'];
								$count 			= 1;
								
								while (in_array( $flnmonly.'_'.$count.'.'.$flnm_ext, $names ))
									$count++;
									
								$filename 					= $flnmonly.'_'.$count.'.'.$flnm_ext;	
								$filefields[$key]['file']	= $filename;
								$changed 					= true;							
								
							}
							
						}
						
						$names[] = $filename;

						rename( $upload_info['path'].$origname, $newpath.$filename );
						
					}
					
					if( $changed and class_exists('GFAPI') )
						GFAPI::update_entry_field( $entry['id'], $field['id'], maybe_serialize($filefields) );
				
				}
				
			}
			
		}
		
	}

	function gform_user_updated( $user_id, $config, $entry, $user_pass ){

		$form 	= RGFormsModel::get_form_meta($entry['form_id']);
		$fields	= $form['fields'];
		
		foreach($fields as $field){
			
			if($field['type'] == 'rcwdupload'){
				
				$upload_info 	= GFRcwdCommon::upload_info( $entry['form_id'], $field['id'], $entry['id'] );	
				$filefields		= $entry[$field['id']];
				$filefields		= maybe_unserialize($filefields);
				$newpath		= GFORMS_RCWDUPLOAD_UP_DIR.RCWD_DS.'users'.RCWD_DS.$user_id.RCWD_DS;

				wp_mkdir_p($newpath);
				
				if(!empty($filefields))
					foreach($filefields as $filefield){
						
						$filename = $filefield['file'];
				
						rename( $upload_info['path'].$filename, $newpath.$filename );
						
					}
				
			}
			
		}
				
	}	

	function entry_post_save( $lead, $form ){

		foreach($form['fields'] as $k => $v){
			
			if($v['type'] == 'rcwdupload'){
				
				$only_name = (bool)apply_filters( 'gforms_rcwdupload_notification_only_name_'.$form['id'], (bool)apply_filters( 'gforms_rcwdupload_notification_only_name', true, $lead, $form['id'] ), $lead );
				
				if($only_name)
					$lead[$v['id']] =  preg_replace('/<a href=\"(.*?)\">(.*?)<\/a>/', "\\2", $lead[$v['id']] );
				
			}
		}

		return $lead;
		
	}

	function merge_tag_filter( $value, $merge_tag, $options, $field, $raw_value ){

		$field = (array)$field;

		if( $field["type"] == "rcwdupload"){
				
			if(!empty($raw_value)){
					
				if(is_serialized($raw_value)){
				
					$value_ 	= maybe_unserialize($raw_value);
					$entry_id 	= $value_[0]['entry_id'];
					$form_id 	= $value_[0]['form_id'];
					$lead 		= GFRcwdCommon::get_lead($entry_id);	
					$only_name	= (bool)apply_filters( 'gforms_rcwdupload_notification_only_name_'.$form_id, (bool)apply_filters( 'gforms_rcwdupload_notification_only_name', false, $lead, $form_id ), $lead );
					$userid		= 0;
					
					if( class_exists("GFUser") or class_exists("GF_User_Registration") ){

						$gfurclass = static::$gfurclass;
						
						if(static::$gfurd == 'old'){	
					
							require_once($gfurclass::get_base_path()."/data.php");

							$config	= $gfurclass::get_feeds_by_form($form_id);
							$user	= $gfurclass::get_user_by_entry_id($entry_id);
						
						}else{
							
							$config	= gf_user_registration()->get_feeds($form_id);
							$user	= gf_user_registration()->get_user_by_entry_id($entry_id);							
							
						}
						
						$userid = $user ? $user->ID : 0;

					}
					
					if($only_name)
						$mode = 'only_name';	
					else
						$mode = '';	

					$show = apply_filters( 'gforms_rcwdupload_merge_tag_filter_'.$form_id, apply_filters( 'gforms_rcwdupload_merge_tag_filter', $mode, $lead, $form_id ), $lead );

					switch($show){
						
						case 'only_name':
						case 'name':
						
							$mode = 'only_name';
							
							break;

						case '':
						case 'link':
						
							$mode = '';
							
							break;	

						case 'url':
						
							$mode = 'url';
							
							break;															
						
					}

					$value = GFRcwdCommon::format_value(array(
					
						'value' 	=> $raw_value,
						'lead' 		=> $lead,
						'field' 	=> $field,
						'form_id' 	=> $form_id,
						'mode'		=> $mode,
						'userid'	=> $userid
																
					));				
					
				}else
					$value = $raw_value;	
					
				$value = html_entity_decode($value);
					
			}
		
		}

		return $value;
		
	}

	function allowable_tags( $allowable_tags, $field, $form_id ){

		$field = (array)$field;
		
		if($field['type'] == 'rcwdupload')
			return true;
		
		return $allowable_tags;
	}
	
	function get_input_value($value, $lead, $field, $input_id){

		$field = (array)$field;

		if($field['type'] == 'rcwdupload'){

			$mode = isset($_POST["screen_mode"]) ?  $_POST["screen_mode"] : '';

			if( isset($_REQUEST['api_key']) and !empty($_REQUEST['api_key']) and isset($_REQUEST['expires']) and !empty($_REQUEST['expires']) and isset($_REQUEST['signature']) and !empty($_REQUEST['signature']) ){
	
				$field = (array)$field;

				if($field['type'] == 'rcwdupload'){
	
					$value = GFRcwdCommon::format_value(array(
					
						'value' 	=> $value,
						'lead' 		=> $lead,
						'field' 	=> $field,
						'form_id' 	=> $field['formId'],
						'mode'		=> 'url'
						
					));	
				
				}			
		
			}elseif( IS_ADMIN and $mode != 'edit' and ( !defined('DOING_AJAX') or !DOING_AJAX or ( DOING_AJAX and !isset($_REQUEST['action']) or ( $_REQUEST['action'] != 'quick_checkout_action' and $_REQUEST['action'] != 'woocommerce_update_order_review' ) ) ) ){ 

				$userid = 0;
				
				if( class_exists("GFUser") or class_exists("GF_User_Registration") ){

					$gfurclass = static::$gfurclass;

					if(static::$gfurd == 'old'){	
				
						require_once(GFUser::get_base_path()."/data.php");

						$config		= $gfurclass::get_update_feed($lead['form_id']);
						$user		= $gfurclass::get_user_by_entry_id($lead['id']);
					
					}else{
						
						$config	= gf_user_registration()->get_update_feed($lead['form_id']);
						$user	= gf_user_registration()->get_user_by_entry_id($lead['id']);							
						
					}
											
					$userid = $user ? $user->ID : 0;
					
				}

				$page = GFForms::get_page();
				$mode = isset($_POST["screen_mode"]) ?  $_POST["screen_mode"] : 'view';
				
				if( isset($_POST['action']) and $_POST['action'] == 'gf_resend_notifications' ){

					$value = GFRcwdCommon::format_value(array(
					
						'value' 	=> $value,
						'lead' 		=> $lead,
						'field' 	=> $field,
						'input_id' 	=> $input_id,
						'form_id' 	=> $lead['form_id'],
						'userid' 	=> $userid
																
					));
													
				}else{

					if( isset($_POST) and isset($_POST['action']) and $_POST['action'] == 'gf_process_export' ){
						
						$value = GFRcwdCommon::format_value(array(
						
							'export'	=> true,
							'value' 	=> $value,
							'simpleurl'	=> true,
							'lead' 		=> $lead,
							'field' 	=> $field,
							'input_id' 	=> $input_id,
							'form_id' 	=> $lead['form_id'],
							'userid' 	=> $userid,
						
						));						
						
					}else{

						switch($page){
							
							case 'entry_list':
		
								$value = GFRcwdCommon::format_value(array(
								
									'mode' 		=> 'only_name',
									'value' 	=> $value,
									'lead' 		=> $lead,
									'field' 	=> $field,
									'input_id' 	=> $input_id,
									'form_id' 	=> $lead['form_id'],
									'userid' 	=> $userid
								
								));
								
								break;
								
							case 'entry_detail':
							
								if( isset($_POST['action']) and $_POST['action'] == 'update' and $mode == 'view' ){							
			
								}else{
		
									$value = GFRcwdCommon::format_value(array(
									
										'value' 	=> $value,
										'lead' 		=> $lead,
										'field' 	=> $field,
										'input_id' 	=> $input_id,
										'form_id' 	=> $lead['form_id'],
										'userid' 	=> $userid
																				
									));
																		
								}
								
								break;
								
							case 'export_entry':
							
								$value = GFRcwdCommon::format_value(array(
								
									'value' 	=> $value,
									'simpleurl'	=> true,
									'lead' 		=> $lead,
									'field' 	=> $field,
									'input_id' 	=> $input_id,
									'form_id' 	=> $lead['form_id'],
									'userid' 	=> $userid
								
								));
								
								break;
								
						}
					
					}
				
				}
			
			}
			
		}
		
		return $value;
		
	}
	
	function entries_field_value( $value, $form_id, $field_id, $lead ){

		return $value;
		
	}
	
	function entry_field_value( $value, $field, $lead, $form ){

		if($field['type'] == 'rcwdupload')
			return htmlspecialchars_decode($value);

		return $value;
		
	}

	function gform_delete_lead($entry_id){
		
		$entry 	= GFRcwdCommon::get_lead($entry_id);
		$form 	= RGFormsModel::get_form_meta($entry['form_id']);
		$fields = GFCommon::get_fields_by_type( $form, array('rcwdupload'));

        if(is_array($fields)){
						
            foreach($fields as $field){
				
				if( (int)$entry['form_id'] > 0 and (int)$field['id'] > 0 and (int)$entry_id > 0){
					
					$upload_info	= GFRcwdCommon::upload_info( $entry['form_id'], $field['id'], $entry_id );
				  //$value 			= RGFormsModel::get_lead_field_value($entry, $field);
					GFRcwdCommon::remove_dir( $upload_info['path'], false );

				}
						
            }
			
        }		

	}
	
	function gform_delete_entries( $form_id, $status ){
		
		if($status == 'trash'){
			
			$form	= RGFormsModel::get_form_meta($form_id);
			$fields = GFCommon::get_fields_by_type( $form, array('rcwdupload') );
			
			if(is_array($fields)){
				
				$leads = GFFormsModel::get_leads( $form_id, 0, 'DESC', '', 0, 999,  null, null, false, null, null, $status );

				if(count($leads) > 0){
	
					foreach($leads as $lead){
										
						foreach($fields as $field){
		
							if( (int)$form_id > 0 and (int)$field['id'] > 0 and (int)$lead['id'] > 0){
								
								$upload_info = GFRcwdCommon::upload_info( $form_id, $field['id'], $lead['id'] );

								GFRcwdCommon::remove_dir( $upload_info['path'], false );
			
							}
											
						}
						
					}
			
				}
		
			}
			
		}
		
	}

}

function gforms_rcwdupload_load(){
	
	if ( class_exists('GFForms') or class_exists('RGForms') ){
		
		new gforms_rcwdupload_plugin();
		
		require_once(plugin_dir_path( __FILE__ ).'gfru-field.php');
				
	}
		
}
add_action( 'plugins_loaded', 'gforms_rcwdupload_load' );
?>