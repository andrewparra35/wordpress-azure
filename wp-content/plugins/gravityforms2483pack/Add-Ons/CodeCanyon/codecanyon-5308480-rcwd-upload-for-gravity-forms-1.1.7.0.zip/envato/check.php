<?php
$check 			= get_option('gforms_rcwdupload_verifypurchase');
$username		= isset($check['username']) 		? trim($check['username'] )		: '';
$purchase_code	= isset($check['purchase_code'])	? trim($check['purchase_code']) : '';
$api_key		= isset($check['api_key'])			? trim($check['api_key']) 		: '';
$msgis			= '';
$msg			= '';

if(isset($_POST['submit'])){
	
	$username 		= trim($_POST['username']);
	$purchase_code	= trim($_POST['purchase_code']);
	$api_key		= trim($_POST['api_key']);

	if( !empty($username) and !empty($purchase_code) ){
		
		update_option( 'gforms_rcwdupload_verifypurchase', array(
		
			'username' 		=> $username,
			'purchase_code' => $purchase_code,
			'api_key' 		=> $api_key
			
		) );
		
		if(GFRcwdCommon::serial_is_valid(true))
			$msgis = 'welldone';
		else
			$msgis = 'error';
					
	}else
		$msgis = 'error';
	
}else{
	
	if(is_array($check)){
		 
		if(GFRcwdCommon::serial_is_valid(true)){
	
			$msgis = 'welldone';
			
		}else{
			
			$msgis = 'error';
			
		}
	
	}

}

if($msgis == 'welldone')
	$msg = '<p class="welldone">'.__( 'Well Done, all data is correct! The item is properly registered.', 'gforms-rcwdupload' ).'</p>';
elseif($msgis == 'error')
	$msg = '<p class="error">'.__( 'Sorry, your data is invalid. Please insert valid data.', 'gforms-rcwdupload' ).'</p>';
?>
<style>
#gforms-rcwdupload-checkpage p.welldone{	color:#090;
											font-size:14px;
											font-weight:bold;
}
#gforms-rcwdupload-checkpage p.error{		color:#ff0000;
											font-size:14px;
											font-weight:bold;
}
#gforms-rcwdupload-checkform table input{	font-size:14px;
											letter-spacing:1px;
}
</style>

<div id="gforms-rcwdupload-checkpage" class="wrap">

	<h2><?php _e( 'Rcwd Upload: an add-on for Gravity Forms plugin', 'gforms-rcwdupload' ) ?></h2>
	<h3><?php _e( '&rarr; Purchase verification', 'gforms-rcwdupload' ) ?></h3>

<?php
	if($msg != '')
		echo $msg;
?>
    <form id="gforms-rcwdupload-checkform" action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
        <table class="form-table">
            <tbody>
                <tr valign="top">
                    <th scope="row"><label><?php _e( 'Marketplace Username:', 'gforms-rcwdupload' ) ?></label></th>
                    <td><input type="text" name="username" class="regular-text" value="<?php echo $username ?>" />
                    <br />
                    <?php _e( 'Insert your Envato account username.', 'gforms-rcwdupload' ) ?>
                    </td>
                </tr>		
                <tr valign="top">
                    <th scope="row"><label><?php _e( 'Purchase code:', 'gforms-rcwdupload' ) ?></label></th>
                    <td><input type="text" name="purchase_code" class="regular-text" value="<?php echo $purchase_code ?>" />
                    <br />
                    <?php printf( __( 'Insert the Purchase code for this item <a href="%1s" target="_blank">(click here for help)</a>.', 'gforms-rcwdupload' ), GFRcwdCommon::get_dir(__FILE__).'img/getitempc.jpg' ) ?></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label><?php _e( 'Secret API Key:', 'gforms-rcwdupload' ) ?></label></th>
                    <td><input type="password" name="api_key" class="regular-text" value="<?php echo $api_key ?>" />
                    <br />
                    <?php printf( __( 'You can find API key by visiting your Envato Account page, then clicking the My Settings tab.<br />At the bottom of the page you\'ll find your account\'s API key.<br />By filling this field, you will enable <strong>automatic updates</strong>.', 'gforms-rcwdupload' ), GFRcwdCommon::get_dir(__FILE__).'img/getitempc.jpg' ) ?></td>
                </tr>	                		
            </tbody>
        </table>
        <p class="submit"><input class="button button-primary" type="submit" name="submit" value="<?php _e( 'Verify', 'gforms-rcwdupload' ) ?>" /></p>
    </form>

</div>

<div>
    <h3><?php _e( 'Permalink structure bug', 'gforms-rcwdupload' ) ?></h3>
    <p style="background:#fff;padding:20px;">
<?php 
        _e( 'You click the linked file in notification mail or in entry detail, and it opens the 404 page?<br />Please open the readme file and check the f.a.q. section in order to fix it ;)<br /><br />If this will not fix it, please send an email to <a href="mailto:roberto@cantarano.com">roberto@cantarano.com</a> with your htaccess file attached and all info about your server type (windows or linux), your license code and plugin name.', 'gforms-rcwdupload' );
		echo '<br />';
        _e( 'Anyway you can manually edit the htaccess file and add those 2 lines BEFORE the line "RewriteCond %{REQUEST_FILENAME} -f [OR]":', 'gforms-rcwdupload' );
?> 
<br /><br />
        RewriteRule ^([_0-9a-zA-Z-]+/)?gformsrcwdup/([^/\.]*)/[^/\.]+/([^/\.]+)/([^/]+)/([^/]+)/((.+)(\.[^.]*$|$))?$ //?mode=$2&gformsrcwduplddwnlod=$3&fid=$4&leadid=$5&file=$6 [QSA,L]<br>
        RewriteRule ^([_0-9a-zA-Z-]+/)?gformsrcwdup/([^/\.]*)/([^/\.]*)/user/([^/]+)/((.+)(\.[^.]*$|$))?$ //?mode=$2&gformsrcwduplddwnlod=$3&userid=$4&file=$5 [QSA,L]     
    </p>
</div>