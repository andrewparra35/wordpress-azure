<?php
class GFRcwdRules{

	static function generate_rewrite_rules($wp_rewrite){ 
		
		$new_non_wp_rules = array(
		
			'([_0-9a-zA-Z-]+/)?gformsrcwdup/([^/\.]*)/[^/\.]+/([^/\.]+)/([^/]+)/([^/]+)/((.+)(\.[^.]*$|$))?$'	=> '/?mode=$2&gformsrcwduplddwnlod=$3&fid=$4&leadid=$5&file=$6',
			'([_0-9a-zA-Z-]+/)?gformsrcwdup/([^/\.]*)/([^/\.]*)/user/([^/]+)/((.+)(\.[^.]*$|$))?$'				=> '/?mode=$2&gformsrcwduplddwnlod=$3&userid=$4&file=$5'
			
		);
		
		$new_non_wp_rules 			= apply_filters( 'gforms_rcwdupload_rewrite_rules', $new_non_wp_rules );
		$wp_rewrite->non_wp_rules 	= $new_non_wp_rules + $wp_rewrite->non_wp_rules;
		
	}
	
	static function flush_rules(){
	
		global $wp_rewrite;

		$wp_rewrite->flush_rules();
			
	}
	
}
?>