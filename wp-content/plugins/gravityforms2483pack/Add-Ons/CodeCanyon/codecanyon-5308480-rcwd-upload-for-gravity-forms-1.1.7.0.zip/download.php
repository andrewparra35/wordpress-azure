<?php

if( isset($_GET['gformsrcwduplddwnlod']) and isset($_GET['file']) ){
	
	$formid			= filter_var( $_GET['gformsrcwduplddwnlod'], FILTER_SANITIZE_NUMBER_INT );
	$fid			= isset($_GET['fid']) ? filter_var( $_GET['fid'], FILTER_SANITIZE_NUMBER_INT ) 			: '';
	$leadid			= isset($_GET['leadid']) ? filter_var( $_GET['leadid'], FILTER_SANITIZE_NUMBER_INT ) 	: '';
	$file_name		= filter_var( $_GET['file'], FILTER_SANITIZE_URL );
	$userid			= isset($_GET['userid']) ? filter_var( $_GET['userid'], FILTER_SANITIZE_NUMBER_INT ) 	: 0;
	$upload_info 	= GFRcwdCommon::upload_info( $formid, $fid, $leadid, $userid );
	$file_path 		= $upload_info['path'].$file_name;

	if (!file_exists($file_path))
		_e( 'File not found :(', 'gforms-rcwdupload' );
		
	else{
		
		$mode	= (int)@$_GET['mode'];
		$cdisp 	= 'inline';

		if($mode == 1)
			$cdisp = 'attachment';
							
		$length		= filesize($file_path);
		$file_ext 	= strtolower(substr( strrchr( $file_name, "." ), 1 ));		

		switch($file_ext){
			
			case "pdf"	: $file_type = "application/pdf"; 				break;
			case "exe"	: $file_type = "application/octet-stream"; 		break;
			case "zip"	: $file_type = "application/zip"; 				break;
			case "doc"	: $file_type = "application/msword"; 			break;
			case "xls"	: $file_type = "application/vnd.ms-excel"; 		break;
			case "ppt"	: $file_type = "application/vnd.ms-powerpoint"; break;
			case "gif"	: $file_type = "image/gif"; 					break;
			case "png"	: $file_type = "image/png";		 				break;
			case "jpeg"	: $file_type = "image/jpg"; 					break;
			case "jpg"	: $file_type = "image/jpg"; 					break;
			case "mp3"	: $file_type = "application/mpeg"; 				break;
			case "wav"	: $file_type = "application/x-wav"; 			break;
			case "mpeg"	: $file_type = "application/mpeg"; 				break;
			case "mpg"	: $file_type = "application/mpeg"; 				break;
			case "mpe"	: $file_type = "application/mpeg"; 				break;
			case "mov"	: $file_type = "application/quicktime"; 		break;
			case "avi"	: $file_type = "application/x-msvideo"; 		break;
	
			case "php"	:
			case "htm"	:
			case "html"	: die(__( 'Sorry, file extension not allowed.', 'gforms-rcwdupload' )); break;
	
			default: $file_type = "application/force-download";
			
		}

		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		//header("Cache-Control: public");
		header("Content-Description: File Transfer");
		header("Content-type: $file_type");  
		header("Content-Disposition: $cdisp; filename= ".$file_name);
		header("Content-Transfer-Encoding: binary");
		header("Content-Length: ".$length);
		readfile($file_path);
													
	}
	
}else
	_e( 'File not found :(', 'gforms-rcwdupload' );	

die();
?>