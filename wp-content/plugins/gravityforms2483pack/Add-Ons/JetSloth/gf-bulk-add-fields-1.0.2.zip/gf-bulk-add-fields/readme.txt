=== Gravity Forms Bulk Add Fields ===
Contributors: jetsloth
Tags: admin,gravityforms,forms
Requires at least: 4.0
Tested up to: 4.8
Version: 1.0.2
License: GPL2
License URI: http://www.gnu.org/licenses/old-licenses/gpl-2.0.html

Easily add fields in bulk

== Description ==
**Gravity Forms Bulk Add Fields**

Easily add fields in bulk

== Installation ==
1. Install Gravity Forms Bulk Add Fields by uploading the files to your server
2. Activate the plugin through the \'Plugins\' menu in WordPress
3. Make sure you also have Gravity Forms activated (at least v2.0)
4. Enter your license key in the Gravity Forms Image Choices settings tab through the 'Forms > Settings' menu in Wordpress
6. Read the documentation and watch our videos for more info

== Frequently Asked Questions ==

= Does this plugin rely on anything? =
Yes, you need to install the [Gravity Forms Plugin](http://themergency.com/gravity-forms-addon-plugins/) for this plugin to work. And it needs to be at least v2.0
