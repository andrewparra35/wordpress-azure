<?php

namespace ForGravity\EntryAutomation\Action;

use ForGravity\EntryAutomation\Action;
use GFAPI;
use GFCommon;
use GFExport;
use GF_Field;
use GFFormsModel;

if ( ! class_exists( '\ForGravity\EntryAutomation\Action' ) ) {
	require_once fg_entryautomation()->get_base_path() . '/includes/class-action.php';
}

class Export extends Action {

	/**
	 * Contains an instance of this class, if available.
	 *
	 * @since  1.2
	 * @access protected
	 * @var    object $_instance If available, contains an instance of this class.
	 */
	protected static $_instance = null;

	/**
	 * Defines the action name.
	 *
	 * @since  1.2
	 * @access protected
	 * @var    string $action Action name.
	 */
	protected $name = 'export';

	/**
	 * Autoload export type classes.
	 *
	 * @since  1.4
	 * @access public
	 */
	public function __construct() {

		parent::__construct();

		require_once 'export/class-csv.php';
		require_once 'export/class-json.php';
		require_once 'export/class-pdf.php';

	}




	// # ACTION SETTINGS -----------------------------------------------------------------------------------------------

	/**
	 * Settings fields for configuring this Entry Automation action.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @return array
	 */
	public function settings_fields() {

		return array( $this->base_settings(), $this->email_settings() );

	}

	/**
	 * Prepare export settings.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @uses   Export::get_fields_as_choices()
	 * @uses   Entry_Automation::get_actions_as_choices()
	 * @uses   Entry_Automation::is_current_section()
	 *
	 * @return array
	 */
	public function base_settings() {

		return array(
			'id'         => 'section-export',
			'class'      => 'entryautomation-feed-section',
			'tab'        => array(
				'label' => esc_html__( 'Export Settings', 'forgravity_entryautomation' ),
				'icon'  => 'fa-file-excel-o',
			),
			'dependency' => array( 'field' => 'action', 'values' => array( 'export' ) ),
			'fields'     => array(
				array(
					'name'          => 'exportFileType',
					'label'         => esc_html__( 'File Type', 'forgravity_entryautomation' ),
					'type'          => 'radio',
					'required'      => true,
					'horizontal'    => true,
					'default_value' => 'csv',
					'onclick'       => "jQuery( this ).parents( 'form' ).submit()",
					'choices'       => array(
						array(
							'value' => 'csv',
							'label' => esc_html__( 'CSV', 'forgravity_entryautomation' ),
						),
						array(
							'value' => 'json',
							'label' => esc_html__( 'JSON', 'forgravity_entryautomation' ),
						),
						array(
							'value' => 'pdf',
							'label' => esc_html__( 'PDF', 'forgravity_entryautomation' ),
						),
					),
				),
				array(
					'name'          => 'exportFileName',
					'label'         => esc_html__( 'File Name', 'forgravity_entryautomation' ),
					'type'          => 'text',
					'required'      => true,
					'class'         => 'medium',
					'default_value' => '{form_title}-{timestamp}',
					'tooltip'       => sprintf(
						'<h6>%s</h6>%s<br /><br />%s',
						esc_html__( 'Export File Name', 'forgravity_entryautomation' ),
						esc_html__( 'Set the file name for entry export file.', 'forgravity_entryautomation' ),
						sprintf(
							esc_html__( 'Available merge tags: %s', 'forgravity_entryautomation' ),
							implode( ', ', array(
								'{form_id}',
								'{form_title}',
								'{timestamp}',
								'{date}',
								'{date:format}',
							) )
						)
					),
				),
				array(
					'name'    => 'exportOverwriteExisting',
					'label'   => null,
					'type'    => 'checkbox',
					'choices' => array(
						array(
							'name'    => 'exportOverwriteExisting',
							'label'   => esc_html__( 'Overwrite existing export file', 'forgravity_entryautomation' ),
							'tooltip' => sprintf(
								'<h6>%s</h6>%s',
								esc_html__( 'Overwrite Existing Export File', 'forgravity_entryautomation' ),
								esc_html__( 'If an export file is found with the same file name, it will overwrite the file instead of incrementing the file name.', 'forgravity_entryautomation' )
							),
						),
					),
				),
				array(
					'name'     => 'exportSorting',
					'label'    => esc_html__( 'Entry Ordering', 'forgravity_entryautomation' ),
					'type'     => 'sorting',
					'callback' => array( $this, 'settings_sorting' ),
					'required' => false,
					'tooltip'  => sprintf(
						'<h6>%s</h6>%s',
						esc_html__( 'Entry Ordering', 'forgravity_entryautomation' ),
						esc_html__( 'Select which column to use to order entries and what direction to order them in.', 'forgravity_entryautomation' )
					),
				),
				array(
					'name'                => 'exportFields',
					'label'               => esc_html__( 'Select Fields', 'forgravity_entryautomation' ),
					'type'                => 'export_fields',
					'required'            => true,
					'callback'            => array( $this, 'settings_export_fields' ),
					'validation_callback' => array( $this, 'validate_export_fields' ),
					'tooltip'             => sprintf(
						'<h6>%s</h6>%s',
						esc_html__( 'Export Selected Fields', 'forgravity_entryautomation' ),
						esc_html__( 'Select the fields you would like to include in the export.', 'forgravity_entryautomation' )
					),
				),
			),
		);

	}

	/**
	 * Prepare export email settings.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @uses   Entry_Automation::get_actions_as_choices()
	 * @uses   GFAddOn::get_current_form()
	 *
	 * @return array
	 */
	public function email_settings() {

		// Get the current form.
		$form = fg_entryautomation()->get_current_form();

		return array(
			'id'         => 'section-export-email',
			'class'      => 'entryautomation-feed-section',
			'tab'        => array(
				'label' => esc_html__( 'Email Settings', 'forgravity_entryautomation' ),
				'icon'  => ' fa-envelope-o',
			),
			'dependency' => array( 'field' => 'action', 'values' => array( 'export' ) ),
			'fields'     => array(
				array(
					'name'    => 'exportEmailEnable',
					'label'   => esc_html__( 'Send Email', 'forgravity_entryautomation' ),
					'type'    => 'checkbox',
					'onclick' => "jQuery( this ).parents( 'form' ).submit()",
					'tooltip' => sprintf(
						'<h6>%s</h6>%s',
						esc_html__( 'Send Email', 'forgravity_entryautomation' ),
						esc_html__( 'When enabled, an email will be sent after the export is completed with the generated export file attached. By default, only export files under 2 MB will be sent.', 'forgravity_entryautomation' )
					),
					'choices' => array(
						array(
							'name'  => 'exportEmailEnable',
							'label' => esc_html__( 'Send an email with export file attached', 'forgravity_entryautomation' ),
						),
					),
				),
				array(
					'name'          => 'exportEmailAddress',
					'label'         => esc_html__( 'Send To', 'forgravity_entryautomation' ),
					'type'          => 'text',
					'required'      => true,
					'class'         => 'medium',
					'default_value' => get_bloginfo( 'admin_email' ),
					'dependency'    => array( 'field' => 'exportEmailEnable', 'values' => array( '1' ) ),
					'tooltip'       => sprintf(
						'<h6>%s</h6>%s',
						esc_html__( 'Send To', 'forgravity_entryautomation' ),
						esc_html__( 'Set the email address the export file will be emailed to. You can send to multiple email addresses by separating them with commas.', 'forgravity_entryautomation' )
					),
				),
				array(
					'name'          => 'exportEmailFromName',
					'label'         => esc_html__( 'From Name', 'forgravity_entryautomation' ),
					'type'          => 'text',
					'required'      => true,
					'class'         => 'medium',
					'default_value' => get_bloginfo( 'name' ),
					'dependency'    => array( 'field' => 'exportEmailEnable', 'values' => array( '1' ) ),
					'tooltip'       => sprintf(
						'<h6>%s</h6>%s',
						esc_html__( 'From Name', 'forgravity_entryautomation' ),
						esc_html__( 'Enter the name you would like the export email message to be sent from.', 'forgravity_entryautomation' )
					),
				),
				array(
					'name'          => 'exportEmailFrom',
					'label'         => esc_html__( 'From Address', 'forgravity_entryautomation' ),
					'type'          => 'text',
					'required'      => true,
					'class'         => 'medium',
					'default_value' => get_bloginfo( 'admin_email' ),
					'dependency'    => array( 'field' => 'exportEmailEnable', 'values' => array( '1' ) ),
					'tooltip'       => sprintf(
						'<h6>%s</h6>%s',
						esc_html__( 'From Address', 'forgravity_entryautomation' ),
						esc_html__( 'Enter the email address you would like the export email message to be sent from.', 'forgravity_entryautomation' )
					),
				),
				array(
					'name'          => 'exportEmailSubject',
					'label'         => esc_html__( 'Subject', 'forgravity_entryautomation' ),
					'type'          => 'text',
					'required'      => true,
					'class'         => 'large',
					'default_value' => sprintf( __( 'Entry Automation export for "%s"', 'forgravity_entryautomation' ), sanitize_text_field( $form['title'] ) ),
					'dependency'    => array( 'field' => 'exportEmailEnable', 'values' => array( '1' ) ),
				),
				array(
					'name'          => 'exportEmailMessage',
					'label'         => esc_html__( 'Message', 'forgravity_entryautomation' ),
					'type'          => 'textarea',
					'required'      => true,
					'class'         => 'large merge-tag-support mt-position-right mt-hide_all_fields mt-prepopulate',
					'default_value' => sprintf( __( 'The latest entry export for your form, %s, is attached to this message.', 'forgravity_entryautomation' ), sanitize_text_field( $form['title'] ) ),
					'dependency'    => array( 'field' => 'exportEmailEnable', 'values' => array( '1' ) ),
					'use_editor'    => true,
					'callback'      => array( $this, 'settings_export_email_message' ),
				),
				array(
					'name'       => 'exportEmailDelete',
					'type'       => 'checkbox',
					'onclick'    => "jQuery( this ).parents( 'form' ).submit()",
					'dependency' => array( 'field' => 'exportEmailEnable', 'values' => array( '1' ) ),
					'choices'    => array(
						array(
							'name'    => 'exportEmailDelete',
							'label'   => esc_html__( 'Delete export file after email has been sent', 'forgravity_entryautomation' ),
							'tooltip' => sprintf(
								'<h6>%s</h6>%s',
								esc_html__( 'Delete Export', 'forgravity_entryautomation' ),
								esc_html__( 'When enabled, the export file will be deleted after the email has been sent.', 'forgravity_entryautomation' )
							),
						),
					),
				),
			),
		);

	}

	/**
	 * Render an export fields field.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $field Field settings.
	 * @param bool  $echo  Display field. Defaults to true.
	 *
	 * @return string
	 */
	public function settings_export_fields( $field, $echo = true ) {

		// Get export file type.
		$file_type_setting = fg_entryautomation()->get_setting( 'exportFileType' );
		$file_type         = $file_type_setting ? $file_type_setting : 'csv';

		/**
		 * Include inputs as separate export fields.
		 *
		 * @since 1.3.6
		 *
		 * @param bool   $include_inputs
		 * @param string $file_type Selected export file type.
		 */
		$include_inputs = apply_filters( 'fg_entryautomation_export_fields_include_inputs', 'pdf' !== $file_type, $file_type );

		// Get field value.
		if ( fg_entryautomation()->get_setting( $field['name'] ) ) {
			$value = $this->update_export_fields( fg_entryautomation()->get_setting( $field['name'] ), $file_type, $include_inputs );
		} else {
			$value = $this->get_default_export_fields( $file_type, $include_inputs );
		}

		// Add hidden field container.
		$html = '<input
                    type="hidden"
                    name="_gaddon_setting_' . esc_attr( $field['name'] ) . '"
                    value=\'' . esc_attr( json_encode( $value ) ) . '\' ' .
				implode( ' ', fg_entryautomation()->get_field_attributes( $field ) ) .
				' />';

		// Add export fields container.
		$html .= '<div id="exportFieldsContainer"></div>';

		if ( $echo ) {
			echo $html;
		}

		return $html;

	}

	/**
	 * Validate Export Select Field setting.
	 *
	 * @since  1.0.2
	 * @access public
	 *
	 * @param array $field       The settings field being validated.
	 * @param array $field_value The submitted settings field value.
	 *
	 * @uses   GFAddOn::get_setting()
	 * @uses   GFAddOn::set_field_error()
	 */
	public function validate_export_fields( $field, $field_value ) {

		// Initialize selected checkboxes count.
		$selected = 0;

		// Loop through export fields.
		foreach ( $field_value as $export_field ) {

			// If choice does not have a valid value, exit.
			if ( ! is_bool( $export_field['enabled'] ) ) {
				fg_entryautomation()->set_field_error( $field, esc_html__( 'Invalid value.', 'gravityforms' ) );
				return;
			}

			// If choice is selected, increase selected count.
			if ( $export_field['enabled'] === true ) {
				$selected++;
			}

		}

		// If this field is required and no choices were selected, set error.
		if ( rgar( $field, 'required' ) && $selected < 1 ) {
			fg_entryautomation()->set_field_error( $field, rgar( $field, 'error_message' ) );
		}

	}

	/**
	 * Render a textarea field with a wrapper for styling.
	 *
	 * @since  1.4.4
	 * @access public
	 *
	 * @param array $field Field settings.
	 * @param bool  $echo  Display field. Defaults to true.
	 *
	 * @return string
	 */
	public function settings_export_email_message( $field, $echo = true ) {

		// Get textarea markup.
		$html = fg_entryautomation()->settings_textarea( $field, false );

		// Wrap markup with wrapper.
		$html = sprintf(
			'<div class="%s-container">%s</div>',
			$field['name'],
			$html
		);

		if ( $echo ) {
			echo $html;
		}

		return $html;

	}

	/**
	 * Render a Entry Ordering field.
	 *
	 * @since  1.4
	 * @access public
	 *
	 * @param array $field Field settings.
	 * @param bool  $echo  Display field. Defaults to true.
	 *
	 * @uses   Export::get_sorting_fields()
	 * @uses   GFAddOn::settings_select()
	 *
	 * @return string
	 */
	public function settings_sorting( $field, $echo = true ) {

		// Prepare key field.
		$key = [
			'name'          => $field['name'] . '[key]',
			'default_value' => 'id',
			'choices'       => $this->get_sorting_fields(),
		];

		// Prepare direction field.
		$direction = [
			'name'    => $field['name'] . '[direction]',
			'choices' => [
				[
					'label' => esc_html__( 'Ascending', 'forgravity_entryautomation' ),
					'value' => 'ASC',
				],
				[
					'label' => esc_html__( 'Descending', 'forgravity_entryautomation' ),
					'value' => 'DESC',
				],
			],
		];

		// Display fields.
		$html = sprintf(
			'%s %s',
			fg_entryautomation()->settings_select( $key, false ),
			fg_entryautomation()->settings_select( $direction, false )
		);

		if ( $echo ) {
			echo $html;
		}

		return $html;

	}

	/**
	 * Get fields for Entry Ordering settings field.
	 *
	 * @since  1.4
	 * @access public
	 *
	 * @uses   Export::get_default_export_fields()
	 *
	 * @return array
	 */
	public function get_sorting_fields() {

		// Get export fields.
		$fields = $this->get_default_export_fields( 'csv' );

		// Loop through fields, modify formatting.
		foreach ( $fields as $i => $field ) {

			// Modify formatting.
			$fields[ $i ] = [
				'label' => $field['default_label'],
				'value' => $field['id'],
			];

		}

		return $fields;

	}

	/**
	 * Icon class for Entry Automation settings button.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @return string
	 */
	public function get_icon() {

		return 'fa-file-excel-o';

	}

	/**
	 * Action label, used in Entry Automation settings.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @return string
	 */
	public function get_label() {

		return esc_html__( 'Export Entries', 'forgravity_entryautomation' );

	}

	/**
	 * Action short label, used in Entry Automation Tasks table.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @return string
	 */
	public function get_short_label() {

		return esc_html__( 'Export', 'forgravity_entryautomation' );

	}





	// # ACTION SETTINGS -----------------------------------------------------------------------------------------------

	/**
	 * Add links to feed list actions.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @param array  $links  Action links to be filtered.
	 * @param array  $task   Entry Automation Task meta.
	 * @param string $column The column ID.
	 *
	 * @return array
	 */
	public function feed_list_actions( $links, $task, $column ) {

		// Get existing export file path.
		$export_file = get_option( fg_entryautomation()->get_slug() . '_file_' . $task['task_id'] );

		// If export file was found, add action.
		if ( $export_file && file_exists( $export_file ) ) {

			// Prepare URL.
			$url = admin_url( 'admin.php?action=fg_entryautomation_export_file&tid=' . $task['task_id'] );
			$url = wp_nonce_url( $url, 'fg_entryautomation_export_file' );

			$links[] = sprintf(
				'<a href="%s">%s</a>',
				$url,
				esc_html__( 'Last Exported File', 'forgravity_entryautomation' )
			);

		}

		return $links;

	}





	// # RUNNING ACTION ------------------------------------------------------------------------------------------------

	/**
	 * Run task.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @param array $task Entry Automation Task meta.
	 * @param array $form The Form object.
	 *
	 * @return string|null
	 */
	public function run_task( $task, $form ) {

		// Prepare export file.
		$file_path = $this->prepare_export_file( $task, $form );

		// Send email.
		if ( rgar( $task, 'exportEmailEnable' ) ) {

			// Log that email export is enabled.
			fg_entryautomation()->log_debug( __METHOD__ . '(): Email of export file is enabled. Beginning email process.' );

			// Email export file.
			$this->email_export_file( $task, $form, $file_path );

		}

		// Save reference to file.
		if ( file_exists( $file_path ) ) {

			// Save to option.
			update_option( fg_entryautomation()->get_slug() . '_file_' . $task['task_id'], $file_path );

			return $file_path;

		} else {

			// Delete option.
			delete_option( fg_entryautomation()->get_slug() . '_file_' . $task['task_id'] );

			return null;

		}

	}

	/**
	 * Export form entries.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @param array $task Entry Automation Task meta.
	 * @param array $form The Form object.
	 *
	 * @uses   Action\Export\CSV::prepare_file()
	 * @uses   Action\Export\JSON::prepare_file()
	 * @uses   Action\Export\PDF::prepare_file()
	 *
	 * @return string
	 */
	public function prepare_export_file( $task, $form ) {

		switch ( $task['exportFileType'] ) {

			case 'csv':
			default:

				$file_path = Export\CSV::prepare_file( $task, $form );
				break;

			case 'json':

				$file_path = Export\JSON::prepare_file( $task, $form );
				break;

			case 'pdf':

				$file_path = Export\PDF::prepare_file( $task, $form );
				break;

		}

		return $file_path;

	}

	/**
	 * Send Entry Automation export file to email address.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @param array  $task      Entry Automation Task meta.
	 * @param array  $form      The form object.
	 * @param string $file_path Export file path.
	 *
	 * @uses   GFAddOn::log_error()
	 * @uses   GFCommon::is_valid_email_list()
	 */
	public function email_export_file( $task, $form, $file_path ) {

		// If file name is empty, return.
		if ( rgblank( $file_path ) ) {
			fg_entryautomation()->log_error( __METHOD__ . '(): Unable to email export file because export file name was not provided.' );
			return;
		}

		// Prepare to address.
		$to = GFCommon::replace_variables( $task['exportEmailAddress'], $form, [], false, false, false, 'text' );

		// If email address is invalid, return.
		if ( ! GFCommon::is_valid_email_list( $to ) ) {
			fg_entryautomation()->log_error( __METHOD__ . '(): Unable to email export file because an invalid email address was provided.' );
			return;
		}

		/**
		 * Get maximum email attachment size allowed in bytes.
		 * Defaults to 2 MB.
		 *
		 * @param int    $maximum_file_size Maximum file size allowed for attachment.
		 * @param array  $task              Entry Automation Task meta.
		 * @param array  $form              The form object.
		 * @param string $file_path         Export file path.
		 */
		$maximum_file_size = gf_apply_filters( array(
			'fg_entryautomation_maximum_attachment_size',
			$form['id'],
		), 2097152, $task, $form, $file_path );

		// If file size is larger than maximum allowed, exit.
		if ( filesize( $file_path ) > $maximum_file_size ) {
			fg_entryautomation()->log_error( __METHOD__ . '(): Unable to email export file because it is larger than the allowed maximum attachment size.' );
			return;
		}

		// Prepare email subject.
		if ( rgar( $task, 'exportEmailSubject' ) ) {
			$subject = GFCommon::replace_variables( $task['exportEmailSubject'], $form, [], false, true, false, 'text' );
		} else {
			$subject = sprintf( __( 'Entry Automation export for "%s"', 'forgravity_entryautomation' ), sanitize_text_field( $form['title'] ) );
		}

		/**
		 * Modify the export email subject.
		 *
		 * @param string $subject   Email subject.
		 * @param array  $task      Entry Automation Task meta.
		 * @param array  $form      The form object.
		 * @param string $file_path Export file path.
		 */
		$subject = gf_apply_filters( array(
			'fg_entryautomation_export_email_subject',
			$form['id'],
		), $subject, $task, $form, $file_path );

		// Prepare email message.
		if ( rgar( $task, 'exportEmailMessage' ) ) {
			$message = GFCommon::replace_variables( $task['exportEmailMessage'], $form, [], false, false, true, 'html' );
			$message = wp_kses( $message, wp_kses_allowed_html( 'post' ) );
		} else {
			$message = sprintf( __( 'The latest entry export for your form, %s, is attached to this message.', 'forgravity_entryautomation' ), sanitize_text_field( $form['title'] ) );
		}

		/**
		 * Modify the export email message.
		 *
		 * @param string $message   Email message.
		 * @param array  $task      Entry Automation Task meta.
		 * @param array  $form      The form object.
		 * @param string $file_path Export file path.
		 */
		$message = gf_apply_filters( array(
			'fg_entryautomation_export_email_message',
			$form['id'],
		), $message, $task, $form, $file_path );

		// Prepare from address.
		if ( rgar( $task, 'exportEmailFrom' ) ) {
			$from = GFCommon::replace_variables( sanitize_text_field( $task['exportEmailFrom'] ), $form, [], false, false, false, 'text' );
		} else {
			$from = 'noreply@forgravity.com';
		}

		// Prepare from name.
		if ( rgar( $task, 'exportEmailFromName' ) ) {
			$from_name = GFCommon::replace_variables( sanitize_text_field( $task['exportEmailFromName'] ), $form, [], false, false, false, 'text' );
			$from      = $from_name . ' <' . $from . '>';
		}

		// Prepare email headers.
		$headers = array(
			'From: ' . $from,
			'Content-type: ' . ( $message === strip_tags( $message ) ? 'text/plain' : 'text/html' ),
		);

		/**
		 * Modify the export email headers.
		 *
		 * @param array  $headers   Email headers.
		 * @param array  $task      Entry Automation Task meta.
		 * @param string $file_path Export file path.
		 */
		$headers = gf_apply_filters( array(
			'fg_entryautomation_export_email_headers',
			$form['id'],
		), $headers, $task, $file_path );

		// Send email.
		$send_result = wp_mail( $to, $subject, $message, $headers, array( $file_path ) );

		// Log email send result.
		fg_entryautomation()->log_debug( __METHOD__ . '(): wp_mail response: ' . print_r( $send_result, true ) );

		// Delete export.
		if ( rgar( $task, 'exportEmailDelete' ) ) {
			wp_delete_file( $file_path );
		}

	}





	// # ACTION DELETION -----------------------------------------------------------------------------------------------

	/**
	 * Delete task.
	 *
	 * @since  1.2.5
	 * @access public
	 *
	 * @param int $task_id Task ID.
	 */
	public function delete_task( $task_id ) {

		// Delete export file reference.
		delete_option( fg_entryautomation()->get_slug() . '_file_' . $task_id );

	}





	// # EXPORT FIELDS -------------------------------------------------------------------------------------------------

	/**
	 * Prepare exportable fields for settings field.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @param string $file_type      Export file type.
	 * @param bool   $include_inputs Include inputs as separate options.
	 *
	 * @uses   Export::add_default_export_fields()
	 * @uses   GFAddOn::get_current_form()
	 * @uses   GFCommon::get_label()
	 * @uses   GF_Field::get_entry_inputs()
	 *
	 * @return array
	 */
	public function get_default_export_fields( $file_type = 'csv', $include_inputs = false ) {

		// Get form.
		$form = fg_entryautomation()->get_current_form();

		// If no form is available, return array.
		if ( ! $form ) {
			return array();
		}

		// Add default export fields.
		$form = $this->add_default_export_fields( $form, $file_type );

		/**
		 * Loop through form fields.
		 *
		 * @var GF_Field $field
		 */
		foreach ( $form['fields'] as $field ) {

			// Exclude Nested Form fields from CSV.
			if ( 'form' === $field->get_input_type() && 'csv' === $file_type ) {
				continue;
			}

			// Get field inputs.
			$inputs = $field->get_entry_inputs();

			// If field has inputs, add them as choices.
			if ( is_array( $inputs ) && $include_inputs ) {

				// Loop through field inputs.
				foreach ( $inputs as $input ) {

					// Add input as choice.
					$fields[] = array(
						'id'            => esc_attr( $input['id'] ),
						'enabled'       => false,
						'label'         => '',
						'default_label' => GFCommon::get_label( $field, $input['id'] ),
					);

				}

			} else if ( ! $field->displayOnly ) {

				// Add field as choice.
				$fields[] = array(
					'id'            => esc_attr( $field->id ),
					'enabled'       => false,
					'label'         => '',
					'default_label' => GFCommon::get_label( $field ),
				);

			}

		}

		return $fields;

	}

	/**
	 * Add new exportable fields for settings field.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @param array  $fields         Existing choices.
	 * @param string $file_type      Export file type.
	 * @param bool   $include_inputs Include inputs as separate options.
	 *
	 * @uses   Export::add_default_export_fields()
	 * @uses   Export::get_previous_field_position()
	 * @uses   GFAddOn::get_current_form()
	 * @uses   GFCommon::get_label()
	 * @uses   GF_Field::get_entry_inputs()
	 *
	 * @return array
	 */
	public function update_export_fields( $fields, $file_type = 'csv', $include_inputs = false ) {

		// Get form.
		$form = fg_entryautomation()->get_current_form();

		// If no form is available, return.
		if ( ! $form ) {
			return $fields;
		}

		// Get existing field IDs.
		$existing_fields = wp_list_pluck( $fields, 'id' );

		// Add default export fields.
		$form = $this->add_default_export_fields( $form, $file_type );

		/**
		 * Loop through form fields.
		 *
		 * @var GF_Field $form_field
		 */
		foreach ( $form['fields'] as $i => $form_field ) {

			// If the field does not exist, skip.
			if ( ! is_a( $form_field, '\GF_Field' ) ) {
				continue;
			}

			// Exclude Nested Form fields from CSV.
			if ( 'form' === $form_field->get_input_type() && 'csv' === $file_type ) {
				continue;
			}

			// Get field inputs.
			$inputs = $form_field->get_entry_inputs();

			// If field has inputs, add them as choices.
			if ( is_array( $inputs ) && $include_inputs ) {

				// Loop through field inputs.
				foreach ( $inputs as $input_index => $input ) {

					// If input is already in list, skip.
					if ( in_array( strval( $input['id'] ), $existing_fields ) ) {
						continue;
					}

					// Get new choice index.
					$field_position = $this->get_previous_field_position( $form, $i, $fields ) + 1;
					$field_position += $input_index > 0 ? $input_index : 0;

					// Prepare input as choice.
					$new_choice = array(
						'id'            => esc_attr( $input['id'] ),
						'enabled'       => false,
						'label'         => '',
						'default_label' => GFCommon::get_label( $form_field, $input['id'] ),
					);

					// Insert choice.
					array_splice( $fields, $field_position, 0, array( $new_choice ) );

				}

			} else if ( ! $form_field->displayOnly ) {

				// If field is already in list, skip.
				if ( in_array( strval( $form_field->id ), $existing_fields ) ) {
					continue;
				}

				// Get new choice index.
				$field_position = $this->get_previous_field_position( $form, $i, $fields ) + 1;

				// Prepare field as choice.
				$new_choice = array(
					'id'            => esc_attr( $form_field->id ),
					'enabled'       => false,
					'label'         => '',
					'default_label' => GFCommon::get_label( $form_field ),
				);

				// Insert choice.
				array_splice( $fields, $field_position, 0, array( $new_choice ) );

			}

		}

		// Loop through export fields.
		foreach ( $fields as $i => &$field_meta ) {

			// Get field.
			$field = GFFormsModel::get_field( $form, $field_meta['id'] );

			// If this is the Entry Notes field and it is not supported by the file type, remove.
			if ( 'entry_notes' === $field_meta['id'] && 'csv' === $file_type ) {
				unset( $fields[ $i ] );
				continue;
			}

			// If field could not be found, skip.
			if ( ! $field ) {
				unset( $fields[ $i ] );
				continue;
			}

			// Get field inputs.
			$inputs = $field->get_entry_inputs();

			// If field has inputs, find input for this export field.
			if ( is_array( $inputs ) ) {

				// Loop through field inputs.
				foreach ( $inputs as $input ) {

					// If this is not the field, skip it.
					if ( strval( $input['id'] ) !== $field_meta['id'] ) {
						continue;
					}

					// Remove input.
					if ( 'pdf' === $file_type ) {
						unset( $fields[ $i ] );
					}

					// Update default label.
					$field_meta['default_label'] = GFCommon::get_label( $field, $input['id'] );

				}

			} else if ( ! $field->displayOnly ) {

				// Update default label.
				$field_meta['default_label'] = GFCommon::get_label( $field );

			}

		}

		return array_values( $fields );

	}

	/**
	 * Add default form and entry meta fields to form object.
	 *
	 * @since  1.3
	 * @access public
	 *
	 * @param array  $form      The Form object.
	 * @param string $file_type Export file type.
	 *
	 * @uses   GFExport::add_default_export_fields()
	 * @uses   GFFormsModel::convert_field_objects()
	 *
	 * @return array
	 */
	public static function add_default_export_fields( $form, $file_type = 'csv' ) {

		// Add default export fields.
		$form = GFExport::add_default_export_fields( $form );

		// Add entry notes field.
		if ( 'csv' !== $file_type ) {

			// Add Entry Notes field to end of form object.
			array_push( $form['fields'], [
				'id'    => 'entry_notes',
				'label' => __( 'Entry Notes', 'forgravity_entryautomation' ),
			] );

			// Convert field objects.
			$form = GFFormsModel::convert_field_objects( $form );

		}

		return $form;

	}

	/**
	 * Get position of previous form field in export fields list.
	 *
	 * @since  1.3
	 * @access public
	 *
	 * @param array $form             The Form object.
	 * @param int   $form_field_index Index of current field in Form object.
	 * @param array $export_fields    Export fields.
	 *
	 * @uses   GF_Field::get_entry_inputs()
	 *
	 * @return int|null|string
	 */
	public function get_previous_field_position( $form, $form_field_index, $export_fields ) {

		// Get previous field.
		$previous_field = $form_field_index == 0 ? false : $form['fields'][ $form_field_index - 1 ];

		// Get previous field ID.
		if ( $previous_field ) {

			// Use final input.
			if ( $previous_field->get_entry_inputs() ) {

				// Get inputs.
				$inputs = $previous_field->inputs;

				// Get last input.
				$last_input = end( $inputs );

				// Use last input ID.
				$previous_field_id = $last_input['id'];

			} else {

				// Use field ID.
				$previous_field_id = $previous_field->id;

			}

		}

		// If previous field ID is defined, find previous field in export fields list.
		if ( $previous_field_id ) {

			// Loop through fields.
			foreach ( $export_fields as $i => $field ) {

				// If the field IDs match, return index.
				if ( esc_attr( $previous_field_id ) === esc_attr( $field['id'] ) ) {
					return $i;
				}

			}

		}

		end( $export_fields );

		return key( $export_fields );

	}





	// # HELPER METHODS ------------------------------------------------------------------------------------------------

	/**
	 * Get fields to be exported to file during Entry Automation.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $task Entry Automation feed settings.
	 *
	 * @return array
	 */
	public static function get_export_fields( $task ) {

		// Initialize fields array.
		$fields = array();

		// Loop through export fields.
		foreach ( $task['exportFields'] as $field ) {

			// If field is not enabled, skip it.
			if ( ! $field['enabled'] ) {
				continue;
			}

			// Add field ID to fields array.
			$fields[] = $field;

		}

		return $fields;

	}

	/**
	 * Get file name for Entry Automation export file.
	 *
	 * @since  1.0
	 * @access public
	 *
	 * @param array $task Entry Automation Task meta.
	 * @param array $form The Form object.
	 *
	 * @uses   GFCommon::get_local_timestamp()
	 * @uses   GFExport::maybe_create_htaccess_file()
	 * @uses   GFExport::maybe_create_index_file()
	 * @uses   GFFormsModel::get_upload_root()
	 *
	 * @return string
	 */
	public static function get_file_name( $task, $form ) {

		// Require export class.
		if ( ! class_exists( 'GFExport' ) ) {
			require_once GFCommon::get_base_path() . '/export.php';
		}

		/**
		 * Modify the root export folder path.
		 *
		 * @since 1.2.3
		 *
		 * @param string $folder Path to the export folder.
		 * @param array  $task   Entry Automation Task meta.
		 * @param array  $form   The Form object.
		 */
		$folder = gf_apply_filters( array(
			'fg_entryautomation_export_folder',
			$form['id'],
			$task['task_id'],
		), GFFormsModel::get_upload_root() . 'export', $task, $form );

		// If export folder does not exist, create it.
		if ( ! is_dir( $folder ) ) {
			wp_mkdir_p( $folder );
		}

		// Add trailing slash to folder path.
		$folder = trailingslashit( $folder );

		// Add htaccess file to export folder.
		GFExport::maybe_create_htaccess_file( $folder );

		// Add index file to export folder.
		GFExport::maybe_create_index_file( $folder );

		// Get file name from Entry Automation settings.
		$file_name = rgar( $task, 'exportFileName' );

		// Get default extension.
		$extension = 'pdf' === rgar( $task, 'exportFileType' ) ? 'pdf' : ( 'json' === rgar( $task, 'exportFileType' ) ? 'json' : 'csv' );

		// If file name is empty, use default file name.
		if ( rgblank( $file_name ) ) {
			$file_name = '{form_title}-{timestamp}.' . $extension;
		}

		// Replace basic merge tags in file name.
		$file_name = str_replace( array( '{form_id}', '{form_title}', '{timestamp}' ), array(
			$form['id'],
			$form['title'],
			fg_entryautomation()->strtotime(),
		), $file_name );

		// Check for date merge tag.
		preg_match_all( '/\{(date):?([A-z- :]*)\}/', $file_name, $date_matches, PREG_SET_ORDER );

		// If matches were found, replace them.
		if ( ! empty( $date_matches ) ) {

			// Loop through matches.
			foreach ( $date_matches as $date_match ) {

				// Get date format.
				$format = ! empty( $date_match[2] ) ? $date_match[2] : 'Y-m-d H:i:s';

				// Get date.
				$date = fg_entryautomation()->strtotime( null, $format );

				// Replace date in file name.
				$file_name = str_replace( $date_match[0], $date, $file_name );

			}

		}

		// Get file name extension.
		$ext = pathinfo( $file_name, PATHINFO_EXTENSION );

		// If file name does not have extension, add it.
		if ( rgblank( $ext ) ) {
			$ext .= $extension;
		}

		// Get filename without extension.
		$file_name = pathinfo( $file_name, PATHINFO_FILENAME );

		// Sanitize the file name.
		$file_name = sanitize_file_name( $file_name );

		// Define target file name.
		$target_file_name = $folder . $file_name . '.' . $ext;

		if ( '1' == rgar( $task, 'exportOverwriteExisting' ) && file_exists( $target_file_name ) ) {

			// Log that we will be deleting the existing file.
			fg_entryautomation()->log_debug( __METHOD__ . '(): Overwrite existing export file enabled. Deleting previous export file.' );

			// Delete file.
			wp_delete_file( $target_file_name );

		} else {

			// Define starting duplicate file name counter.
			$counter = 1;

			// If file name exists, iterate until it does not.
			while ( file_exists( $target_file_name ) ) {
				$target_file_name = $folder . $file_name . '-' . $counter . '.' . $ext;
				$counter++;
			}

		}

		/**
		 * Modify the export file name.
		 *
		 * @param string $file_name File name of export file.
		 * @param array  $task      Entry Automation Task meta.
		 * @param array  $form      The Form object.
		 */
		$target_file_name = gf_apply_filters( array(
			'fg_entryautomation_export_file_name',
			$form['id'],
		), $target_file_name, $task, $form );

		return $target_file_name;

	}

	/**
	 * Get header for CSV export file.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @param array|\GF_Field_Repeater $form       The form object.
	 * @param array                    $field_meta Fields being exported.
	 *
	 * @uses   GFCommon::get_label()
	 * @uses   GFFormsModel::get_field()
	 *
	 * @return string
	 */
	public static function get_field_label( $form, $field_meta ) {

		// Get field.
		$field = GFFormsModel::get_field( $form, $field_meta['id'] );

		// If field does not exist, return.
		if ( ! $field ) {
			return '';
		}

		// Get field label.
		$field_label = rgar( $field_meta, 'label' ) ? $field_meta['label'] : ( rgobj( $field, 'adminLabel' ) ? $field->adminLabel : $field->label );

		// Get field input.
		$input = GFFormsModel::get_input( $field, $field_meta['id'] );

		// Prepare label.
		if ( $input != null ) {
			$input_label = rgar( $input, 'customLabel', rgar( $input, 'label' ) );
			$label       = $field_label . ' (' . $input_label . ')';
		} else {
			$label = $field_label;
		}

		return $label;

	}

	/**
	 * Get field value from entry.
	 *
	 * @since  1.4
	 * @access public
	 *
	 * @param array  $form     The Form object.
	 * @param array  $entry    The Entry object.
	 * @param string $field_id The field ID to return.
	 * @param bool   $is_csv   Return value for CSV file.
	 *
	 * @uses   GFAPI::get_field()
	 * @uses   GFCommon::get_local_timestamp()
	 * @uses   GF_Field::get_value_export()
	 * @uses   GFFormsModel::get_lead_notes()
	 *
	 * @return string
	 */
	public static function get_field_value( $form, $entry, $field_id, $is_csv = true ) {

		// Get field value based on field ID.
		switch ( $field_id ) {

			case 'date_created':

				// Get entry GMT time.
				$entry_gmt_time = mysql2date( 'G', $entry['date_created'] );

				// Get entry local time.
				$entry_local_time = GFCommon::get_local_timestamp( $entry_gmt_time );

				// Get formatted time.
				$field_value = date_i18n( 'Y-m-d H:i:s', $entry_local_time, true );

				break;

			case 'entry_notes':

				// Get entry notes.
				$field_value = GFFormsModel::get_lead_notes( $entry['id'] );

				break;

			case 'form_title':

				// Get form title.
				$field_value = rgar( $form, 'title' );

				break;

			case 'ip':
			case 'source_url':
			case 'id':

				// Get value, set to lowercase.
				$field_value = rgar( $entry, strtolower( $field_id ) );

				break;

			default:

				// Get field.
				$field = GFAPI::get_field( $form, $field_id );

				// If this is a Nested Form, get Nested Form value.
				if ( $field && 'form' === $field->type ) {
					$field_value = static::get_nested_form_value( $form, $entry, $field );
				// If this is a Repeater field, get Repeater value.
				} else if ( $field && 'repeater' === $field->type ) {
					$field_value = static::get_repeater_field_value( $form, $entry, $field, $is_csv );
				} else if ( is_a( $field, '\GF_Field' ) ) {
					$field_value = $field->get_value_export( $entry, $field_id, false, $is_csv );
					$field_value = $is_csv || empty( $field_value ) ? $field_value : fg_entryautomation()->maybe_decode_json( $field_value );
				} else {
					$field_value = rgar( $entry, $field_id );
				}

				break;

		}

		// Unserialize field value.
		$field_value = maybe_unserialize( $field_value );

		return $field_value;

	}

	/**
	 * Get field value for Nested Form.
	 *
	 * @since  1.4
	 * @access private
	 *
	 * @param array                 $form              The Form object.
	 * @param array                 $entry             The Entry object.
	 * @param \GP_Field_Nested_Form $nested_form_field The Nested Form field.
	 *
	 * @uses   Export::get_field_label()
	 * @uses   Export::get_field_value()
	 * @uses   GFAPI::get_entry()
	 * @uses   GFAPI::get_form()
	 *
	 * @return array
	 */
	private static function get_nested_form_value( $form, $entry, $nested_form_field ) {

		// Initialize value array.
		$value = [];

		// Get entry IDs.
		$entry_ids = rgar( $entry, $nested_form_field->id );

		// If Nested form has no entries, return.
		if ( rgblank( $entry_ids ) ) {
			return $value;
		}

		// Get Nested Form.
		$nested_form = $nested_form_field->gpnfForm ? GFAPI::get_form( $nested_form_field->gpnfForm ) : false;

		// If Nested form was not found, return.
		if ( ! $nested_form ) {
			return $value;
		}

		// Explode entry IDs.
		$entry_ids = explode( ',', $entry_ids );

		// Loop through entry IDs.
		foreach ( $entry_ids as $entry_id ) {

			// Initialize entry array.
			$e = [];

			// Get nested entry.
			$nested_entry = GFAPI::get_entry( $entry_id );

			// If entry could not be found, skip.
			if ( ! $nested_entry ) {
				continue;
			}

			// Loop through Nested Form fields.
			foreach ( $nested_form['fields'] as $field ) {

				// If field is not nested, skip.
				if ( ! is_array( $nested_form_field->gpnfFields ) || ! in_array( $field->id, $nested_form_field->gpnfFields ) ) {
					continue;
				}

				// Get field label and value.
				$field_label = self::get_field_label( $nested_form, [ 'id' => $field->id ] );
				$field_value = self::get_field_value( $nested_form, $nested_entry, $field->id );

				// Add to entry.
				$e[ $field_label ] = $field_value;

			}

			// Add entry to return value.
			$value[] = $e;

		}

		return $value;

	}

	/**
	 * Get values for Repeater field.
	 *
	 * @since  1.4
	 * @access protected
	 *
	 * @param array              $form           The Form object.
	 * @param array              $entry          The Entry object.
	 * @param \GF_Field_Repeater $repeater_field Repeater Field object.
	 * @param bool               $is_csv         Return value for CSV file.
	 *
	 * @uses   Export::get_field_label()
	 * @uses   Export::get_repeater_field_value()
	 * @uses   Export::get_field_value()
	 * @uses   GF_Field::get_entry_inputs()
	 *
	 * @return array
	 */
	protected static function get_repeater_field_value( $form, $entry, $repeater_field, $is_csv = true ) {

		// Initialize value array.
		$value = [];

		// Get items.
		$items = rgar( $entry, $repeater_field->id );

		// If no items were submitted, return.
		if ( empty( $items ) ) {
			return $value;
		}

		// Loop through items, get value.
		foreach ( $items as $item ) {

			// Initialize value for item.
			$val = [];

			/**
			 * Loop through fields.
			 *
			 * @var GF_Field $field
			 */
			foreach ( $repeater_field->fields as $field ) {

				// Get label.
				$label = self::get_field_label( $repeater_field, [ 'id' => $field->id ] );

				if ( is_array( $field->fields ) ) {

					// Get inputs.
					$inputs = $field->get_entry_inputs();

					// Get field value for inputs.
					if ( is_array( $inputs ) ) {

						$field_value = array();
						$field_keys  = array_keys( $item );

						foreach ( $field_keys as $input_id ) {
							if ( is_numeric( $input_id ) && absint( $input_id ) == absint( $field->id ) ) {
								$field_value[ $input_id ] = $item[ $input_id ];
							}
						}

					} else {

						// Get field value.
						$field_value = isset( $item[ $field->id ] ) ? $item[ $field->id ] : '';
						$field_value = [ (string) $field->id => $field_value ];

					}

					$field_value = static::get_repeater_field_value( $field->fields, $field_value, $field, $is_csv );

				} else {

					$field_value = static::get_field_value( $form, $item, $field->id, $is_csv );

				}

				// Add to value.
				$val[ $label ] = $field_value;

			}

			// Add to main value array.
			$value[] = $val;

		}

		return $value;

	}

	/**
	 * Get sorting for task.
	 *
	 * @since 1.4
	 *
	 * @param array $task Entry Automation task meta.
	 * @param array $form The current Form object.
	 *
	 * @return array
	 */
	public static function get_sorting( $task, $form ) {

		// Initialize default sorting.
		$sorting = [ 'key' => 'id', 'direction' => 'DESC' ];

		// If task has sorting defined, use it.
		if ( rgars( $task, 'exportSorting' ) ) {
			$sorting = [
				'key'       => $task['exportSorting']['key'],
				'direction' => $task['exportSorting']['direction'],
			];
		}

		/**
		 * Define entry sorting criteria.
		 *
		 * @since 1.2
		 *
		 * @param array $sorting Sorting criteria.
		 * @param array $task    Entry Automation Task meta.
		 * @param array $form    The Form object.
		 */
		$sorting = gf_apply_filters( array(
			'fg_entryautomation_export_sorting',
			$task['task_id'],
		), $sorting, $task, $form );

		return $sorting;

	}
	
}

Action::register( '\ForGravity\EntryAutomation\Action\Export' );
