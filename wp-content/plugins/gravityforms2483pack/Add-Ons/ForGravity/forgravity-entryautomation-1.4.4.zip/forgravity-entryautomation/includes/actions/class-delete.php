<?php

namespace ForGravity\EntryAutomation\Action;

use ForGravity\EntryAutomation\Action;
use GFAPI;

if ( ! class_exists( '\ForGravity\EntryAutomation\Action' ) ) {
	require_once fg_entryautomation()->get_base_path() . '/includes/class-action.php';
}

class Delete extends Action {

	/**
	 * Contains an instance of this class, if available.
	 *
	 * @since  1.2
	 * @access protected
	 * @var    object $_instance If available, contains an instance of this class.
	 */
	protected static $_instance = null;

	/**
	 * Defines the action name.
	 *
	 * @since  1.2
	 * @access protected
	 * @var    string $action Action name.
	 */
	protected $name = 'delete';


	// # ACTION SETTINGS -----------------------------------------------------------------------------------------------

	/**
	 * Settings fields for configuring this Entry Automation action.
	 *
	 * @since  1.2.1
	 * @access public
	 *
	 * @return array
	 */
	public function settings_fields() {

		return array(
			'id'         => 'section-delete',
			'class'      => 'entryautomation-feed-section',
			'tab'        => array(
				'label' => esc_html__( 'Delete Settings', 'forgravity_entryautomation' ),
				'icon'  => 'fa-trash'
			),
			'dependency' => array( 'field' => 'action', 'values' => array( 'delete' ) ),
			'fields'     => array(
				array(
					'name'    => 'moveToTrash',
					'label'   => esc_html__( 'Move To Trash', 'forgravity_entryautomation' ),
					'type'    => 'checkbox',
					'tooltip' => sprintf(
						'<h6>%s</h6>%s',
						esc_html__( 'Move To Trash', 'forgravity_entryautomation' ),
						esc_html__( 'When enabled, entries will be moved to the trash section instead of being immediately deleted from the database.', 'forgravity_entryautomation' )
					),
					'choices' => array(
						array(
							'name'  => 'moveToTrash',
							'label' => esc_html__( 'Move entries to trash instead of deleting them immediately', 'forgravity_entryautomation' ),
						),
					),
				),
			),
		);

	}

	/**
	 * Icon class for Entry Automation settings button.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @return string
	 */
	public function get_icon() {

		return 'fa-trash';

	}

	/**
	 * Action label, used in Entry Automation settings.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @return string
	 */
	public function get_label() {

		return esc_html__( 'Delete Entries', 'forgravity_entryautomation' );

	}

	/**
	 * Action short label, used in Entry Automation Tasks table.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @return string
	 */
	public function get_short_label() {

		return esc_html__( 'Delete', 'forgravity_entryautomation' );

	}





	// # RUNNING ACTION ------------------------------------------------------------------------------------------------

	/**
	 * Process task.
	 *
	 * @since  1.2
	 * @access public
	 *
	 * @param array $task Entry Automation Task.
	 * @param array $form The Form object.
	 */
	public function run_task( $task, $form ) {

		// Prepare search criteria.
		$search_criteria = fg_entryautomation()->get_search_criteria( $task, $form );

		// Prepare paging criteria.
		$paging = array(
			'offset'    => 0,
			'page_size' => 50,
		);

		// Get total entry count.
		$found_entries = GFAPI::count_entries( $form['id'], $search_criteria );

		// Set entries processed count.
		$entries_processed = 0;

		// Loop until all entries have been processed.
		while ( $entries_processed < $found_entries ) {

			// Log the page number.
			fg_entryautomation()->log_debug( __METHOD__ . '(): Starting deletion of page ' . ( round( $entries_processed / $paging['page_size'] ) + 1 ) . ' of ' . ( round( $found_entries / $paging['page_size'] ) ) );

			// Get entries.
			$entries = GFAPI::get_entries( $form['id'], $search_criteria, null, $paging );

			// If no more entries were found, break.
			if ( empty( $entries ) ) {
				fg_entryautomation()->log_debug( __METHOD__ . '(): No entries were found for this page.' );
				break;
			}

			// Loop through entries.
			foreach ( $entries as $entry ) {

				// Move entry to trash or delete it.
				if ( rgar( $task, 'moveToTrash' ) ) {
					GFAPI::update_entry_property( $entry['id'], 'status', 'trash' );
				} else {
					GFAPI::delete_entry( $entry['id'] );
				}

				// Increase entries processed count.
				$entries_processed++;

			}

		}

		// Log that deletion has been completed.
		fg_entryautomation()->log_debug( __METHOD__ . '(): Deletion completed.' );

		/**
		 * Executed after entries have been deleted.
		 *
		 * @param array $task Entry Automation Task.
		 * @param array $form The Form object.
		 */
		gf_do_action( array( 'fg_entryautomation_after_deletion', $form['id'] ), $task, $form );

	}

}

Action::register( '\ForGravity\EntryAutomation\Action\Delete' );
