=== Entry Automation for Gravity Forms ===
Contributors: travislopes
Tags: automation, entry, export, delete, deletion, submissions, gravity forms
Requires at least: 4.2
Requires PHP: 5.6
Tested up to: 4.9.2
License: GPL-3.0+
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Automate common entry clean up actions including deletion and export.

== Description ==

Entry Automation allows Gravity Forms entries to be deleted and exported on a defined scheduled.

Entry Automation requires [Gravity Forms](https://forgravity.com/gravityforms).

= Requirements =

1. [Purchase and install Gravity Forms](https://forgravity.com/gravityforms)
2. WordPress 4.2+
3. Gravity Forms 1.9.14+

= Support =

If you have any problems, please contact support: https://forgravity.com/support/

== Installation ==

1.  Download the zipped file.
1.  Extract and upload the contents of the folder to your /wp-contents/plugins/ folder.
1.  Navigate to the WordPress admin Plugins page and activate the "Entry Automation for Gravity Forms" plugin.

== ChangeLog ==

= 1.4.4 =
- Update the position of the Export Email Message validation error message to be more easily visible.

= 1.4.3 =
- Fix PHP warning when duplicating task.
- Update Date Range preview to not run when no date is set.
- Update Start Running Task task setting to not be visible when task has already run.

= 1.4.2 =
- Add merge tag support to export email from, to, subject and message settings.
- Fix a PHP 7.3 warning when exporting to PDF.

= 1.4.1 =
- Add "fg_entryautomation_next_run_time" filter.

= 1.4 =
- Add custom ordering to Export Entries tasks.
- Add starred and unread statuses to conditional logic filters.
- Add support for Gravity Perks Nested Forms fields.
- Add support for Repeater fields.

- Add "fg_entryautomation_disable_task_skipping" filter.
- Add "fg_entryautomation_export_email_headers" filter.
- Add "fg_entryautomation_export_fields_include_inputs" filter.
- Add "fg_entryautomation_export_lines" filter.
- Add support for Polls, Quiz and Survey Add-Ons.
- Fix HTML content type not being set when export email message contains HTML tags.
- Fix issue with fields not appearing in PDFs.
- Fix issue with task running when saving task settings.
- Fix Run Task Now not using updates to export email message.
- Fix run time preview displaying incorrect time.
- Fix task running when form could not be found.
- Update extension framework to support new extensions.
- Update formatting of first run date on task settings page.

= 1.3 =
- Add available extensions to plugin settings page.
- Add extension framework.
- Add option to export entry notes to JSON or PDF files.
- Fix first task settings section with error not being visible on load.
- Update automation queue to run as individual scheduled events for each task.
- Update export fields setting to insert new fields after previous form field.
- Update "Next Run Time" and "Start Run Time" task settings to allow for more precise control over time.

- Add ability to change next run time for task.
- Add database cleanup when deleting an action.
- Add option to move entries to trash instead of immediately deleting them.
- Add "fg_entryautomation_export_folder" filter to modify root Entry Automation export folder location.
- Add "fg_entryautomation_{$action}_settings_fields" filter to modify settings fields for an action.
- Fix fatal error during export task when mbstring is not installed.
- Fix fatal error on task settings page after a form field was deleted.
- Fix List field values appearing as string in JSON export.
- Fix multiple row List field values appearing as "Array" in CSV export.
- Update license API requests to support upcoming ForGravity bundle.

= 1.2 =
- Add "fg_entryautomation_export_sorting" filter.
- Add framework for custom actions.
- Add JSON as export entries file type.
- Add PDF as export entries file type.
- Update conditional logic to support entry meta and entry properties (including Partial Entries).
- Update date range preview to be relative to next run time (or first task run time for new tasks).
- Update export fields to allow for custom field labels.
- Update export fields to be sortable.

- Add "fg_entryautomation_export_field_value" filter.
- Add support for custom date string in export file name.
- Add support for duplicating Entry Automation tasks.
- Fix email subject not using feed settings option.
- Fix incorrect slug in automatic updater.
- Fix "Last Exported File" link not working due to htaccess permissions.
- Fix several PHP notices.
- Update automation to select active entries by default.
- Update conditional logic instructions based on selected action.
- Update export file to use admin field labels.
- Update export header names to be wrapped in quotes.
- Update search criteria to use custom strtotime method.

= 1.1 =
- Add error validation for task date range.
- Add export email settings (from address, from name, message, subject).
- Add "fg_entryautomation_recurrence" filter to control how often Entry Automation cron action runs.
- Add "fg_entryautomation_{verb}_task" action for custom tasks.
- Add "Last Exported File" to feed list.
- Add minimum PHP version check.
- Add plugin capabilities.
- Add support for definitive dates for task date range (YYYY-MM-DD or YYYY-MM-DD HH:MM:SS).
- Add task ID modifier to "fg_entryautomation_search_criteria".
- Add timezone correction for first run time.
- Add setting to allow overwriting of existing export file.
- Add validation to "Select Fields" Export settings field to ensure at least one field is selected.
- Fix DateTimeZone not initializing when GMT offset is set to a positive integer.
- Fix error when calculating first run time.
- Fix issue where task would request entry pages that did not exist.
- Fix issue with tasks set to run weekly/monthly running too often.
- Improved interface for setting initial task run time.
- Improved interface for setting task date range.
- Improved task configuration interface.
- Removed default feed processing filter.
- Update "fg_entryautomation_export_file_name" filter to run after detecting duplicate file name to allow for more flexible modifying.
- Update task configuration interface to display last active tab on save.
- Update time conversion method to default to strtotime function when DateTime cannot be initialized.

= 1.0 =
- It's all new!