<?php

require_once 'lib'.DIRECTORY_SEPARATOR.'curl.php';
require_once 'lib'.DIRECTORY_SEPARATOR.'curl_response.php';
require_once 'lib'.DIRECTORY_SEPARATOR.'curl_exception.php';