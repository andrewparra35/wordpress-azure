<?php


namespace Twilio\Exceptions;

// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die();
}

class TwimlException extends TwilioException {

}