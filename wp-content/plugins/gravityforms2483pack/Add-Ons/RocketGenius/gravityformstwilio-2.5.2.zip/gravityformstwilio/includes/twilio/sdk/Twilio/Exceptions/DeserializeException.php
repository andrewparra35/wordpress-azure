<?php


namespace Twilio\Exceptions;

// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die();
}

class DeserializeException extends TwilioException {

}